"use client";

import ReactCookieBot from "react-cookiebot";
const domainGroupId = "b7172fe2-e48f-4a74-ad70-75b96c2daa16";

export default function CookiebotReact() {
  return <ReactCookieBot domainGroupId={domainGroupId} />;
}