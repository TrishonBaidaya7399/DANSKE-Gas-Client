(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/lib/utils.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "cn": ()=>cn
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-client] (ecmascript)");
;
;
function cn() {
    for(var _len = arguments.length, inputs = new Array(_len), _key = 0; _key < _len; _key++){
        inputs[_key] = arguments[_key];
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/ui/dropdown-menu.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "DropdownMenu": ()=>DropdownMenu,
    "DropdownMenuCheckboxItem": ()=>DropdownMenuCheckboxItem,
    "DropdownMenuContent": ()=>DropdownMenuContent,
    "DropdownMenuGroup": ()=>DropdownMenuGroup,
    "DropdownMenuItem": ()=>DropdownMenuItem,
    "DropdownMenuLabel": ()=>DropdownMenuLabel,
    "DropdownMenuPortal": ()=>DropdownMenuPortal,
    "DropdownMenuRadioGroup": ()=>DropdownMenuRadioGroup,
    "DropdownMenuRadioItem": ()=>DropdownMenuRadioItem,
    "DropdownMenuSeparator": ()=>DropdownMenuSeparator,
    "DropdownMenuShortcut": ()=>DropdownMenuShortcut,
    "DropdownMenuSub": ()=>DropdownMenuSub,
    "DropdownMenuSubContent": ()=>DropdownMenuSubContent,
    "DropdownMenuSubTrigger": ()=>DropdownMenuSubTrigger,
    "DropdownMenuTrigger": ()=>DropdownMenuTrigger
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-dropdown-menu/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/check.js [app-client] (ecmascript) <export default as CheckIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRightIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-client] (ecmascript) <export default as ChevronRightIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle.js [app-client] (ecmascript) <export default as CircleIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
function DropdownMenu(param) {
    let { ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
        "data-slot": "dropdown-menu",
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dropdown-menu.tsx",
        lineNumber: 12,
        columnNumber: 10
    }, this);
}
_c = DropdownMenu;
function DropdownMenuPortal(param) {
    let { ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Portal"], {
        "data-slot": "dropdown-menu-portal",
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dropdown-menu.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
}
_c1 = DropdownMenuPortal;
function DropdownMenuTrigger(param) {
    let { ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trigger"], {
        "data-slot": "dropdown-menu-trigger",
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dropdown-menu.tsx",
        lineNumber: 27,
        columnNumber: 5
    }, this);
}
_c2 = DropdownMenuTrigger;
function DropdownMenuContent(param) {
    let { className, sideOffset = 4, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Portal"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Content"], {
            "data-slot": "dropdown-menu-content",
            sideOffset: sideOffset,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("bg-popover text-popover-foreground data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 max-h-(--radix-dropdown-menu-content-available-height) min-w-[8rem] origin-(--radix-dropdown-menu-content-transform-origin) overflow-x-hidden overflow-y-auto rounded-md border p-1 shadow-md !transform-[translate(16px, 61.5px)]", className),
            ...props
        }, void 0, false, {
            fileName: "[project]/src/components/ui/dropdown-menu.tsx",
            lineNumber: 41,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dropdown-menu.tsx",
        lineNumber: 40,
        columnNumber: 5
    }, this);
}
_c3 = DropdownMenuContent;
function DropdownMenuGroup(param) {
    let { ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Group"], {
        "data-slot": "dropdown-menu-group",
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dropdown-menu.tsx",
        lineNumber: 58,
        columnNumber: 5
    }, this);
}
_c4 = DropdownMenuGroup;
function DropdownMenuItem(param) {
    let { className, inset, variant = "default", ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Item"], {
        "data-slot": "dropdown-menu-item",
        "data-inset": inset,
        "data-variant": variant,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("focus:bg-accent focus:text-accent-foreground data-[variant=destructive]:text-destructive data-[variant=destructive]:focus:bg-destructive/10 dark:data-[variant=destructive]:focus:bg-destructive/20 data-[variant=destructive]:focus:text-destructive data-[variant=destructive]:*:[svg]:!text-destructive [&_svg:not([class*='text-'])]:text-muted-foreground relative flex cursor-default items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-hidden select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 data-[inset]:pl-8 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dropdown-menu.tsx",
        lineNumber: 72,
        columnNumber: 5
    }, this);
}
_c5 = DropdownMenuItem;
function DropdownMenuCheckboxItem(param) {
    let { className, children, checked, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CheckboxItem"], {
        "data-slot": "dropdown-menu-checkbox-item",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("focus:bg-accent focus:text-accent-foreground relative flex cursor-default items-center gap-2 rounded-sm py-1.5 pr-2 pl-8 text-sm outline-hidden select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", className),
        checked: checked,
        ...props,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "pointer-events-none absolute left-2 flex size-3.5 items-center justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ItemIndicator"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckIcon$3e$__["CheckIcon"], {
                        className: "size-4"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/dropdown-menu.tsx",
                        lineNumber: 103,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/dropdown-menu.tsx",
                    lineNumber: 102,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/ui/dropdown-menu.tsx",
                lineNumber: 101,
                columnNumber: 7
            }, this),
            children
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/dropdown-menu.tsx",
        lineNumber: 92,
        columnNumber: 5
    }, this);
}
_c6 = DropdownMenuCheckboxItem;
function DropdownMenuRadioGroup(param) {
    let { ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RadioGroup"], {
        "data-slot": "dropdown-menu-radio-group",
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dropdown-menu.tsx",
        lineNumber: 115,
        columnNumber: 5
    }, this);
}
_c7 = DropdownMenuRadioGroup;
function DropdownMenuRadioItem(param) {
    let { className, children, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RadioItem"], {
        "data-slot": "dropdown-menu-radio-item",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("focus:bg-accent focus:text-accent-foreground relative flex cursor-default items-center gap-2 rounded-sm py-1.5 pr-2 pl-8 text-sm outline-hidden select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", className),
        ...props,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "pointer-events-none absolute left-2 flex size-3.5 items-center justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ItemIndicator"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleIcon$3e$__["CircleIcon"], {
                        className: "size-2 fill-current"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/dropdown-menu.tsx",
                        lineNumber: 138,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/dropdown-menu.tsx",
                    lineNumber: 137,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/ui/dropdown-menu.tsx",
                lineNumber: 136,
                columnNumber: 7
            }, this),
            children
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/dropdown-menu.tsx",
        lineNumber: 128,
        columnNumber: 5
    }, this);
}
_c8 = DropdownMenuRadioItem;
function DropdownMenuLabel(param) {
    let { className, inset, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
        "data-slot": "dropdown-menu-label",
        "data-inset": inset,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("px-2 py-1.5 text-sm font-medium data-[inset]:pl-8", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dropdown-menu.tsx",
        lineNumber: 154,
        columnNumber: 5
    }, this);
}
_c9 = DropdownMenuLabel;
function DropdownMenuSeparator(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Separator"], {
        "data-slot": "dropdown-menu-separator",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("bg-border -mx-1 my-1 h-px", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dropdown-menu.tsx",
        lineNumber: 171,
        columnNumber: 5
    }, this);
}
_c10 = DropdownMenuSeparator;
function DropdownMenuShortcut(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        "data-slot": "dropdown-menu-shortcut",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-muted-foreground ml-auto text-xs tracking-widest", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dropdown-menu.tsx",
        lineNumber: 184,
        columnNumber: 5
    }, this);
}
_c11 = DropdownMenuShortcut;
function DropdownMenuSub(param) {
    let { ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Sub"], {
        "data-slot": "dropdown-menu-sub",
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dropdown-menu.tsx",
        lineNumber: 198,
        columnNumber: 10
    }, this);
}
_c12 = DropdownMenuSub;
function DropdownMenuSubTrigger(param) {
    let { className, inset, children, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SubTrigger"], {
        "data-slot": "dropdown-menu-sub-trigger",
        "data-inset": inset,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("focus:bg-accent focus:text-accent-foreground data-[state=open]:bg-accent data-[state=open]:text-accent-foreground flex cursor-default items-center rounded-sm px-2 py-1.5 text-sm outline-hidden select-none data-[inset]:pl-8", className),
        ...props,
        children: [
            children,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRightIcon$3e$__["ChevronRightIcon"], {
                className: "ml-auto size-4"
            }, void 0, false, {
                fileName: "[project]/src/components/ui/dropdown-menu.tsx",
                lineNumber: 220,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/dropdown-menu.tsx",
        lineNumber: 210,
        columnNumber: 5
    }, this);
}
_c13 = DropdownMenuSubTrigger;
function DropdownMenuSubContent(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dropdown$2d$menu$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SubContent"], {
        "data-slot": "dropdown-menu-sub-content",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("bg-popover text-popover-foreground data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 min-w-[8rem] origin-(--radix-dropdown-menu-content-transform-origin) overflow-hidden rounded-md border p-1 shadow-lg", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dropdown-menu.tsx",
        lineNumber: 230,
        columnNumber: 5
    }, this);
}
_c14 = DropdownMenuSubContent;
;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13, _c14;
__turbopack_context__.k.register(_c, "DropdownMenu");
__turbopack_context__.k.register(_c1, "DropdownMenuPortal");
__turbopack_context__.k.register(_c2, "DropdownMenuTrigger");
__turbopack_context__.k.register(_c3, "DropdownMenuContent");
__turbopack_context__.k.register(_c4, "DropdownMenuGroup");
__turbopack_context__.k.register(_c5, "DropdownMenuItem");
__turbopack_context__.k.register(_c6, "DropdownMenuCheckboxItem");
__turbopack_context__.k.register(_c7, "DropdownMenuRadioGroup");
__turbopack_context__.k.register(_c8, "DropdownMenuRadioItem");
__turbopack_context__.k.register(_c9, "DropdownMenuLabel");
__turbopack_context__.k.register(_c10, "DropdownMenuSeparator");
__turbopack_context__.k.register(_c11, "DropdownMenuShortcut");
__turbopack_context__.k.register(_c12, "DropdownMenuSub");
__turbopack_context__.k.register(_c13, "DropdownMenuSubTrigger");
__turbopack_context__.k.register(_c14, "DropdownMenuSubContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/Icons.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "Icons": ()=>Icons
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
;
;
const Icons = {
    wrcLogo: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "95",
            height: "40",
            viewBox: "0 0 95 40",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M16.0964 10.3735V13.0572C16.0964 16.4182 13.3466 19.1679 9.98566 19.1679H6.12623C2.76526 19.1679 0.0154891 16.4182 0.0154891 13.0572V12.9204C0.00533852 12.8376 0 12.7532 0 12.6677V2.23384C0 1.08826 0.9373 0.150958 2.08288 0.150958C3.22848 0.150958 4.16575 1.08826 4.16575 2.23384V12.6677C4.16575 12.7705 4.15816 12.8716 4.14352 12.9706V13.1644C4.14352 14.1668 4.96366 14.9868 5.96602 14.9868H10.1459C11.1482 14.9868 11.9684 14.1668 11.9684 13.1644V9.92752H11.977V9.18952C11.977 5.77299 14.7722 2.97775 18.1887 2.97775C21.6052 2.97775 24.4005 5.77299 24.4005 9.18952V9.92752H24.4055V13.1644C24.4055 14.1668 25.2256 14.9868 26.228 14.9868H30.4078C31.4102 14.9868 32.2303 14.1668 32.2303 13.1644V5.6847H32.2281C32.2944 2.57143 34.8333 0.045166 37.9616 0.045166H56.5937C59.7634 0.045166 62.3568 2.63858 62.3568 5.80831C62.3568 8.97801 59.7634 11.5714 56.5937 11.5714H50.8906V11.5596H44.5398C43.6483 11.5596 42.9189 12.289 42.9189 13.1804C42.9189 14.0719 43.6483 14.8013 44.5398 14.8013H49.7959C49.8173 14.8005 49.8389 14.8001 49.8605 14.8001H60.2943C61.4399 14.8001 62.3772 15.7466 62.3772 16.9035C62.3772 18.0604 61.4399 19.0069 60.2943 19.0069H49.8605C49.6859 19.0069 49.5162 18.9849 49.3538 18.9435H44.5586C41.3888 18.9435 38.7954 16.3501 38.7954 13.1804C38.7954 10.0107 41.3888 7.41725 44.5586 7.41725H51.8133V7.42911H56.6125C57.5039 7.42911 58.2333 6.6997 58.2333 5.80824C58.2333 4.91678 57.5039 4.18735 56.6125 4.18735H38.0029C37.153 4.18735 36.4225 4.85033 36.3588 5.68463H36.3583V13.0571C36.3583 16.4181 33.6085 19.1679 30.2475 19.1679H26.3881C23.0271 19.1679 20.2774 16.4181 20.2774 13.0571V10.3734H20.2754V9.17311C20.2754 8.02546 19.3363 7.08647 18.1887 7.08647C17.041 7.08647 16.1021 8.02546 16.1021 9.17311V10.3734L16.0964 10.3735Z",
                    fill: "#FDFCFC"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 13,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M89.2664 19.0079H81.7028H70.1816C66.8206 19.0079 64.0708 16.2581 64.0708 12.8971V6.14321C64.0708 2.78225 66.8206 0.0324707 70.1816 0.0324707H81.7028H89.2664H92.1367C93.2822 0.0324707 94.2195 0.969749 94.2195 2.11535C94.2195 3.26095 93.2822 4.19823 92.1367 4.19823H81.7028C81.5683 4.19823 81.4367 4.18518 81.3091 4.16051H70.0744C69.072 4.16051 68.2519 4.98064 68.2519 5.98301V13.0573C68.2519 14.0597 69.072 14.8798 70.0744 14.8798H81.3091C81.4367 14.8552 81.5683 14.8421 81.7028 14.8421H92.1367C93.2822 14.8421 94.2195 15.7794 94.2195 16.925C94.2195 18.0706 93.2822 19.0079 92.1367 19.0079H89.2664Z",
                    fill: "#FDFCFC"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 19,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M1.76271 23.792H92.4638C93.3852 23.792 94.139 24.5439 94.139 25.463V32.0275C94.139 32.9465 93.3852 33.6984 92.4638 33.6984H1.76271C0.841352 33.6984 0.0874872 32.9465 0.0874872 32.0275V25.463C0.0874872 24.5439 0.841352 23.792 1.76271 23.792Z",
                    fill: "#FDFCFC"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 25,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M12.1069 26.8843V26.8856L12.0971 26.8859C10.7368 26.9314 10.7209 27.4956 10.7277 28.673C10.7218 28.697 10.7187 28.7223 10.7187 28.748V30.3419C10.7187 30.5149 10.8589 30.6553 11.0319 30.6553C11.2049 30.6553 11.3453 30.5149 11.3453 30.3419V29.037H15.6911V30.3419C15.6911 30.5149 15.8313 30.6553 16.0042 30.6553C16.1772 30.6553 16.3177 30.5149 16.3177 30.3419V28.9386C16.3361 28.8989 16.3464 28.8548 16.3465 28.8083L16.3471 28.7241C16.3543 27.5207 16.3575 26.9406 15.0081 26.8869C14.995 26.8852 14.9816 26.8843 14.9681 26.8843H12.1069ZM12.1069 27.5104V27.5112H14.9681L14.9816 27.5109C15.5465 27.5356 15.6838 27.7605 15.7152 28.2108C15.6997 28.2479 15.6911 28.2883 15.6911 28.331V28.4107H11.3522C11.3615 27.8226 11.4517 27.5351 12.1069 27.5104Z",
                    fill: "#171515"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 31,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M3.10731 28.7484C3.10731 28.7227 3.11036 28.6976 3.11625 28.6736C3.10944 27.4961 3.1255 26.9319 4.48579 26.8864L4.49559 26.8862V26.885H7.35677C7.52976 26.885 7.67006 27.0253 7.67006 27.1983C7.67006 27.3713 7.52976 27.5116 7.35677 27.5116H6.60604H4.49559V27.5108C3.84035 27.5355 3.75019 27.823 3.74087 28.4112H4.4506H5.99576C6.16876 28.4112 6.30907 28.5515 6.30907 28.7244C6.30907 28.8974 6.16876 29.0378 5.99576 29.0378H3.73393V30.3426C3.73393 30.5156 3.5936 30.6559 3.42062 30.6559C3.24761 30.6559 3.10731 30.5156 3.10731 30.3426L3.10731 28.7484Z",
                    fill: "#171515"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 37,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M29.3906 26.8804C29.1038 26.8804 28.8433 26.9975 28.6546 27.1861C28.466 27.3747 28.3489 27.635 28.3489 27.9218V29.5499C28.3489 29.8367 28.466 30.0969 28.6546 30.2856C28.8433 30.4742 29.1038 30.5913 29.3906 30.5913H32.9033C33.19 30.5913 33.4506 30.4742 33.6392 30.2856C33.8278 30.0969 33.945 29.8367 33.945 29.5499V27.9218C33.945 27.635 33.8278 27.3747 33.6392 27.1861C33.4506 26.9975 33.19 26.8804 32.9033 26.8804H29.3906ZM29.3906 27.507H32.9033C33.0171 27.507 33.121 27.5537 33.1963 27.629C33.2716 27.7043 33.3183 27.808 33.3183 27.9218V29.5499C33.3183 29.6637 33.2716 29.7674 33.1963 29.8427C33.121 29.918 33.0171 29.9647 32.9033 29.9647H29.3906C29.2768 29.9647 29.1728 29.918 29.0975 29.8427C29.0222 29.7674 28.9755 29.6637 28.9755 29.5499V27.9218C28.9755 27.808 29.0222 27.7043 29.0975 27.629C29.1728 27.5537 29.2768 27.507 29.3906 27.507Z",
                    fill: "#171515"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 43,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M49.2898 28.9006C49.2898 29.0736 49.1495 29.2139 48.9765 29.2139C48.8035 29.2139 48.6632 29.0736 48.6632 28.9006V27.922C48.6632 27.6351 48.7802 27.3747 48.9688 27.1861C49.1575 26.9975 49.418 26.8804 49.7047 26.8804H53.2176C53.5043 26.8804 53.7649 26.9975 53.9535 27.1861C54.1421 27.3747 54.2592 27.6351 54.2592 27.922V29.5499C54.2592 29.8366 54.1421 30.0971 53.9535 30.2857C53.7649 30.4744 53.5043 30.5915 53.2176 30.5915H48.9502C48.7772 30.5915 48.6369 30.4511 48.6369 30.2781C48.6369 30.1051 48.7772 29.9648 48.9502 29.9648H53.2176C53.3313 29.9648 53.4351 29.918 53.5105 29.8427C53.5858 29.7674 53.6326 29.6635 53.6326 29.5499V27.922C53.6326 27.8082 53.5858 27.7044 53.5105 27.6291C53.4351 27.5538 53.3313 27.507 53.2176 27.507H49.7047C49.5911 27.507 49.4872 27.5538 49.4119 27.6291C49.3366 27.7044 49.2898 27.8082 49.2898 27.922V28.9006Z",
                    fill: "#171515"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 49,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M41.9939 27.0098C41.9939 26.8368 42.1342 26.6965 42.3072 26.6965C42.4802 26.6965 42.6205 26.8368 42.6205 27.0098V29.5502C42.6205 29.6639 42.6674 29.7677 42.7427 29.843L42.755 29.8562C42.8284 29.9238 42.927 29.9652 43.0355 29.9652H47.3029C47.4759 29.9652 47.6162 30.1055 47.6162 30.2785C47.6162 30.4515 47.4759 30.5918 47.3029 30.5918H43.0355C42.7603 30.5918 42.5084 30.4828 42.3211 30.3057C42.3137 30.2995 42.3065 30.2929 42.2996 30.286C42.1111 30.0975 41.9939 29.8369 41.9939 29.5503L41.9939 27.0098Z",
                    fill: "#171515"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 55,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M22.6208 28.9882C22.6208 28.9717 22.622 28.9555 22.6245 28.9397V28.6361C22.6245 28.3367 22.7473 28.0636 22.9454 27.8652L22.9459 27.8644L22.9467 27.8639L22.9487 27.8619C23.147 27.6649 23.4192 27.543 23.7175 27.543C24.0184 27.543 24.2917 27.6659 24.4896 27.8639C24.6876 28.0618 24.8105 28.3351 24.8105 28.636V28.9713L24.8099 28.9874V28.9883V29.5265C24.8099 29.6402 24.8568 29.7439 24.9321 29.8193C25.0074 29.8946 25.1112 29.9414 25.2249 29.9414H26.0621C26.1758 29.9414 26.2796 29.8946 26.3549 29.8193C26.4302 29.7439 26.4771 29.6402 26.4771 29.5265V27.1605C26.4771 26.9875 26.6174 26.8472 26.7904 26.8472C26.9634 26.8472 27.1037 26.9875 27.1037 27.1605V29.5265C27.1037 29.8132 26.9865 30.0738 26.798 30.2623C26.6094 30.4508 26.3488 30.5681 26.0621 30.5681H25.2249C24.9382 30.5681 24.6776 30.4508 24.4891 30.2623C24.3005 30.0738 24.1833 29.8132 24.1833 29.5265V28.9883L24.1838 28.9721V28.9713V28.636C24.1838 28.5082 24.1312 28.3915 24.0466 28.3069C23.962 28.2223 23.8453 28.1696 23.7175 28.1696C23.5888 28.1696 23.4723 28.2217 23.3884 28.3056L23.3872 28.3068C23.3033 28.3907 23.2512 28.5072 23.2512 28.6359V28.9712C23.2512 28.9878 23.25 29.0039 23.2475 29.0198V29.5263C23.2475 29.8119 23.1302 30.0722 22.9411 30.2615L22.9419 30.2623C22.7533 30.4508 22.4927 30.5681 22.206 30.5681H21.3688C21.0821 30.5681 20.8215 30.4508 20.633 30.2623C20.4444 30.0737 20.3272 29.8132 20.3272 29.5265V27.1605C20.3272 26.9875 20.4675 26.8472 20.6405 26.8472C20.8135 26.8472 20.9538 26.9875 20.9538 27.1605V29.5265C20.9538 29.6402 21.0007 29.7439 21.076 29.8193C21.1513 29.8946 21.2551 29.9414 21.3688 29.9414H22.206C22.3197 29.9414 22.4235 29.8946 22.4988 29.8193L22.4994 29.8198L22.5002 29.8193C22.5748 29.7447 22.6211 29.641 22.6211 29.5265V28.9882L22.6208 28.9882Z",
                    fill: "#171515"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 61,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M66.4697 26.8843V26.8856L66.4599 26.8859C65.0996 26.9314 65.0836 27.4956 65.0904 28.673C65.0846 28.697 65.0815 28.7223 65.0814 28.748V30.3419C65.0814 30.5149 65.2216 30.6553 65.3946 30.6553C65.5676 30.6553 65.7081 30.5149 65.7081 30.3419V29.037H70.0538V30.3419C70.0538 30.5149 70.194 30.6553 70.367 30.6553C70.54 30.6553 70.6804 30.5149 70.6804 30.3419V28.9386C70.6989 28.8989 70.7092 28.8548 70.7093 28.8083L70.7098 28.7241C70.7171 27.5207 70.7202 26.9406 69.3708 26.8869C69.3577 26.8852 69.3444 26.8843 69.3308 26.8843H66.4697ZM66.4697 27.5104V27.5112H69.3308L69.3444 27.5109C69.9093 27.5356 70.0463 27.7605 70.0776 28.2108C70.0622 28.2479 70.0538 28.2883 70.0538 28.331V28.4107H65.7149C65.7243 27.8226 65.8144 27.5351 66.4697 27.5104Z",
                    fill: "#171515"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 67,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M72.0868 27.0098C72.0868 26.8368 72.2272 26.6965 72.4001 26.6965C72.5731 26.6965 72.7135 26.8368 72.7135 27.0098V29.5502C72.7135 29.6648 72.7598 29.7685 72.8344 29.843L72.8356 29.8442C72.9101 29.9188 73.0138 29.9652 73.1284 29.9652H77.3958C77.5688 29.9652 77.7091 30.1055 77.7091 30.2785C77.7091 30.4514 77.5688 30.5918 77.3958 30.5918H73.1284C72.8444 30.5918 72.5851 30.4756 72.3961 30.2883L72.3938 30.286L72.393 30.2855L72.3922 30.2847C72.2035 30.0955 72.0865 29.8352 72.0865 29.5501V27.0097L72.0868 27.0098Z",
                    fill: "#171515"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 73,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M78.6601 27.0098C78.6601 26.8368 78.8004 26.6965 78.9734 26.6965C79.1464 26.6965 79.2867 26.8368 79.2867 27.0098V29.5502C79.2867 29.6639 79.3336 29.7677 79.4089 29.843L79.4212 29.8562C79.4946 29.9238 79.5932 29.9652 79.7017 29.9652H83.9691C84.1421 29.9652 84.2824 30.1055 84.2824 30.2785C84.2824 30.4515 84.1421 30.5918 83.9691 30.5918H79.7017C79.4265 30.5918 79.1746 30.4828 78.9873 30.3057C78.9799 30.2995 78.9727 30.2929 78.9658 30.286C78.7773 30.0975 78.6601 29.8369 78.6601 29.5503L78.6601 27.0098Z",
                    fill: "#171515"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 79,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M90.4525 27.0098C90.4525 26.8368 90.5928 26.6965 90.7658 26.6965C90.9388 26.6965 91.0791 26.8368 91.0791 27.0098V29.5502C91.0791 29.8369 90.9619 30.0975 90.7733 30.286C90.7664 30.2929 90.7593 30.2995 90.7519 30.3057C90.5646 30.4828 90.3128 30.5918 90.0375 30.5918H85.7701C85.5971 30.5918 85.4568 30.4515 85.4568 30.2785C85.4568 30.1055 85.5971 29.9652 85.7701 29.9652H90.0375C90.1459 29.9652 90.2445 29.9238 90.318 29.8562L90.3303 29.843C90.4056 29.7677 90.4525 29.6639 90.4525 29.5502V29.0956H86.4623C86.1756 29.0956 85.915 28.9784 85.7265 28.7899C85.5379 28.6013 85.4207 28.3407 85.4207 28.054V27.0098C85.4207 26.8368 85.561 26.6965 85.734 26.6965C85.907 26.6965 86.0473 26.8368 86.0473 27.0098V28.054C86.0473 28.1677 86.0942 28.2715 86.1695 28.3468C86.2448 28.4221 86.3486 28.469 86.4623 28.469H90.4525V27.0098Z",
                    fill: "#171515"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 85,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M35.9111 30.2437C35.9111 30.4167 35.7708 30.557 35.5978 30.557C35.4248 30.557 35.2845 30.4167 35.2845 30.2437V27.922C35.2845 27.6351 35.4016 27.3747 35.5902 27.1861C35.7788 26.9975 36.0393 26.8804 36.3261 26.8804H39.839C40.1266 26.8804 40.3883 26.9988 40.5777 27.1921C40.7645 27.3828 40.8806 27.6454 40.8806 27.937C40.8806 28.2287 40.7645 28.4912 40.5777 28.6819C40.3883 28.8752 40.1266 28.9936 39.839 28.9936V28.9924L38.6864 28.9952L37.5339 28.998V28.9992C37.4193 28.9992 37.3154 29.046 37.2406 29.1224C37.1656 29.199 37.1189 29.307 37.1189 29.4292C37.1189 29.5514 37.1655 29.6594 37.2406 29.7361C37.3154 29.8124 37.4193 29.8593 37.5339 29.8593H40.5609C40.7339 29.8593 40.8742 29.9996 40.8742 30.1726C40.8742 30.3456 40.7339 30.4859 40.5609 30.4859H37.5339C37.2464 30.4859 36.9845 30.3674 36.7951 30.1741C36.6083 29.9834 36.4923 29.7209 36.4923 29.4292C36.4923 29.1376 36.6083 28.875 36.7951 28.6843C36.9845 28.491 37.2462 28.3726 37.5339 28.3726V28.3738L38.6864 28.371L39.839 28.3683V28.3671C39.9535 28.3671 40.0574 28.3202 40.1322 28.2439C40.2073 28.1673 40.2539 28.0592 40.2539 27.937C40.2539 27.8148 40.2073 27.7068 40.1322 27.6302C40.0574 27.5538 39.9535 27.507 39.839 27.507H36.3261C36.2123 27.507 36.1085 27.5538 36.0333 27.6291C35.9579 27.7044 35.9111 27.8082 35.9111 27.922V30.2437Z",
                    fill: "#171515"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 91,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M58.881 30.2437C58.881 30.4167 58.7407 30.557 58.5677 30.557C58.3947 30.557 58.2544 30.4167 58.2544 30.2437V27.922C58.2544 27.6351 58.3715 27.3747 58.5601 27.1861C58.7487 26.9975 59.0092 26.8804 59.296 26.8804H62.8089C63.0965 26.8804 63.3583 26.9988 63.5476 27.1921C63.7344 27.3828 63.8504 27.6454 63.8504 27.937C63.8504 28.2287 63.7344 28.4912 63.5476 28.6819C63.3583 28.8752 63.0965 28.9936 62.8089 28.9936V28.9924L61.6563 28.9952L60.5038 28.998V28.9992C60.3892 28.9992 60.2853 29.046 60.2105 29.1224C60.1355 29.199 60.0888 29.307 60.0888 29.4292C60.0888 29.5514 60.1354 29.6594 60.2105 29.7361C60.2853 29.8124 60.3892 29.8593 60.5038 29.8593H63.5308C63.7038 29.8593 63.8441 29.9996 63.8441 30.1726C63.8441 30.3456 63.7038 30.4859 63.5308 30.4859H60.5038C60.2163 30.4859 59.9544 30.3674 59.765 30.1741C59.5782 29.9834 59.4622 29.7209 59.4622 29.4292C59.4622 29.1376 59.5782 28.875 59.765 28.6843C59.9544 28.491 60.2161 28.3726 60.5038 28.3726V28.3738L61.6563 28.371L62.8089 28.3683V28.3671C62.9234 28.3671 63.0273 28.3202 63.1021 28.2439C63.1772 28.1673 63.2238 28.0592 63.2238 27.937C63.2238 27.8148 63.1772 27.7068 63.1021 27.6302C63.0273 27.5538 62.9234 27.507 62.8089 27.507H59.296C59.1822 27.507 59.0785 27.5538 59.0032 27.6291C58.9279 27.7044 58.881 27.8082 58.881 27.922V30.2437Z",
                    fill: "#171515"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 97,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M11.3462 36.3491C11.3462 36.2127 11.4568 36.1021 11.5932 36.1021C11.7296 36.1021 11.8402 36.2127 11.8402 36.3491V37.322H15.1529V36.3491C15.1529 36.2127 15.2635 36.1021 15.3999 36.1021C15.5363 36.1021 15.6469 36.2127 15.6469 36.3491V38.7889C15.6469 38.9253 15.5363 39.0359 15.3999 39.0359C15.2635 39.0359 15.1529 38.9253 15.1529 38.7889V37.816H11.8402V38.7889C11.8402 38.9253 11.7296 39.0359 11.5932 39.0359C11.4568 39.0359 11.3462 38.9253 11.3462 38.7889V36.3491Z",
                    fill: "#FDFCFC"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 103,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M20.6465 36.062V36.0628L20.6389 36.0631C19.5663 36.099 19.5536 36.5439 19.559 37.4722C19.5544 37.4912 19.5519 37.5109 19.5519 37.5312H19.5522V38.7884C19.5522 38.9249 19.6628 39.0354 19.7991 39.0354C19.9356 39.0354 20.0461 38.9249 20.0461 38.7884V37.7594H23.4728V38.7884C23.4728 38.9249 23.5834 39.0354 23.7198 39.0354C23.8562 39.0354 23.9667 38.9249 23.9667 38.7884V37.6819C23.9812 37.6507 23.9894 37.6158 23.9895 37.5792L23.9898 37.513C23.9956 36.5637 23.9982 36.1063 22.9333 36.0641C22.9233 36.0627 22.9129 36.062 22.9025 36.062H20.6465ZM20.6465 36.5552V36.556H22.9025L22.9131 36.5557C23.3587 36.5752 23.4669 36.7527 23.4916 37.108C23.4793 37.1371 23.4728 37.1691 23.4728 37.2027V37.2655H20.0517V37.2652C20.059 36.8014 20.1298 36.5746 20.6465 36.5552Z",
                    fill: "#FDFCFC"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 109,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M7.33975 38.4911C7.47615 38.4911 7.58677 38.6017 7.58677 38.7381C7.58677 38.8745 7.47615 38.9852 7.33975 38.9852H4.0432C3.81714 38.9852 3.6117 38.8928 3.463 38.7441C3.3143 38.5954 3.22194 38.39 3.22194 38.164V36.8803C3.22194 36.6551 3.31442 36.4499 3.4635 36.3007L3.463 36.3001C3.6117 36.1514 3.81714 36.0591 4.0432 36.0591H7.33975C7.47615 36.0591 7.58677 36.1697 7.58677 36.3061C7.58677 36.4425 7.47615 36.5531 7.33975 36.5531H4.0432C3.95348 36.5531 3.87157 36.5901 3.81225 36.6494L3.81175 36.6488L3.81125 36.6494C3.7525 36.7081 3.71591 36.7899 3.71591 36.8803V38.1639C3.71591 38.2536 3.75285 38.3355 3.81217 38.3948C3.8715 38.4541 3.9534 38.4911 4.04313 38.4911L7.33975 38.4911Z",
                    fill: "#FDFCFC"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 115,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M31.2983 37.2791C31.2983 37.2921 31.2973 37.3049 31.2953 37.3175V37.5568C31.2953 37.7939 31.1983 38.0096 31.0423 38.1656C31.0371 38.1707 31.0318 38.1757 31.0263 38.1803C30.8711 38.3278 30.6621 38.4186 30.4336 38.4186C30.1964 38.4186 29.9808 38.3216 29.8248 38.1656C29.8197 38.1605 29.8149 38.1553 29.8103 38.1499C29.6628 37.9951 29.5718 37.7859 29.5718 37.5568V37.2924L29.5723 37.2796V37.2791V36.8547C29.5723 36.7645 29.5358 36.6827 29.4769 36.6239L29.4759 36.6229C29.4171 36.564 29.3353 36.5275 29.245 36.5275H28.5849C28.4952 36.5275 28.4133 36.5645 28.354 36.6238C28.2947 36.6832 28.2577 36.765 28.2577 36.8547V38.7203C28.2577 38.8567 28.1471 38.9673 28.0106 38.9673C27.8742 38.9673 27.7636 38.8567 27.7636 38.7203V36.8547C27.7636 36.6287 27.856 36.4233 28.0047 36.2746C28.1534 36.1259 28.3589 36.0334 28.5849 36.0334H29.245C29.4697 36.0334 29.6747 36.1256 29.8238 36.2742L29.8244 36.2747L29.8249 36.2752L29.8255 36.2758C29.9744 36.4249 30.0666 36.6301 30.0666 36.855V37.2793L30.0663 37.292V37.2926V37.557C30.0663 37.6533 30.1037 37.7414 30.1646 37.8072L30.1745 37.8165C30.2412 37.8832 30.3333 37.9247 30.434 37.9247C30.5306 37.9247 30.6186 37.8874 30.6838 37.8268L30.6936 37.8165C30.7603 37.7498 30.8018 37.6579 30.8018 37.557V37.2926C30.8018 37.2795 30.8027 37.2667 30.8047 37.2541V36.8549C30.8047 36.6289 30.8971 36.4235 31.0458 36.2748C31.1945 36.1261 31.4 36.0337 31.626 36.0337H32.2862C32.5122 36.0337 32.7176 36.1261 32.8663 36.2748C33.015 36.4235 33.1074 36.6289 33.1074 36.8549V38.7205C33.1074 38.8569 32.9968 38.9675 32.8604 38.9675C32.7239 38.9675 32.6133 38.8569 32.6133 38.7205V36.8549C32.6133 36.7652 32.5764 36.6834 32.5171 36.6241C32.4577 36.5647 32.3758 36.5277 32.2862 36.5277H31.626C31.5363 36.5277 31.4544 36.5647 31.3951 36.6241C31.3357 36.6834 31.2988 36.7653 31.2988 36.8549V37.2793L31.2983 37.2791Z",
                    fill: "#FDFCFC"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 121,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M37.3895 38.711C37.3895 38.8474 37.2789 38.958 37.1425 38.958C37.0061 38.958 36.8955 38.8474 36.8955 38.711V36.8803C36.8955 36.6551 36.988 36.4499 37.137 36.3007L37.1365 36.3001C37.2852 36.1514 37.4907 36.0591 37.7167 36.0591H40.4865C40.7134 36.0591 40.9197 36.1525 41.069 36.3048C41.2164 36.4552 41.3078 36.6622 41.3078 36.8921C41.3078 37.1221 41.2163 37.3291 41.069 37.4795C40.9197 37.6319 40.7133 37.7253 40.4865 37.7253V37.7243L39.5777 37.7266L38.1961 37.7288C38.0603 37.7288 37.9501 37.6186 37.9501 37.4828C37.9501 37.347 38.0603 37.2368 38.1961 37.2368L39.5777 37.2345L40.4865 37.2323V37.2313C40.5768 37.2313 40.6588 37.1944 40.7178 37.1342C40.777 37.0738 40.8137 36.9886 40.8137 36.8922C40.8137 36.7959 40.777 36.7107 40.7178 36.6503C40.6587 36.5901 40.5768 36.5532 40.4865 36.5532H37.7167C37.627 36.5532 37.5451 36.5901 37.4857 36.6495L37.4852 36.6489L37.4847 36.6495C37.4259 36.7082 37.3893 36.79 37.3893 36.8804V38.711L37.3895 38.711Z",
                    fill: "#FDFCFC"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 127,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M87.0582 38.711C87.0582 38.8474 86.9475 38.958 86.8111 38.958C86.6747 38.958 86.5641 38.8474 86.5641 38.711V36.8803C86.5641 36.6551 86.6566 36.4499 86.8056 36.3007L86.8051 36.3001C86.9538 36.1514 87.1593 36.0591 87.3853 36.0591H90.1551C90.382 36.0591 90.5883 36.1525 90.7376 36.3048C90.885 36.4552 90.9764 36.6622 90.9764 36.8921C90.9764 37.1221 90.8849 37.3291 90.7376 37.4795C90.5884 37.6319 90.3819 37.7253 90.1551 37.7253V37.7243L89.2463 37.7266L87.9503 37.7288C87.8145 37.7288 87.7043 37.6186 87.7043 37.4828C87.7043 37.347 87.8145 37.2368 87.9503 37.2368L89.2463 37.2345L90.1551 37.2323V37.2313C90.2454 37.2313 90.3274 37.1944 90.3864 37.1342C90.4456 37.0738 90.4824 36.9886 90.4824 36.8922C90.4824 36.7959 90.4456 36.7107 90.3864 36.6503C90.3273 36.5901 90.2454 36.5532 90.1551 36.5532H87.3853C87.2956 36.5532 87.2137 36.5901 87.1544 36.6495L87.1538 36.6489L87.1533 36.6495C87.0945 36.7082 87.0579 36.79 87.0579 36.8804V38.711L87.0582 38.711Z",
                    fill: "#FDFCFC"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 133,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M45.0831 36.3491C45.0831 36.2127 45.1937 36.1021 45.3301 36.1021C45.4665 36.1021 45.5771 36.2127 45.5771 36.3491V38.7889C45.5771 38.9253 45.4665 39.0359 45.3301 39.0359C45.1937 39.0359 45.0831 38.9253 45.0831 38.7889V36.3491Z",
                    fill: "#FDFCFC"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 139,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M50.2273 36.0591C50.0013 36.0591 49.7958 36.1513 49.6471 36.3L49.6476 36.3005C49.4985 36.4497 49.4062 36.6551 49.4062 36.8803V38.1639C49.4062 38.39 49.4986 38.5953 49.6473 38.7439C49.796 38.8926 50.0013 38.9851 50.2273 38.9851H51.6206H53.0136C53.2397 38.9851 53.4452 38.8926 53.5939 38.7439C53.7426 38.5953 53.835 38.39 53.835 38.1639V36.8803C53.835 36.6627 53.7486 36.4636 53.6084 36.3159C53.6039 36.3104 53.599 36.3051 53.5939 36.3C53.4452 36.1513 53.2397 36.0591 53.0136 36.0591H51.6206H50.2273ZM50.2273 36.5531H51.6206H53.0139C53.1036 36.5531 53.1854 36.5901 53.2447 36.6494L53.2545 36.6587C53.3081 36.7167 53.3411 36.7945 53.3411 36.8803V38.1639C53.3411 38.2537 53.304 38.3354 53.2447 38.3948C53.1854 38.4541 53.1036 38.4911 53.0139 38.4911H51.6206H50.2273C50.1376 38.4911 50.0556 38.4541 49.9962 38.3948C49.9369 38.3354 49.9001 38.2537 49.9001 38.1639V36.8803C49.9001 36.7899 49.9367 36.7082 49.9954 36.6494L49.996 36.6489L49.9965 36.6494C50.0558 36.5901 50.1376 36.5531 50.2273 36.5531Z",
                    fill: "#FDFCFC"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 145,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M74.0745 36.3491C74.0745 36.2127 74.1852 36.1021 74.3216 36.1021C74.458 36.1021 74.5686 36.2127 74.5686 36.3491V37.322H77.8812V36.3491C77.8812 36.2127 77.9919 36.1021 78.1283 36.1021C78.2647 36.1021 78.3753 36.2127 78.3753 36.3491V38.7889C78.3753 38.9253 78.2647 39.0359 78.1283 39.0359C77.9919 39.0359 77.8812 38.9253 77.8812 38.7889V37.816H74.5686V38.7889C74.5686 38.9253 74.458 39.0359 74.3216 39.0359C74.1852 39.0359 74.0745 38.9253 74.0745 38.7889V36.3491Z",
                    fill: "#FDFCFC"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 151,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M82.3134 36.3491C82.3134 36.2127 82.424 36.1021 82.5604 36.1021C82.6968 36.1021 82.8075 36.2127 82.8075 36.3491V38.7889C82.8075 38.9253 82.6968 39.0359 82.5604 39.0359C82.424 39.0359 82.3134 38.9253 82.3134 38.7889V36.3491Z",
                    fill: "#FDFCFC"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 157,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M70.1686 36.0593C70.305 36.0593 70.4156 36.1699 70.4156 36.3063C70.4156 36.4427 70.305 36.5533 70.1686 36.5533H66.7264C66.6361 36.5533 66.5541 36.5904 66.4951 36.6505C66.4359 36.7108 66.3992 36.796 66.3992 36.8924C66.3992 36.9887 66.4359 37.0739 66.4951 37.1343C66.5541 37.1945 66.6361 37.2315 66.7264 37.2315C66.7345 37.2315 66.7425 37.232 66.7504 37.2324L69.5953 37.2539H69.5981C69.8245 37.2578 70.0302 37.3511 70.1781 37.502C70.3247 37.6517 70.4156 37.8565 70.4156 38.0861C70.4156 38.3161 70.3241 38.5231 70.1768 38.6734C70.0275 38.8257 69.8211 38.9191 69.5943 38.9191H66.1521C66.0156 38.9191 65.905 38.8085 65.905 38.6721C65.905 38.5357 66.0156 38.4251 66.1521 38.4251H69.5943C69.6846 38.4251 69.7665 38.3882 69.8256 38.328C69.8847 38.2676 69.9215 38.1824 69.9215 38.0861C69.9215 37.9907 69.8852 37.9071 69.8268 37.8475C69.7664 37.7857 69.6824 37.7475 69.5905 37.746L66.7467 37.7245C66.74 37.725 66.7332 37.7253 66.7264 37.7253C66.4996 37.7253 66.2931 37.6319 66.1439 37.4795C65.9966 37.3291 65.9051 37.1221 65.9051 36.8921C65.9051 36.6622 65.9965 36.4552 66.1439 36.3048C66.2932 36.1525 66.4996 36.0591 66.7264 36.0591H70.1686V36.0593Z",
                    fill: "#FDFCFC"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 163,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M58.118 38.7196C58.118 38.8561 58.0074 38.9667 57.8709 38.9667C57.7345 38.9667 57.6239 38.8561 57.6239 38.7196V36.8541C57.6239 36.6281 57.7163 36.4226 57.865 36.2739C57.8702 36.2688 57.8756 36.2638 57.8811 36.2592C58.0286 36.1192 58.2275 36.0328 58.4452 36.0328H59.3593C59.5853 36.0328 59.7908 36.1252 59.9395 36.2739C60.0882 36.4226 60.1806 36.6281 60.1806 36.8541C60.1806 36.861 60.1803 36.8679 60.1798 36.8747L60.1838 37.4987L60.1879 38.1444V38.1453H60.1888C60.1888 38.235 60.2259 38.3169 60.2852 38.3762C60.3445 38.4355 60.4264 38.4726 60.5161 38.4726H61.1762C61.2659 38.4726 61.3478 38.436 61.4071 38.3771L61.4081 38.3762C61.4669 38.3169 61.5035 38.2351 61.5035 38.1453V36.2797C61.5035 36.1433 61.6141 36.0327 61.7505 36.0327C61.8869 36.0327 61.9975 36.1433 61.9975 36.2797V38.1453C61.9975 38.3706 61.9051 38.5757 61.7564 38.7245L61.7554 38.7255C61.6067 38.8742 61.4015 38.9666 61.1762 38.9666H60.5161C60.2901 38.9666 60.0846 38.8742 59.9359 38.7255C59.7872 38.5768 59.6948 38.3713 59.6948 38.1453H59.6957L59.6916 37.5006L59.6877 36.8777C59.6868 36.8699 59.6864 36.862 59.6864 36.854C59.6864 36.7643 59.6494 36.6824 59.5901 36.6231C59.5308 36.5638 59.4489 36.5268 59.3592 36.5268H58.4451C58.3596 36.5268 58.2814 36.5599 58.223 36.6138L58.2142 36.6231C58.1549 36.6824 58.1178 36.7643 58.1178 36.854V38.7196L58.118 38.7196Z",
                    fill: "#FDFCFC"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 169,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M8.77587 27.2481C8.77587 27.0751 8.91618 26.9348 9.08919 26.9348C9.26217 26.9348 9.40247 27.0751 9.40247 27.2481V30.3424C9.40247 30.5154 9.26217 30.6557 9.08919 30.6557C8.91618 30.6557 8.77587 30.5154 8.77587 30.3424V27.2481Z",
                    fill: "#171515"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 175,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Icons.tsx",
            lineNumber: 6,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0)),
    oilLogo: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: 96,
            height: 55,
            viewBox: "0 0 96 55",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            xmlnsXlink: "http://www.w3.org/1999/xlink",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("mask", {
                    id: "mask0_139_597",
                    style: {
                        maskType: "alpha"
                    },
                    maskUnits: "userSpaceOnUse",
                    x: 0,
                    y: 0,
                    width: 96,
                    height: 55,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: "M88.2881 53.9668H43.4675H11.9362C6.02414 53.9668 4.05345 54.573 1.6786 52.1981C-0.0900275 50.4295 0.314509 47.3977 0.314509 44.9217C0.314509 42.4457 0.264871 23.4967 0.264871 19.5554C0.264871 15.614 -0.189868 13.0874 1.78083 11.1167C3.75152 9.14604 5.31797 9.3987 9.10777 9.3987H25.5302C28.7137 6.23209 35.9373 0 48.47 0C61.0027 0 68.5318 7.78166 70.4014 9.3987H84.6005C90.6642 9.3987 92.1802 9.04498 94.1508 11.0157C95.7274 12.5922 95.514 14.3507 95.514 15.614V41.6373C95.514 49.2674 96.1215 49.9748 94.3024 52.0971C92.7976 53.8527 91.9275 53.9668 88.2881 53.9668Z",
                        fill: "#D9D9D9"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Icons.tsx",
                        lineNumber: 202,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 193,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                    mask: "url(#mask0_139_597)",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                        x: "-12.7195",
                        y: "-11.1169",
                        width: "121.274",
                        height: "80.849",
                        fill: "url(#pattern0_139_597)"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Icons.tsx",
                        lineNumber: 208,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 207,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("pattern", {
                            id: "pattern0_139_597",
                            patternContentUnits: "objectBoundingBox",
                            width: 1,
                            height: 1,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("use", {
                                xlinkHref: "#image0_139_597",
                                transform: "scale(0.000833333 0.00125)"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Icons.tsx",
                                lineNumber: 223,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/components/Icons.tsx",
                            lineNumber: 217,
                            columnNumber: 9
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("image", {
                            id: "image0_139_597",
                            width: 1200,
                            height: 800,
                            preserveAspectRatio: "none",
                            xlinkHref: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABLAAAAMgCAIAAAC8ggxVAAAKN2lDQ1BzUkdCIElFQzYxOTY2LTIuMQAAeJydlndUU9kWh8+9N71QkhCKlNBraFICSA29SJEuKjEJEErAkAAiNkRUcERRkaYIMijggKNDkbEiioUBUbHrBBlE1HFwFBuWSWStGd+8ee/Nm98f935rn73P3Wfvfda6AJD8gwXCTFgJgAyhWBTh58WIjYtnYAcBDPAAA2wA4HCzs0IW+EYCmQJ82IxsmRP4F726DiD5+yrTP4zBAP+flLlZIjEAUJiM5/L42VwZF8k4PVecJbdPyZi2NE3OMErOIlmCMlaTc/IsW3z2mWUPOfMyhDwZy3PO4mXw5Nwn4405Er6MkWAZF+cI+LkyviZjg3RJhkDGb+SxGXxONgAoktwu5nNTZGwtY5IoMoIt43kA4EjJX/DSL1jMzxPLD8XOzFouEiSniBkmXFOGjZMTi+HPz03ni8XMMA43jSPiMdiZGVkc4XIAZs/8WRR5bRmyIjvYODk4MG0tbb4o1H9d/JuS93aWXoR/7hlEH/jD9ld+mQ0AsKZltdn6h21pFQBd6wFQu/2HzWAvAIqyvnUOfXEeunxeUsTiLGcrq9zcXEsBn2spL+jv+p8Of0NffM9Svt3v5WF485M4knQxQ143bmZ6pkTEyM7icPkM5p+H+B8H/nUeFhH8JL6IL5RFRMumTCBMlrVbyBOIBZlChkD4n5r4D8P+pNm5lona+BHQllgCpSEaQH4eACgqESAJe2Qr0O99C8ZHA/nNi9GZmJ37z4L+fVe4TP7IFiR/jmNHRDK4ElHO7Jr8WgI0IABFQAPqQBvoAxPABLbAEbgAD+ADAkEoiARxYDHgghSQAUQgFxSAtaAYlIKtYCeoBnWgETSDNnAYdIFj4DQ4By6By2AE3AFSMA6egCnwCsxAEISFyBAVUod0IEPIHLKFWJAb5AMFQxFQHJQIJUNCSAIVQOugUqgcqobqoWboW+godBq6AA1Dt6BRaBL6FXoHIzAJpsFasBFsBbNgTzgIjoQXwcnwMjgfLoK3wJVwA3wQ7oRPw5fgEVgKP4GnEYAQETqiizARFsJGQpF4JAkRIauQEqQCaUDakB6kH7mKSJGnyFsUBkVFMVBMlAvKHxWF4qKWoVahNqOqUQdQnag+1FXUKGoK9RFNRmuizdHO6AB0LDoZnYsuRlegm9Ad6LPoEfQ4+hUGg6FjjDGOGH9MHCYVswKzGbMb0445hRnGjGGmsVisOtYc64oNxXKwYmwxtgp7EHsSewU7jn2DI+J0cLY4X1w8TogrxFXgWnAncFdwE7gZvBLeEO+MD8Xz8MvxZfhGfA9+CD+OnyEoE4wJroRIQiphLaGS0EY4S7hLeEEkEvWITsRwooC4hlhJPEQ8TxwlviVRSGYkNimBJCFtIe0nnSLdIr0gk8lGZA9yPFlM3kJuJp8h3ye/UaAqWCoEKPAUVivUKHQqXFF4pohXNFT0VFysmK9YoXhEcUjxqRJeyUiJrcRRWqVUo3RU6YbStDJV2UY5VDlDebNyi/IF5UcULMWI4kPhUYoo+yhnKGNUhKpPZVO51HXURupZ6jgNQzOmBdBSaaW0b2iDtCkVioqdSrRKnkqNynEVKR2hG9ED6On0Mvph+nX6O1UtVU9Vvuom1TbVK6qv1eaoeajx1UrU2tVG1N6pM9R91NPUt6l3qd/TQGmYaYRr5Grs0Tir8XQObY7LHO6ckjmH59zWhDXNNCM0V2ju0xzQnNbS1vLTytKq0jqj9VSbru2hnaq9Q/uE9qQOVcdNR6CzQ+ekzmOGCsOTkc6oZPQxpnQ1df11Jbr1uoO6M3rGelF6hXrtevf0Cfos/ST9Hfq9+lMGOgYhBgUGrQa3DfGGLMMUw12G/YavjYyNYow2GHUZPTJWMw4wzjduNb5rQjZxN1lm0mByzRRjyjJNM91tetkMNrM3SzGrMRsyh80dzAXmu82HLdAWThZCiwaLG0wS05OZw2xljlrSLYMtCy27LJ9ZGVjFW22z6rf6aG1vnW7daH3HhmITaFNo02Pzq62ZLde2xvbaXPJc37mr53bPfW5nbse322N3055qH2K/wb7X/oODo4PIoc1h0tHAMdGx1vEGi8YKY21mnXdCO3k5rXY65vTW2cFZ7HzY+RcXpkuaS4vLo3nG8/jzGueNueq5clzrXaVuDLdEt71uUnddd457g/sDD30PnkeTx4SnqWeq50HPZ17WXiKvDq/XbGf2SvYpb8Tbz7vEe9CH4hPlU+1z31fPN9m31XfKz95vhd8pf7R/kP82/xsBWgHcgOaAqUDHwJWBfUGkoAVB1UEPgs2CRcE9IXBIYMj2kLvzDecL53eFgtCA0O2h98KMw5aFfR+OCQ8Lrwl/GGETURDRv4C6YMmClgWvIr0iyyLvRJlESaJ6oxWjE6Kbo1/HeMeUx0hjrWJXxl6K04gTxHXHY+Oj45vipxf6LNy5cDzBPqE44foi40V5iy4s1licvvj4EsUlnCVHEtGJMYktie85oZwGzvTSgKW1S6e4bO4u7hOeB28Hb5Lvyi/nTyS5JpUnPUp2Td6ePJninlKR8lTAFlQLnqf6p9alvk4LTduf9ik9Jr09A5eRmHFUSBGmCfsytTPzMoezzLOKs6TLnJftXDYlChI1ZUPZi7K7xTTZz9SAxESyXjKa45ZTk/MmNzr3SJ5ynjBvYLnZ8k3LJ/J9879egVrBXdFboFuwtmB0pefK+lXQqqWrelfrry5aPb7Gb82BtYS1aWt/KLQuLC98uS5mXU+RVtGaorH1futbixWKRcU3NrhsqNuI2ijYOLhp7qaqTR9LeCUXS61LK0rfb+ZuvviVzVeVX33akrRlsMyhbM9WzFbh1uvb3LcdKFcuzy8f2x6yvXMHY0fJjpc7l+y8UGFXUbeLsEuyS1oZXNldZVC1tep9dUr1SI1XTXutZu2m2te7ebuv7PHY01anVVda926vYO/Ner/6zgajhop9mH05+x42Rjf2f836urlJo6m06cN+4X7pgYgDfc2Ozc0tmi1lrXCrpHXyYMLBy994f9Pdxmyrb6e3lx4ChySHHn+b+O31w0GHe4+wjrR9Z/hdbQe1o6QT6lzeOdWV0iXtjusePhp4tLfHpafje8vv9x/TPVZzXOV42QnCiaITn07mn5w+lXXq6enk02O9S3rvnIk9c60vvG/wbNDZ8+d8z53p9+w/ed71/LELzheOXmRd7LrkcKlzwH6g4wf7HzoGHQY7hxyHui87Xe4Znjd84or7ldNXva+euxZw7dLI/JHh61HXb95IuCG9ybv56Fb6ree3c27P3FlzF3235J7SvYr7mvcbfjT9sV3qID0+6j068GDBgztj3LEnP2X/9H686CH5YcWEzkTzI9tHxyZ9Jy8/Xvh4/EnWk5mnxT8r/1z7zOTZd794/DIwFTs1/lz0/NOvm1+ov9j/0u5l73TY9P1XGa9mXpe8UX9z4C3rbf+7mHcTM7nvse8rP5h+6PkY9PHup4xPn34D94Tz+49wZioAAAAJcEhZcwAADsMAAA7DAcdvqGQAACAASURBVHic7N0HfBvlwcdxTUuW95D3dnaYZYVAC2FvKIUAhTDKKquFlhbKCIVSKGVDFythFSh7h/ECYYe9EkLs2I73kCxbe570PrpLhOKVZVu29ft+Ulc+nU6PpdPx/PUsXSQSUQEAAAAAko8u0QUAAAAAACQGgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAAAACSFIEQAAAAAJIUgRAAAAAAkhSBEAAwxUWEwRvD4fjNapn4vwG7aQZtAQBgKiEQAgAmmUhkfcQLBALiRjAYDIfDoVAoLAsGAiLXhSVJbInurVZH75KkAQcJKhs35D3xf3q9Xj0o/ulTUpRNao1G7CAfT52SkqKS99doNNoNdDqdWrU+WY7hHw8AwKgiEAIAJqKQTIS9+J+CpNyQ45yIf6oN+TCWEpWNA1LZEBFtyNg2qCkxstGdEVWsLVGlEmkw9qtCRESRC/UykQ9FbhRBUbmt/FQeAgDAxEEgBAAkjNK+Fwt7fllA/AsEJDnvyf9bH/xiBoa9WCuffENksK0v0KCUOEJjX3z+VIhix7YrNzQxWq34IUKhwWgUQdEgpKToU1KUrLhNZQYAYBsQCAEA4ySW/Xw+n1cWDATEFpH9lG6fA6Jd7PZEblgb3EF0wBYRC6OdV+X+qz6VyuFwxO6KdjNVaLUiKJpSU41Go7ixYRspEQAw5giEAIDRF1GpJDnpiezn8XhE9vP7fP5AQEmAA2ZzUX5O4fwzIN/GbkfC4YDcIhp9Qex2ZWO0ITFFptcbU1NNMqX36UQOxgCASYpACAAYBSLShMNhkfrcIv6Jf74o8WtYnszzx9F3cWPwEmzQ1KMJKVUsD8dv/DElbni59HI4TJXbD0U+TDOZdPKUNuNfYADAFEMgBABsJRH2lJ6fHo/H7XaL/4tN9amKC36jnwDjstzgxsYhfx3cjVO38cg9cZRQMDggJI7w64C7huzsutUGp8SAzN7fr5IHSYooaJSToSByoiktTZn4FACALUUgBABsAb/f7/P5RPxzuVziZ0geFqgM/xsw/ea2iJ+XZcBd4imi03VqtTo5FylLPqjlG8q6ESIaKSWJZSSdvCbERseXCzkgvEVz7IAEuGFlC+XeYDAobigjHpWXQiWPDwxHIpL8IijjIaVBS1yoYhlPNczsppsSHxGVQYni9Xc6nSo5H4q/zmAwpGdkpKWlpcqmcP9bAMDoIhACAEYi4ocyB4zD4RAp0C9PAaqs4Lftw/8GBz9xQ4l2ytJ+IvOlGAzKQg4i8+jkSTm1mo2MaVdPo9G4OX+FCIHKT3lWVCm4QbRdz++PBUVlLY3YA39sV1RtWVAckA+V9kNluhpluQuTyZSRmZmeni7PZkrjIQBgWARCAMBAyvLubo/HbrdH+4LK04EqdymNb5qtSoDrU5/8f0rwU+bS1MpzbIroIv6nxL/YYgyTYpic0mipkpeqH26f2GSq6+dZ9XpFsPb7fNF0LWdIcXdkQ0Nr7LCbX4DYT3EopROv1WpVyz1LU1NTMzJEPMwUt0coIQAgOREIAQBRypKAIv45HA6X0+mRBwTG5jXZumAWP51MtHuniHk6nVGmJMDoinzycnyj/MdMPMpKEuJPHrBdpEGlfU9Zg9EvN8aK/49fgHGLBmEOGH/ok9Nhn82mkls709LS0jMysrKyxG26lQIAVARCAEhyInKIEOh0OJzymLSQvB6gasMQuy3tjRlLgMrDDXL2S5VbqZQcGBvgNyZ/zCSkTA8T3zFVma9VnqU1mubW3/B4lF6p8VOPbs7x4/dUDtjb26s8aWZmZob4l5ExOKYCAJIHgRAAklEwGBTxz263O+x2vzzITRXrDroljYHxEUWr1UaDn8Egfqanp6empirdPol/W0R5JdNkyhZluhrxNono7nG7fX6/yHUBv1+1oRfuZubD2G7iUcrEsN3d3TqdLi09PTsrKz0jQ7xrvFkAkGwIhACQRDxer8vp7LPZRBjwBwLrB61tybygSgJRfmp1OqM88E8kCpFeTCaTfuO1HDAqxLujrFSfkZGh2tC5NxAIiFAnUr0SDv1x6xaqNmP8YSwcikP122zilIj2aDUaM7OycrOzTWlpjDYEgCRBIASAKU5ZLbBf6OuLhgd5ehj1htbAzTlCLAQqazmIqJAhSzWZlF/H9g/AxpR3QUhPTy8oKFBmGfX7fC6Xy+F0+uS3ONbkq9pUOIzeK+8hSZJHXk6kq6MjNTVVJPzcvDzxLjNJKQBMbQRCAJialNkmbb29DodDVPRD8uJ4m98jNBYCleYpo9GoLGNgMpk2ZyUGjJvoWE1ZZlZWiZLrPB6v3HgoBEU4lAcfbrJbaXx6VOYptVitRoNBZMLsnJysrCySIQBMSQRCAJhSlOFhNputv79f5EBlkXRlvb7NfLgSAnU6nSktLV2WmZGRDBOBTg1arVZpvy0oLAyHw+JkcLlcbpfL6XL5fT6xZTPDobKDPO+pz2q16vX6rOz1aBMGgKmEQAgAU4TX6+2Tidp/KBTa/BlilBCo7KyEQGXZOlHvnxTLAGI44u1TIr1qQ8uh0mzocjoDgUD0TRfZb8S3OH6ooaWnp3dDMszNzRVniLL6IgBgUuNSDgCTm9/vdzgcVovF5XYry8dvZntgLAcaDIa0tLTMrCxRxTcYjTpmhZmKYi2H4rZIg263u7+/X1lwUtrQnXiEZsPYveKxPd3d4nwTp02OyIU5OekZGXxxAACTF4EQACalUCjkdDptvb2iWi8yoTL8a5P18tjIQBEPUlNTRQjMzs42mUysRJdUlDlpcnJylAmHxInU39cnIuL6ZsPNS4Y+n6+jvb27q0ucP9FkmJsrbozjHwEAGB0EQgCYTJQhgr29vX19fR63O9bVc5OPUn7q9XpjamqOPEeIqL6zRESSE2eOsuBhUVGR3+93uVz9/f3K0pRhZUmSTSVDcVKJR4lI2dnRkZGRkZefzyBDAJhcCIQAMDmEQiGbzSaioNPhiA0R3ORyc0q1Xll8PCc7Oys7OzU1lcXHMZgyVWleXp44uxyy/r4+kQwlSdqcZCh2E+dnX1+fwWjMzc0Vx2GZewCYFAiEADDRuVyuXqtV1LZ9Pp8yBegmmwSVHKjVarOyor1Cc3JyjEYjtXNsDp1OJ/cAzZXKy5XepHa73ev1brLNUDkt/Ru6kmZkZOTn54toyNwzADCRcY0GgAlKkiR7f393T8/mNwkq88RodbocJQdmZxtpD8TW0mq1yjoT4vRzu93RtUz6+pRvJUY4FWNdSfv7+0WSbGtvz8vLE8kwLS1tnMsPANgcBEIAmHC8Xm+vYLV6PJ7NGSW4PgdqtaLOrUzvQb9QjCKdTpclC5aVuVwuq9XqdDhEMlSNODdprMGwva2tu7s7U14aURyEkasAMKEQCAFgoojOz+F0dvf09PX1BQOBTTYJxtaNEPEvOyeaBNPT01kAAGNHr9fnyKKLndjt1t5eccYGg8FNNhhK8ghYcWKnpaXlm835+fkpKSnjXHgAwJAIhACQeJIkibqyxWKx9/crI7U23SQoaudyu01efr74yTAtjCeDwWAuKBD/PB5Pn83Wa7N53O4RBhnGtrvdbpfL1dnZmZebW1BYyEoVAJBwVCAAIJGCwaDVarX09LjlNSRGnjBGaRJUlgoQOVDpGjqepQUGMMmKS0rsdnu0DdBmE6e0Sk6AQ+6vJMOA39/R0dFjsWRnZxcUFIif41tqAMCPCIQAkBg+n89qEUmwR9zYzN6hKSkpouqcbzZnZGQwEAsTh0ajWd+VtKxMxEKr1ep2uTbZYBiWJPEREBkyKyuroLBQPJyBrwAw/giEADDePB6PyIG9Vqvf7x+5d2hslGBaenpubm5+fr7RaBzPogJbxGAwFBcXFxQUuFwui8XS39cX2DAadsj9xckvzvDo/KX9/eIkLywszMvL48sOABhPBEIAGD9ut7uzoyM6Z4w8D8cmo6Ber8/MzCwoLBQ/qSVjsli/AGZWls/ni06Xa7Eo8+UOd8Ir211Op/gnPiDR0Ylmszj5x7fUAJCkCIQAMB5cLldXV5eoHEvyioIjR0GV3NISXb3NbGb1NkxeRqOxtLS0qKiov6+vp6fH4XBIkjRCP1KV3H6+rqmpp7u7oKjInJ9PLASAsUYgBICxZbfbRVW4z2YLhUIjzxkTDoeVCWPMZnM+LSSYKrRabV5+vvgnAqHFYrH19o6wUoWy3ev1RmNhV1dBYSGthQAwpgiEADBWlFZBUf3dRBSMRMJyb7rsnJyCgoLc3NypsZZgV2dXbl5eSgpVeayXKSstLbX09FisVp/XO1IsVKlELGxet667u7uoqCj6FQlrqwDAGODaCgCjz+1ydW5GFFQGCup0utycnEJ5oOCUmWXR6XSefc6v773338XFxYkuCyYWo9FYXlFRVFwcnWXXYhEflpE7kYrc2NTYKGKh+Izk04kUAEYbgRAARpPX6+1ob++Vo+AIYwVjy0jk5OYWFRVNvYGCy5a9/vLLL77/3skLTzg+0WXBRCRyXXFJibmgoL+/v6uz0+l0DjfrzPpOpB5Pkzy2sLi4OC8/nzmWAGC0EAgBYHT4/f7Ozk6rxaLMsz9yFDQYDPlmURkumJIry/sDgSVLloq/9eVXXj1+4XFTptkTo06n0+Xn5+fm5opY2N3VZbfblZG0g/dU2hA9Hk9DQ0NXV1dJSUluXt7U6FwNAIlFIASAbRUMBrtlfnmJ+U1GQbOIgoWFU3hFwU9XfPr2O2+LKvy7y5d3dHSWlpYkukSY0MRHRmTCnNxcu9xaKMLhCLFQJS/fUl9fn9nTI2JhdnY23zgAwLYgEALA1hPV1p6ens7OTq/Hs8koKBKgyIEFBQUpKSnjXM5xtmTJ0mDAp9XpWlqbV61aRSDE5hCpTqS7rKwspRPpyK2F4qfDbnc6HCJGiliYkZEx7uUFgCmCQAgAW8lms3W0tzudTtWGlbUHi40VLCwqKiwsnPJRUKivW/vSyy+pNVq5hh95+ulnDzrowEQXCpOGCHs5OTkiGfb39XVtqhOp+Nlrtdr7+81mc3FJyRRudQeAsUMgBIAt5nK52tvb+2y2SDis3lQUNBcUFE7pDqIDPPzII729Fq1u/VSQ77//vq3XlpuXm9hSYXKJxsLc3OycnE22FoqNkiR1dnba+vqKi4rEh03H6hQAsCW4aALAFggEAu1tbRaLRVlPYug0KK8rqNfrzWZzUXFx8kRBobOj67//fUy1YUyXRqurq/vh88+/OOhgGgmxxX5sLezvF587pTV+8IhBZRrSgN+/bt06i9VaWlqal5fHwEIA2EwEQgDYLNHhgt3dHR0dvhFnjhG76XS6ArO5sLBw6i0msUkvvPBCU1ODdkMTjXihJCn03HPPEwix1ZRYmJWdbevt7Whvd7vdquFjocftrq+rs+bklJaVMbAQADYHgRAANi3aQNHe7rDbVSMOFxT10bz8/OLi4szMzPEt4ITg9fqWPvigeCU23qx+e/k7DrsjMysZXxOMFo1anZ+fL5KhxWKJTeM0ZCxUyeN7HQ5HQWFhSUlJMgzcBYBtQSAEgJH4fL72tjar1RoOh4frhCaioPgpQmBJaWkyT4L/1v+9/fXXX2m0G/2XRaPVNjU2vP/Bh4cffmiiCoYpQ6vVFhUV5eXldXV29vT0+P3+EQYWdrS39/f1iU+l2WxO2k8lAGwSgRAAhqYsKdHe3u73+aLDBYeqUCozx5hMppKSknyzOcmXyX5gyZJAwK9MJyOq48qLJgSDgddff4NAiNGi1+vLKyrEJ66jo8NqsSgn24B9lHPP6/U2rF3ba7VWVFSkpacnpLQAMMERCAFgCE6ns6Wlxd7fP/JwQWU9CUHUUMe5hBPNio8/fePN1+XVJqKvTFlpudVqCYaC8p3qZcuWeTx/Fck5sYXEVJKamlpbW1tQUNDe1tbX16caZmCh+Cnudblc4qNaUlLCHKQAMACXRQDYSDAYbG9v7+nuVuYRHXIfEXi0Wq25oKCsrEzUSse5hBPTfx/7r8ft0ur0cqNp+DcXXfT0M898+tkKrVYnInVbe+uKjz/Zb/8FiS4mppqMjIyZs2bZbLa21la3x6MeKhaKD7L4OIsdRDIUn9m8vLyEFBUAJiYCIQD8SFQrW1ta3G63RjZ4B2W4YFZWVmlZWXZ29rgXcIJqbm753//+t6F5UCotLVu06JS+Ptunn36skqvjPq/ntddeIxBiLEQnc8rLy8zM7O7u7ursDAQCw/UgVeYg7TObRSxMqvVgAGAEBEIAiPL5fG1tbVaLRUS+ERoGDUZjaWlpQUFBkg8XHOCRhx+1WLrXL0YfiRxz9M+Ligv3nD9frzdIYUlusVG/9vobVy++OiODcVwYE3q9XsS83Nxc8UG29fYqs/4O2EfZ0tPd7bDbyysqzGZzIkoKABMLgRAAVBaLpa211ev1Djd5jNJHtKioqLSszGAwjH8JJ7L+fvt/H3tMed3kzGw6YeFCcXuv+fPFy7WuqVGr02m02tU/rP7m62/2/uleiS4vpjKTyTR9+nRbXl57W5vL5RpyaQrxMff7/Q1r19pstoqKCnp9A0hyBEIASU3UC1uam3vl9oTh+ogKmVlZZVO6j6gkSQ8tfeT9Dz4QlWO5Ah3Z9GNkao2mq7NrTd0PymoTkbC02667zZu3u7idm5ez9/y91jU1qOSWmVAoeOkfLttt113DYWnM/g61SKTBYFC8ZbNmzjrttFMKigrG7LkwQSk9SLOysrq6ujo7OsT5MGQPUvGz12p1OZ3io11QWMi6FACSFoEQQJISmcFqtba2tPiGX1VCmUe0pKSksKhIq9WOfyHHjfjr9t1vnyf+98Sb//f61jxc9+Mkq6efdpo+Zf2vRx515KP/fViOl2rxFJ988qH4NzolHpZ655/s8qszzjjkkINJg8lMp9OJpJeTmys+49E5SIfqQSo++IFAoLGxsa+/v7KykqZCAMmJQAggGUVHDLa2ikA4QsOg+JmXn19eXp4kiyXU1FQ/9/yz119/w6233RIMBLRbPjt/WApVVdUeeujBsS077bRjQUFRj6VHidPxuXG0RKc0lULiRr658PBDD1u06JQF++3LCE8o0kymmTNnik96rE/4gB2UlGjr7XW7XGXl5QUFBTQVAkg2BEIASafXam1paRl5xGBqamppWZlZ1A7Hv3yJk5ZmuvHG67ebO/eS313y4yQxG5MkSRUZrkNp5MgjjywpLYn9PmPG9J122vmNN5aJMDjqpRVvk8iCGo1u7twdfvnLkxYef/y06bWj/iyY7MRn3Gw2Z2ZmKt8BidNmuKbCpsZGZbIZJiAFkFQIhACSSDAYbG1t7enuHqFhUFQWCwsLS5N4VvqTTzmpuqb6oot+8+WXn2m0uvjas1qtmT6tNkWvD0kDxwGKl06n1Z5+2qkDth9++GEiEEqD9t9WkUh6RuaCffddtGjRwQcflJmZMcrHx9RiMBhqp03LyckRVwBlXZkBOyjnucVicblcFRUVefn5iSgmACQAgRBAsrDb7c3NzS6nUzPUxIMqucXJZDKVi7pg0q9bPX/+vFdeeel3l/z+8Sf+q1JrYuMnw1KourrmrrvuKCgwi3S90WMiKq1Om5eXO+BQZ5995v77Lxj1bngifxoMxtqaGrUmqRpxsU1y5eUK29rbu7u6wpKkHhQLo2tm+nz19fUOp7OsvFy/5R2nAWDS4UoHYOoTSa9DaG+XJGmkhsGiovLy8pSUlPEv4QRUVFT44ENLd95558XXXO3zeZXuo6IC/cYbr559tufee/4za/bMzTlOamrq3Llzx7iwwObS6fVVVVXZ2dktzc0ul2u4psLOjg6X01lZVSUCZCKKCQDjh0AIYIrzeDzN69b19fUNuSKZSmkYTEsTUZCGwQFSUvR/+OPvRfA7/7zz29pblUwofr7//vIDDz7kvnv+c0jc/DHAJCICYVp6entbW7SpcJhRhU6n84fVq0vLykpKSphpBsAURiAEMJVZLJaW5ma/30/D4FY78sgjqqurL7jgovfee0cZUigyYVvruhNPOumv1//1ggvP29ID9vba3l3+Xn19fZ/dFq2Lq8akqi3e3Ly8/BMWHl9VXTXcPl6v98MPPv7yq69sfb3hsDRaJYmoInpdSl5u3ty5c/baa356RvomHxIKhb5ftfr99z7o7OkKBHxj9JooZdNqdfv89GeEeb1OV1VVlZWVJS4RHrd7yO6jYUlqXrcu2lRYWWlkUQoAUxSBEMDUJGrYra2t3V1dw80fI6KI0WisqKjIN5vHv3iTy3bbzX3h+WcvvfSPDyy5X6WOrigoMqHDab/wNxc1tzT/+c/XmEybVVf+9JPP77333mWvv97T3RUKBca62MJ99977zDPP7LjTDgO2ezzepUse/M8999TX1/n93jF69pQUY1VV9S9POvG8884rKBz2NFv26rI77rjzoxUrXE6HvGbjmLvl5lv+9KcrrrvumnF4rgkuJycnLS0tOtdUT88QaxWq1Rq1ure31+PxVFVXi50TVEwAGEMEQgBTkNvtbmpqctjtQ84fE1tjMPqtf7JOJbqlsnOy77n339tvv/3Vi692Ou0iEGo02kg4fPPNN9XXr7377jvLykpHeLjf57/ppptvvf02h71PpUxTMwZrEg7W0Lj2bzf9/fHHH43fuLa+4cKLLnr99WUqpShjUxJxmoWkUF3d6j9fe82LL7107z337LLrTwbs43K5r7zy6n//+5/BYECURJRlfLomijR+++23H3XUEbvuuss4PN0El5KSUlNTk5WV1bxu3ZC9CZSZZurWrCkpKSktK2OVSwBTDIEQwFTT09PT0twcCASGaxjU6/Vl5eVFRUWMC9oiIsT99uKLZs+edcGFF61du0bkKLW8kuPzzz+z117zL730d8M9MOAPnHnWuf/970MqubvpeJZZWLnyO5fTFeu3KdLgMcccs+r7lQNW1Bh1ysGVv/fLLz9feMIJz27cVilO0fPPO/+RRx9WjVkoHY74210u+6qV3xMIFeLNys/PT0tLa2lpsfX2qja8ffE7iEtHm7xkRVV1NV8kAZhKCIQApg5JklpbWrqG6SYakWVmZor6XHr6pod1YUgHHXzgG2+8dvxxx3/51RciV4iX1Jhq2uUnA9u+YsQOf/nLDSINjnUAG05xcYkpzaTc9nl9F/3mYpEGxzmAiadrbFz724sveeWVl9I2FOb22+4UaTAhL4v8tYihorx8nJ93gktNTZ0xY0ZnZ2d7W1swGBxwDYm+TWq1zWbzeDzVNTV0HwUwZRAIAUwRXq+3qbGxv79fbrUaopuo2FhcUlJWXq7bsKoeto7ZbA6GJGWsWyQszZo5e8/584bb+btvV95x5+3qQW+KFJZELhnjkqqMRtOFF1wQq9k/99zzr7+xTGSw+H3EuRGWQqP+1NEuoHGJQjzpu+8tX/bqa8cdf6z4talx3W233yaPUPvxZRmjkgzpjDN+9dN99h6f55pExNtRUlKSkZHR1NQUXbN0qO6jfr+/bs2a0rKy0tJSehkAmAIIhACmApvNJipwfp9vhPljKquqWFhiVHzx+RerVq3UaNbn6oMPOmiEHnT/+te/XS5HfIuceDtE7iksLC4vr4jWpyOjP41KRK7ZV1VWnHb66YcffmjseR9YslQ8tSauMFIoZDKl7brrrkWFhZFRKok4CTs6Or/65muXy6nd8O2D/JeGX3n1FSUQPvb44z09XfEvSzQNhiM77LDz9OnTNGrNGM0uI/5EnVYzf6+9zzrrVzpWXR+GCISzZ89uaW6OzjQzTPdRca/X662srGSCYgCTHf8xADC5iWp0Z0dHa2urqKINlwazs7OrqqtNJtP4F29Keva55yUpKMKM3PMw5Ygjj4i/V4Tzzo6uudvNEbe93N2scAAAIABJREFUHu+HH30Yf69IPaZU06W/v/Sss8/MyspSj9msmuLIaenp8TX5zs6ub7/7VhW3ooMof2Vl9dKlS+btsftojgpTq7xe3zdff3PKqac2NTZo4lqkv/76G7vdkZmR8fHHH8U/QpzGIlf8/aa/n3rqooyM9DFddoI5UTaHXq+vra0VybClpWXwgGRlUVNLT4/X46mpraULOoBJjUAIYBILhUJNTU1Wi0U16Ft81YZuomVlZaVlZVq6iY4Sm63v7XfeVm5HwtJ2O+68044/TpTy3rvvX3zJJQcdeODfbrpR/FpXV9/R0aFS/1iZDkvS2Wed/edrF49zsYWV361yOhzxy82JdHrN4qsXLNhn1J/LZErdc/688887T55rJ3buqd1utzhp7Q7HunUt8fuHpdBxx/7yoosuGPWSDDB2UXMKUqsLCgvT0tPXT1k8VPdR8YauXr26uro6Pz8/IWUEgG1HIAQwWXk8noaGBlHFH65h0GA0VlVW5lFRG1WrVn2/+vtVmg29DRcsWKBM4Ol0Ov/+91vuuON2l8t5xGGHK/dae3sdcQOxRETX6Q0nnXRiQkouThgpHI4FIlEYrVb305/9dOye0ev1DNiidEr1+/0iSKg2zmZ77b3n2JUEWy0tLW3WrFktLS3dXV2qobqPhoLBtfX1Xo+HFSkATFIEQgCTUnTQYGPjkIuGqeS6fnZ2dnVNTWrqZi2Yjs331FNPSVJIq9NHA5VOf+IJx4uNH3348R8vu+zDD9+PbwwUQpKIYPEzx0T7K3q9PpfLPSpDByNyK01s3s6RDTn/R2RTXVZF+be0VU08xOlyidfkH//8l1oT3zQdycnJEuekw+EYqkF7i54E40en09XU1EQXpWhuDoVCgzOh+Nna2urxesVuev14L6wCANuIQAhg8uno6GhtaRly0OD62USLi6OziTJnxmiz99uXL1+uNG2FJWmPPeZVVFTeeMNNf7/5pv7+PmWKFCn0YwIcEHrk2Tik8y+8ID0tfVRmcIk2Oep0e++91+9/d0lRcdG2HzBmzQ9r3nrrndU/rO7s7NSot6DZR/yNfr+/oaGxvqHe7/cN6Kv8k112MZlS+/v6RrGoGB+FhYUizDc1NbldriG7j/ZarQG/v6a2VkTHhJQQALYOtSUAk4kkSS3NzV1D9d1Sre8EqK2sqhJVt0SUbur7+ptv1qz5QZklRdSAc3LyfvWrM19d9nJ0jQU5DSoxLzzsehJqscP3q1aO7lQyK1Z8uHr16ieffGJU5g1aW99w4403Pff8s319vdtyHPGKxKfBSCScYjCeuHDhNhcQCZOZmTlr1qzmdeusVuuQmdDpdK754QdWKQQwuRAIAUwawWCwYe1am8023KBBkQdqamtFpW38y5YkXnzxpUDAr2Q/EQv/7603Q0F/bGl1KRQUke/oo39+2umnjnAQ7Wi33Iq3ftmyV998462jjzlyGw/19lvvnHPOuQ2N9SLiju6S8WFJOuGkU/bZ52ejdUAkhMFgmD5jRqrJ1N7WpvRHiL93/SqFdXVVfC0FYPIgEAKYHNxud0NDw5BLRavkSJCbl1dTU8OaYGPH5/O9/vobsV8jUWElHCpLC5ZXVC2++urTTz9NpxvXOV2jPVGlUEdn5zYe57tvV552+mltba3xywNuO2W5+V122f3GG29Qa5jkc9IT51t5eXlqauq6pqZgMDjEKoWS1NjQ4Pf5yisqWLkewMRHIAQwCfT394sKlm+odeeVL+lLSksrKiqY4m9MffThioaGtfGzpMQaBkWCWnTq6dcsvqqqumr8CxYOS8bUtB22325bDhIKBq+66urh0+CW9nFVRxRhSfxy9FE//8c/7y4tK9mWEmJCyc/PNxqNTY2NzkHfUkU/F5FIe3u7z++vrqnRM5gZwMTGRQrARNfT07OuqUmSpCHToFarraquLigoSEjZksoHH37g83ni85LSMDh37vZ/vubPxx1/7GYeR+5ZOpq0Wt3Fv714/l7btGzDBx989Nobr2u0G/1nUUTNyLDjITdFrUlPS58ze84555yz6NSTabueetLT02fOmiUyoc1mG9gSKP9utViCwWBtba2IjgkqIwBsGoEQwITW3t7e2tIyeKyOSk4jxtTU2pqarOzshJQtqfj9gReefyF+i8h1BkPqGWf8avHVVxaXFG/eYcT7qF206NRRmxE0ojIYjPP22OOwww/dxr55r7/xRsDvjY+7kiSZ8wuOOOKw2tppKfqULWoiFDEyOzt7jz12nzV7ltFo2JaCYSITOX/6jBktLS2dHR2qQTNdaTQau92+5ocfpk2fztSjACYsAiGACUrkvebm5q7OTrVs8L0ZmZm1tbWjMrEkNunLL75cveYHpb+oSEoi8ey440/+duMNhxx68OYfRG7R1fzx0j9ut8PcMSvpsEZIjJFwZM2aNfFbwmGpqLD4maefnr/XvLEvWhSDzSYpkfqqqqqMRmPzunXRVSsHZEK12u12/7B6de20adl8dQVgQiIQApiIRORoaGiwWixDdhMVP/Py8mpqa1kDety8uuw1r8el0eqkUDAjI/O3v7n4kt9dnJu7ibn1lWF08TVk8e75g/6xLesw5A6uA9r51v8qzjef17vRHeHwcccdO0ZpUHlZBmyUpK3tm4oJoKioKCUlpamx0e/3D7hqiV8DgUB9XV1VdbXZbE5UCQFgOARCABOOqDytXbu2v69vuDRYUlpaXl7OFDLjxu32LFv2qiq6dkJowb77X3fdtXv/dK/NeWBWZpbJZPJ43EqziVqtCQV9H3+8YpddfjK2JR7K8nffCYUC8YteaLX62KLzgxNae3vHGJUkLS09KytrwEQ1L7zwwplnnsFgs8krNzfXYDCsra93u92Dp5kJhUKNDQ3iZ3HxZvavBoBxQiAEMLF4PJ6GtWsHT9ynkqvsYmN5RUVJCbM1jqtV36384ovPzebCSy6+5JJLfmtM3dzQUllZbs43r1vnVG14N0UmvO666zQa7THHHGk0po5ZkTcSCPjvv2/Jvffeq4lbKT4cDpeVlGZkZKiiaypqCos2WjVOo9W9/Morl19+5QUXnDcKo78ikRSDIT19/XGysjNnzJj+zTdfxj/dm//3xvnnX3jVlVdkj+2a5hGRgbNz6Ls4JsSpMmv27IaGhsHfZ0WXowiHlfmxSktL6SEMYOIgEAKYQEQaXLNmjdfjGTIN6nS66pqa/Pz8hJQtaYlX/smnn9lvvwNvueWmnXfeaYseW1xSPG/eHuvWNcS2qDUai9VywYXnX3nVlVmZWWLDaJd3IFHxdns8lp5ukfo2qoVHwvsuWFAgd+ET59suu+z20MMPxT1KLUmhm2664f7778vIyBrcfrhFIpFwfl7uolNPPf/881JS9OLge+/906ee+l/804mQvHTpA8+/8EJWZvY2Pt2IJYmk6PUHHnTA5Zf9saKyYoyeJZkZDIYZM2Y0NTVZenqGWI5CpWptaQkGg1VVVWRCABMEgRDAROFwONbW1/sGjcBRybVYUc2qnTZN7miHcSVJ0jFHH/2X6/6catqaBr3zzvv1s88+E5JC6g2dM7VarXhD7fb+/v6+LV/fb+uoB6TBcFgymTLOOOP0WCA94ojDrr++sMfSrd2w8oTYX6vT2/psvTbrthegpaXpy6++8Ho8f7ricvH7SScuvOvuuxrW1se6sCpPJ16Tvr7ebX66kUoiPk5r/72mvq7+5ZdfNDAD6hjQ6XTTpk3T6/Ud7e2Dr2bije7s6AhLUlV1tTauyRoAEoVACGBCsNvtIg0Ono9BJXftS0tPnz5tmol52xNB1G73/un8rX74XnvNX7TotAceuFer+/GdHXLm2HEjrxcfvvCCC/be+8e/q7q66ve/u/Syyy8dsMaJfEKOymhVrRQKPvb4EyIhZ+dkmwvM11177aJFi0Tejk8Fo/d0IxGfqeXvLX/nneVbNEksNp84hSorK0UmHHLVHPEud3d3S+FwbW0tmRBAwhEIASSe1WptamwMhUJDpsGsrKxp06cbDDRlTEqivvv3m25saWl5883Xou10iZ4KSFkz48wzz77mz4sH3PWb31zw9ddfPf7Ef6MNimNSTVf7fL5AMKj8ctJJJ3Z0dFx22R9FUIxf/3AcROc4CQa6urvH80mTjXiRS0tLlalHxVk3OBNaLRZxfaupqRH7JKqQAKAiEAJIOItIgw0NgytMKjkN5uXniwoTy0tMarl5uU888dgVV1y1dOmSQMAXHUf44xwz49FOqAzJC4dFFIwYU9MuuvDCa6+9JjV1YA9YY6rxvvvuyc/Pv+/+e30+b3w5R6sgP/nJT3I2TOgi/vRLL/1dTk7OFVdc0dPTJU+4oxmfFyQshQoKiveav/UNv9hMZrNZp9M1NDQEhlqOwtbbGwoGp8+YwRdeABKIQAggkawWS2NjY3ioNCgq8QUFBdU1NXSpmgJyc3P+859/HnPM0Q8uffDd997ttdlCoVBEJLTxGUOo1qSkpBQWlC5YsN8ZZ5y+774/G27HtPS0u+6+49hfHLtkydK33vq/Xps1GAiNRhGjnQb32GP+9X+5bsC3G2eeecbuu++2dMmDz73wQldXRyAQGLMJZWJlCRcWFt/895unz5g2xs+EKJH5Z8yYUV9XJ97cwe2EDqezrq5uBpkQQOIQCAEkTEdHR2tLSzgcHrJtsLikpLKyMuE9DDGKDjnkoIMPPtBq7f3i8y87u7ocdruoDY91m5g4fn5+/rTaml123SU7e7MmJRKJUfzr6+v75utvm5tbwpHINhZRHCE7K2v//RdkDVWA7bff7rbbb1l8zdWrVq5a29AY/URs29ONQIRNrUYzf689p02rHbMnwUCZmZmz58ypW7PGM2gKZY1a7XQ46uvrp9MxHkCCEAgBJEZnR0dLc/Pg6RaULWXl5eKfhmnZpxzx5prN+YccelCiC7JpOTk5+y7YZ9yeToTVvfaev9fedOOcmkwm04yZM+vr6kQmHKKd0G7/YfVqscPgnswAMNYIhAASoGP4NCh+VlRUlJSWJqhoADAmRCacNXt2fX29iH+DxxO63e41P/wwc9YsMiGAcUYgBDDeRkiDYgtpEMBUpSxbX1dXN2Qm9Hg8IhPOmDlTRMdElRBAEiIQAhhX7e3tLS0t6qHSoKgPVdfUFBQUJKpsADDWUlJSRCZsaGjos9mGzoRr1swkEwIYRwRCAONHaRuMRsHBbYMaTU1NjZk0CGCqE5lw+vTpIhP2Wq2DM6HX46lbs2bW7NlGozFRJQSQVAiEGCgUCkmyRBcEU01/X19LS8vg7bG2QdJgkuiz9dXV1avkNeKLS4qrq6tidzU2NHV2dqnV6vT0tDlzZ+t0I/1HSjy8q7NLHnfK5ENbQLxi2TnZGRnpiS5IUhPndm1tdKLXITOhx+NpWLu2sqpKq9VGxnwdEiQRcXUV5544x1jPCfEIhEktGAoF/FE+r9fj9fp9vmgQDIcj4ahElw5TTXTduWF6itbU1prN5kQVDOPms88+f3Dpw729VnGBeePNN6qranbbbWe73XngQQdIIempp5/u7OxMT8toWte4w/bbt3d0HHboYb8+75zp04dYLu/rr76+6De/bV7f4Dz+f8okJq7wGekZl1/+p0WnnpzosiQ1US+fNm2aOHmtQ2VCh8Ox+vvvx3pRFiQhEQXFeSXOMYPBYBRSo/R6vbjJ+Za0CIRJR1TKRfyzOxxOh8Pn94tAKLbE7uVagLGjlsVvIQ0mD4/Hc8MNN3333crTTz91/vw9n3ryaa/PU1ZWfsbpp4payKOPPvbYE08s+Nk+p5922v7779vZ1ZWaanrgvqW2ftuuu+52/V+uP/+CX8d/n91n6z/zrHO+/PIz2ga3VuS888+bNq12z/nzEl2SpCbO6tpp0e87BmdCcbWM/68zMFqCwaByw+VyKTfEySYCociHaenpmZmZ6enp4jYVwqRCIEwWkiQ5HI4+m83hdIpAGJEpFXQW/kZCkAaTh8vpEvmtsqLimWef1Gm1Dz74SGlp6UEHH7DnvD2ffurZP1526d9vvvHkU37563PPm944zdbXF31MRHXMz4/KycnZe++97rzjrpWrVv7n3/9Sa9ZXUHosPV9+9aVGq1OqLNEu7nHd6jTy998DmqOVfndiSzgcju+DF7sGDrd9uINHu1HEtqtVGk3c9jhKjo0ePCyJ/bRyJ9hYYWJlG/Ao8dTy0aKPG1Sk6KMH19UGN78PuTG2xe12fvLpJwTChBs5EyaoUEgK8SeYSImBQMDpdHZ1dopwKJJhVmZmTm5uamoq52EyIBBOfW63u7e312aziRwoKhfqOIkuGpJYbNwgaTAJXHfd9atWrioqLFrx0Qq3y/3OW+/84Q+/++jjjxYtOmWnnXb8wx8uv/yyP6ytr99ll11eeunlW269efr0WkuP9f33P2xqajrvvHNtvbZ77rnn3nvvO/fX5ygHVEcD2I9pqqa6Ni0tbUOcU7e2NjtdTlNqmj/giwUtnU6v0+m8Xk9mRmZRUUlYHiYtTkJbv81qtYjbBeaCrKyciLy/SJ6dXZ1ud/Tr88rKKvEQ5eDiaE1Njf6AX0Sz2tpaU2rq+ieNqFrbWx0Ou8FgLCsti15d5czm8Xo6OtvFPiLZ7rjDjl1d3Wvq1oigJ+pbYoeQtL79R4TJqorqaFaMRr1oBG1pawlLobS0jOLC4vXpUaNxOO3d3V16fYo4/IC2I3lEkE7U6Aa88gaDQewZexFEsQ0Gvd/vV35lrPgEITJhTW1tZKjxhMD4iK8WiitDf1+fvb+/vb09IzMzLy9PXMGiVy1MXQTCKUvUIfr7+3t6esRHWlQIaAzExMEKE0llxccrli17vb2j7e5/3vXAkvujrWGR8CvLXs7Jyd13n33+fvPNX331+fPPP/vHP1x22+03v/rKa2eccabX59bJLJbezq6uG/76FxG9rrjyqgX7LZgxY3r8waVQ8PDDjvrFcb9obm5Srm8pKSmPPfZ4fX39OWeds+ShB+zyam9it3323ic7J+ull1+6ZvE14l6rtVerFekoZffd97jhxhtEnrrqyitXrFgRHekaDufm5lVVVf7h8j/su8+C31x00bfffaOMrc7PN/f19S9efNUvjv35kUcd1dTUoDypPiXlySefWrny2/N+fZ44v0UtShttMFTNm7fnkgeX/rBm9a033+JwOisrKu+77/5XXn3x6CN/LgLnxx9/oNXpRdkWLjxpj913X7HiYxHqwmFJPOrTTz979rmnL/7NxbbeXmuvNToPhFa7yy673X7n7eJTU1VR9fSz/xOP3fAihKpqpy3YZz/x98Z/0yeO/Nvf/+GZ556pr1ujbKmsrDnppBP/9rcblMfyteDEMcIcM8D4i/Wb6LPZRDg0Go15+fni4sPMt1MVgXAKEvUtm83W2dHhcrmUJsHN/69LrMcU05ph7ETTYHU1aTBJPPjQI2f86rQrr7pCaTGTe06qfF6PyCQvv/Tqt99+I3612ay102pEljviyMOuufbPTU31KrVGaUb+yc47PfTQIwsXHjdv2Wsi6f35z4sHHH/77bYTdeh1Tc1Kb8wXXnyx19qdlZ2bmZkR39Uz1WRKSTGkZ2QaU40PP/rIgfsf6HYH1Cp10B8UyXD2rDmrvl+19MEHYvvfd+/9Yv85c2YvffCh9ra2nXbeWQpJGrU2LT1dXCB32G777s6udetaotMzqNQvvvSixdKVnp45Z9ast9951+l0iZIHg0G/3z+tprZDXI7bO6+8+k/7/Gy/7ebMEQfPyMiwO/rXP5NaM7122j333ltcXJSVke33+xx2h1anNZlMNVVV36/63uvzipdOHC0lRV9TXR0KBTMzM1UbXaUj4qXLyckRF/wBV/u+/v6TTzrli8+/EAeUJGn27NkVFeWj+vZi1IhMWFNTEwwE7HY7WR1jJ3Z2bc5pplxSfD5fW2trT3d3bl5ecUlJKrFwyiEQTjX9dntHe7u9v19phBk5Cir1iVitQvzXSCvb5AOBrSbOt/z8/ILCwkQXBOOhtbXN43bvt9+CYDAkVz4ic7fbcc6cueJaY7H2/OnKP3p87jfffDMvL3/evD3E/iLXiTqHqKcoQ++kULC1tXWfffaxWq277bbL88+/cOmlv09PT4t/CiksyYNf/Fo5ahaYzU6HXaQmo9FoMBhE/pTk7SJfKQPzwmHpV6efYUgxvP3OW/oUw2133t7S0jx71tyc7Gy9PkWj0UUiYaMxNUWfoowqFI93e5xt7a3R4rU0ffbZ5+JGIBhUazUBv09JoXl5eX39NrVG7XZ72uW+o2qNJiyFeizdYfkCK8/iEJ0jJCv6LAaz2dzS2vzjnyBJ22+/w9FHHfnPf/4jElE/9/xz361aaTbnOxzOto5WkSqjxZZCFotFHEQKR0Se1On0sRbCQFgUUsrLyzWZ0kRqVebZUbqJLn1wyZxZc1MMKeKDJ8pQXV3d3dUz9m87tpJer58xc2ZTU5M4oUmEGAviehS9KIrroCRFFxnb0INMNWI+VPYR15Cuzk5bb6+4golYmJKSMo4Fx9giEE4d0e9v2tp6rVbxAVfqPcPtGZtRRieqP3q9qCelpaeLypNepixQQyAEsO1Wf/9Dbm5eYWGB0lshLIV33GGHUxctSkszvfPuO3a7XVxw0kwmUT/xerxi/xUrVnR1dYqUJa5jSib88OMPT/rlSSu/XXnAAQe8+cZbvb29GwVCteatt9+66MILy8rLNeroVevoo466865/fPDB8u9WfvfXv95gtVpETot+DZFrvuXWW/3+wNtvLe/o7PjVGWeUV5aLC117e8edd92x4tMVIrX+4+5/RuQLZGpq6pdffiXy3qpV31uttu9lG55QKypHr73xxiW//U1VVVX0UqlWHXH4EXfceecXX3z6+htvrvj0k4Dfq+wcCoVF5gz4Ays++URExO9/WLVw4fH/uPsfIuM9sOR+jfwHipflsy8+b29v/8nOO51yyiJRAHHMhx9+ZOWq755/8cVPPv1EFVk/AlCrTem323t7e4468si77/7H+jqcSv3Fl188/PBDDqfj7rvuUuYPFBtbWltuuOGve83f+9hjf648XLykaaa02++4Q6Xm8j5xiUr2zJkzE10KTGXKWtOhUEjpxeD1et1ut8/rFb+K7SPMMRGLheJ6ZbPZSkpLzQUFGlqzpwQC4VQgqi/d3d3tbW3igz1yllM6FKUYDFmZUekZGSIHkv0AjJFgKLimrv6BB5YqNQmR9B7/3+P/fezR7Oyc2bNn23rtTzzxhMfj0upS7v7Hv7bbbu4jjzyiTARaWVHZ2dUpLm4ikvX39ft8otria2xqDAT8G44dXY9ehMYvv/ry3PN+HT/hgaivaHX6x5547IWXXogtViEvuRq9Qj77/LPisd98+7Wy6r14LrG/z+e74qorTCbT+kNHIqKGpNHq3n33XZGuYm1xG2i++PKzM885SzlC7EnD4chrb7wand9lw/7f/7A6ukqiWv36m6+J7f39/b//w+9F2hQ1MOWbO5XcI+vtd94SN6659hpxl/LAQCAgDvjOu2/J5V//J3z1zZfKRKaL/7w4fiSPOJTY+8abbpSj8oa5dsTVXqv9eMVHn3/xmbJFlEReacgfe00YGgAkIaUv2ID2PXHBERc9l8vlsNvFT2XGqSGToXIxF9fMhrVr+2y2isrK2JUTkxeBcNITn8nm5mZbb69qQ1fvwZQmQfHhzxa1sNxckQZ1zBYFYOyJuDVzxoxDDj5o8TWL4+sWRmNqRXn5Pvv87In/PS4CoYhzC/bdZ9bsmVcvvjoikl44ctZZZ91z773t7W0+r3v58uWlJWW5ebl5eXlK4FHSZURuOhM1m5AsdnDlicT10OPxxBdGuUJqtdGfSj6M7a/cJepDA3aOLXQxgHjSoGyjJxXH2bj+FJsKNZb9xAuiPEv85Vq5raTQ2NHUG/rNDiySWi3qavFFje3vdnsGbFSmkh9Q8thtvZ4eXwCixEU4WxYpLRUVy76+PlGxjE1FMTgZKhttNpvYp6y8vLCwkIGvkxqBcHITH8Xmdeu8Xu/IUTAtPT1f1KTy85keCsB4EheeQMBfUBhdXERebU/65Ykn//Kkk9LSTO998F5OTnYs5BQXFzU0NNp6rXKPd83Djzza39+vpKJHHnn0lltu/uLLL0S8SUuL9hctLCict/seH370foL/vMks31y0//77JboUACYWcdFNlRUVFTmdTktPjwiH4to7ZCxUZs9qamx0OBxVVVWMKpy8CISTlahatbW3t7e2KpPHDLmD+CkqT0XFxbm5ufFdmwBgfMyZPcti6amrW6uThwWKC1NJacnhRx4mLlDL33u3t9e2fpE9ucnurbfeCoWC8koMofq61WK7uB2dNrnPOnPGjFeXLZs5c0ZhYXRy2syszCVL7r/yqqtXrfwuuuBfgv/KSSYcDpvN5ssuu2zu3DmJLguACUrULbNkXo+nq7u712oNBAKDK5xKSrRaLGK36poaZQ5kTDqEhEkpFAo1NTVZozPODdHDW2kVTE1NLSktzc/PH9DpCADGTXZO9qxZs595+jmR+ZR5L59++pmsrGytRvvlF1+ta2rp6+9TycNXLBbra6+/rpJnFt111z1OXLjwu5UrH33s0bAkBVTBe++7/73337vssj/GLmgzZs546qn/9dn6JCmsievYqcydvJnFi79+DhpQJy8vr+RVeeTeljx22H2HPM5wZR5wed/qIX8Diirk5uZqtIweB7BpqSZTdXV1UVFRR3u7xWoNbxj/HE9scbvda374QWRCUfNMSDmxLQiEk08gEFhbX9/X1zdk0hP/pdfpdAUFBcwIDGAiOPfcsw859PDa6ulOp2NabW1OTm5VZeUvTz7x5ltu2fdn+3o8ni++/GLunLnPPvucIcWYn184d86cSy6++OifH/X9qtXvvPtuaXGxTqf/5NNPRYY57rhjBxw8JzcnIX/EQiFGAAAgAElEQVQUACSV1NTU2mnT8s3mttZWh8OhGvSNlciEoVBo7dq1wUBAVEETVExsJQLhJOP1euvr6lwu13BpMCMzs7KiIoMmewATQ1l56TWLr7788j9dc/Xis889095v/8tfbjziiMM0ak1VdeWhhx6ycOHxvzju2OZ16y644CKH3bFo0akajfaBB5a2tbXf8Nfrjz3252eeec47y99+6cUXlAGEA3z26ef/+te/QiFJVE4kSTrggAPP+NVpyl31dfVff/Pt8cf/Qvn15Zdenj17du20WuXXd5e/98jDD2u0OrnpLXLOOefstvuuyl12u+NvN97U0dF+7rnnOp1Osdvc7bf/3e8uNhgMyg6vvPLqM089rYtOyhJdwufMM8/cfY/dlLtWr1695oe6Y35+tPKrxWK95eZbRRUqujR8SNpp550v+s0FseHczz//4tNPPllaVn75ny5ramzq6uo67PBDlbva2ztuvvkWl9Op1WglKVRZVXXZ5ZelpETnAwv4A48//vjCExYqs5J+9MFHobD0s5/9NPZ3mdJMu+22/m9Zt26dKIDPF51hNSyFDjjooBNOOJ7pHwBshaysrIyMDHGlam9vDw7qQRq9sITDzc3NIhmWlZdznZlECISTiUiDdXV1bpdrcGO9sq5gSWlpWVkZfUQBTCjHL/xFr633hRdfnLvdnPl77blw4S8eeOBBKSy9/94HHR2dV151msPhfPTRxzLSM5997imfx+f3+8vKSkRWbGhoOOSQQ4NB6aEHl+666y5DHvxf//pPWlr6EYcfJkXXkQ/X1k6L3bVq1eo77rhTmT9dXCTvvuvuP/3pciUQhqXwnXfd3djYtMN224s7P/3sM61WFwuEy99Z/vIrr+y666633Hqrvd+1/fZzHn74kT1232O//fdVdnhgyVJVWCUqRuI4y99dLp45Fgi//fbbe+55IBYIP1nx6f/939vXXrtYq9E4Xa7Fi6/9+bHHTJPLIC7p119/4/HHHbtk6YMHHHTAuoZ1a+rXxALhSy++fP8DS448/Ai9TidqV3m5+Xr9+v9kezye++57wGLpFVUu8esTTzyx+267xgLhq68uM+fnxwLhY489vnz5e3vsvrvX5127tuG99z448MAD8vJyR+F9BZB8RBW0pKREXP3WrVvndDgG1kjlENjW1iYuyJWVlWTCyYJAOGn4fL66NWuiS2MNlQZTUlKqqqry6LcNYEL69a/Pqamuvu32O5csefCEE473eX33PXDfnNlzL7zwvH/c/c9lr73RsHZtcXHRzTffcsThR3y3cmVZadn9999nTE3Lzc3+299u2G67ucMdWeScvX+61/y95oej7XwRU1wrolar7e7uevXV11TydbKrqyt2/YxEM6FkNpuNqdHGuhkzZypDHBXdXd3iinrWmWcuPOFEg8Fw5x23fvPNN/32/tgOhpSUabUzrFZrMBg8+OCDzz//1/FFij9UIBAoKCjYe++9ostCeDymtPTYChnihlajO/ucs1as+KRuTZ140ojqxwceedQRH374UX+fXafT9Vh6Vt137ymnnpyZmRG9T60OhoLLl7+blxe95q+pq9tz3h7DvT5Wi7W2pjYjI9Plds+aPfuAA/bLzs4a6a0CgE0RgXD27NktLS3d3d0quU0i/l7xa0d7u/gpMmGiSogtQiCcHESdY+3atUOmQVHzEB/LmtraITtTAcAEcdDBB+67YJ+33nr7pZdetdlsZWWlOr32ySef2WnnHW699e96ne7FF19a8clnjzz6316bdVrN9MMOO+zwIw7bc9481YhfMR980EH/+tc/n37q6eiyFlLo8COO/O3FFyl3ZWVnnvzLk6+97hrl1+v/8tec7GzltkatnjN79oknnbDDjjuIX0W15qknn4kds2ZazY477LDn/D2eefp/BqNx5qwZO++8c2VFRWyH8vKKY445cpddfzK4PAUFhfP3nBf7ddbsmS63c+HxJ2h1Wr/PX11VXlxUpNyl1+vn7bGbyKUnnrjw5ptvDocjV1x5ReyBXZ2dbpdTq1OrNWGTyVBZVR7rsCpeqz12333x4qvzzdFA+MhDj0hxEbSmpjp7w58pzJw1a86cuWed/auRXkQA2EI6na6mpsZoNLa2tCjLFcbfK+qrnR0dKXo94wknBQLhJCBJUsPatQ67fcg0mJeXV11Tw/wxACY+caU69NBDxL8h773kdxdvxTHP+NVphx12iMfjUeYCzY3rDPmzn/00mic3uOqqK2PZUq1RX/uXa/Ub1uMpLy///aWXxPY84ID9xT9xY96GaHfb7bfEP+lfr79OLw/nG2zfffdZsGDf2K9z5sx+9ZWXrFarXFtSF5cUxXKdqEjdefdtoswnnLhQPErUrvLy82IP3HGnHW+7/TZlZlFx8S8rL40NB0hLT7v1tltEnlR+PfmUkyNxNbFzf31OfHnOPffsIcsJANuupKREXNOaGhuVtQrj7xKXr+bmZp1ebzabE1U8bCYC4USnfJxsNtvQaTA/v7a2ljUGASSzwqLC4e7aKLZt3NIYG5KnGmr9npENlwaHPFRGZkaG0tVz+P0H/wniwl5VPWxvq1gaFFhAAkAC5eXlietVfV3dgEyofEnX1NQkEiPrE05wBImJrqc7asg0WFBQUFNbO+Sq9AAAAMA4yMrKmj59en19/eBMKIVCjY2Ns2fPjnWOwAREIJzQnA5Hc3NzdKHljb9yFmkwNy+vqrqaNAgAAIDEysrOHi4TetzudevWiXuptU5YBMKJS3yimpqaJEka3Cc7Ozt72rRp9BQFAADARCAyYU1NjciEA+aYETnQ1tvblZFRwgQzExWJYuJqb2tzDVpyUKTBVJOpljQIAACAiSQ3L68yGGxqbBywXeTD1tbWDFlCCoaRESomqP7+/sFDB0Ua1Ov1tbW19MMGAADARFNUVOT1ers6Owd0cJNCoZaWltmzZ9NxdAIiEE5EIUkSn5mwJKk3/syIj1ZFZSVfrgAAAGBiqqio8Ljd9o3XSxO37XJrR3FxcQLLhiERCCei7q6uwZ1FRT40FxYWFBQkqlQAAADAyLRabVV19ervvx88wUxHe3tubi493SYaAuGE4/f7o+3sG2+MDh1MS6uoqEhMmQAAAIDNk5aWVlZe3tjYGF+hFYFQ1HI7Ojqqq6sTVjIMhUA44YjPifi0DO5gLT5XfKECAACAia+wsLBPsNkGdBy19PSYzeb09PQElg0DEAgnFq/Xa7VYBnYWDYfzhby8RJUKAAAA2Hxqtbq8vNzpcIh6bPz2UCjU2dExfcaMRBUMgxEIJ5aurq5gMBgfCCORiE6nKy0tHTBZEwAAADBhpaenmwsKRPyLr9mKCm1fX5/L5aKRcOIgEE4gPp+v12odvAy9+Cyl8ZkBAADApFJSXNzb2xsKBmNbREU3FAr19PQQCCcOAuEEIj4wgUBgQPNgSkoK8/MCAABg0jEYjQVmc1tb24BGQpvNVlpSIu5NYNkQQyCcKEKhkNViGdw8mJefb+TTAgAAgEmosKjIYrEEAoFYLVfcCPj9vb29JaWliS0bFATCicLpdHo8nvhAKNKgXq8vLCxMYKkAAACArWYwGPLN5va2tgFrEopAKLKiVqtNYNmgIBBOFFarVSTAAYEwMyvLZDIlsFQAAADAtsjPz+/p7g6FQvGNhB6Px+3xZGZkJLZsUBEIJ4hgMOh0OAb0FxW/ms3mRBUJAAAA2HZpaWkZGRk2my2+ritJUn9fH4FwIiAQTggOh8Pv9w9oHkxNTc3MzExgqQAAAIBtl5eXJwJh/BZR7xWBsKysbMD62xh/BMIJQQTCwf1Fs7KzdTreIAAAAExuGZmZBoMhfmoZlbzimsftTqeRMNHIG4kXDocddvvAdefV6tzc3ASVCAAAABg1RqMxPT29t7c3fhhhKBRyulwEwoQjECae1+sdsr8o08kAAABgasjOyRGBcMBGp9PJgtsJRyBMPLfLJUnSgECYZjLp9foElgoAAAAYLRkZGRqtVlRzY1tE7TdaDQ6FtAySSihe/cRzezwDBhCK27SeAwAAYMpISUkxpaa63e74Sm8wGPT5/WkEwoTi1U+wcDjs9Xg2Hj4oB8L09MQUCAAAABhtOp3OZDK5XK74YYSSJImImJaWltiyJTkCYYKJj4HX61Vt3F9Ur9cbjcYElgoAAAAYXakm04BpFEW91ydqwkgoAmGChWQDPhupqaksOAEAAICpxDQoEAp+vz8hhUEMqSPBfD5fJG5wrUr+psRgMLBGJwAAAKaSwT3gRD70BwLhcJiqbwIRCBMsMPhLkUgkJSUlEWUBAAAAxopWq9Xr9QOWpw8SCBONQJhgwWBw4BSjGg0LTgAAAGCKEYEwxWAQgTC2RdSBRWVYBMIElgoEwgQLDA6EarWeFkIAAABMLRqNRjeoJVDUhCVJSkh5oCAQJtiAAYRRajWN5gAAAJhi1Gq1Tq8f0BaikidZTFSRoCIQJlxkUBO5Wv76JCGFAQAAAJBUCIQJNvgbkWiXUcYQAgAAABh7BEIAAAAASFIEQgAAAABIUgRCYKtFVCpJHvU5/s/LJxcAAACjgGolsLnCdpvU3has+yb4w1qp2RHu61ZJoYQEQnVKqjo9R1uWri0v0FVW68qmaQoLNRkZKjWjTwEAALAFCITAJkjtDb63l/s/+tS/4pPQWotKCkQCQZUUVqm0CQiDiuhqJWGVVqPWaVU6vVqv11bnpsyepZuzg2Hedik77KYxF6lUzFULAACATSAQAsOQ/L733nY/9qTv9Q/CPbaIXxK5S2QwEbTUKcZEF26DaK/VSEQKhFZ2BL9uUUVe+3/27gPMiWoNA/CcqambbKMKoiAIVqyIiN1r7wUEBRXBgl0vqJfeFLADAoIiTVBQUQQEwa6gCDZA6UiHbellyrkzu9gQIbuZZJLs9z7rFbnZyZ82mW/mnP+weXaSn287+3jbeRfZzm3HNW5hdYkAAAAAkLkQCAH2R+Vw5IM5wdETY0t/pME4EQWG5Yk9I0djkn3/MDxnXC3Ui49RurMkNGVhaNqHXMM6tvat7TdcZzvnPDavyNpKAQAAACADIRAC/E3080X+4c/FFi6lCkMEgdgz5mJgglg9H3KE4xjKaDvLQ9MWht5cKB7X3HHzVY4bbuIbNbW6PgAAAADIIAiEAPtoFXv8Tw8LjHmDBmJEkohkdUFJIr9fNqRM/Pv18e+GB1581Xnrte677uIaHGl1cQAAAACQERAIAQzx75eVP9Qr9slKItmILduz4N8Rxhj1ygjaDr9/8Ljw7Pmu7p3dt99J3AVWVwYAAAAAFkMgBGAi784ou/9JdXs5sdutriWVeJbwdmXtroqHh4XfnOvp/6j9wqusrgkAAAAArIRACLUcDU0cU/bwYBqRiSRaXUw6EIFjGC6+bHXJdT2ct3zg6dePq9PQ6qIAAAAAwBoIhFCr+Z8Z7HvyBYayhK9dnwVjEGmcBsfMjC39Pv/ZgbazL7a6IgAAAACwQO06CAb4q9Cksb4+L1I9DXK1cg13lhC7Xf5+Q8m1t3mevM9138NEyLaWqgAAAACQHARCqKUi82aXPzjAWFuCr5Vp8HdEEmhQLX9sRHz1mvzhI9iCelZXBAAAAADpg0AItZH86/flDz6phWQi4CPAMBxLWCn02lx16+6Cl0fxRza3uiAAAAAASBMcDUOtQ2OhiseeVNbvIbZa0UUmIYQhkhRduKzk5q5F0ybwTVtZXRAAAAAApAMCIdQ6wXEvReZ/pecfqwvJOMRuj3+zZu8VNxdOGS2efKbV5QAAAABAyiEQQu0i//K9/6mxhBUYYnUpGYnYJPmXLSUduhe9MU48pZ3V5QAAAABAaiEQQq2i+Z9+Vt1ZQexop/mv9EyobNxpZMIZeiY8y+pyAAAAACCFEAihFomv+CYy56NasgB9MvSnSNm8u+SmHkUzx+M6IQAAAEAOQyCE2oMGx4zTysO4PJgIIgrK5l0lHXsUzxwvnIT5hAAAAAC5CYEQagt53erIB58QEZcHE2VcJ9ywc69xnXCciEwIAAAAkIsQCKG2iLz3nrqrjNjtVheSTYhNz4Q7jLGjb4zF2FEAAACA3INACLUCjUfDb85lOLzhq83IhBt37Os7eip6zAAAAADkFBwfQ60gr1mhbtxKOM7qQrLSvh4zHSrHjqLv6B+0uBaOajt/U7ZtVLZv0/b41e2B/W7CNytg6xTwDQ7jG7dg8/OJw8kwrCXFAkDuUmk4rJWVKts3qLt3qiWl6pZyGpD/troSpVzDPLbYzTVowDc8gqvbiOQ5CI8hMwBgQCCEWiH26TdqaQWxOawuJFtV9pjRM+FdRiY8uVaPHdVKd8a/Xx77YqX8y0r5543q9gqqxBk5TmWVUbX9by1wROAJLzKSxDcrElq1lFqfJrZrLbQ8kYjpfDfS1N+FhSt7mv7oUvpY0vBaJO/gz0DyD4GaembErKc0y1anpf7S2Mpl8W9XKb/+FP/xF2X9XkaNU0VmFIXGVT0B7v8LHEsEjhEEfY+kp0HhhMPF5scKJx4vnX4Sf2QrhrXmhKmy6Zf4zysZNoH3g6rpaVY65ewa3Ev8h6+VLZuYRE4KK4rQqrVwVKsa3AtA9kIghFqAqvEflzMUlweTQiRB2bSzMhOOF09qa3U56aaVbo9+/mVk7vuxT1eoe0qpP8ywvHHNmSUM0Y8jeSIIzD87FumHZBqlMYWJyfFv/fGv14WYd9giL9+sof2S820XXSid2obhpJRWru7cXP7Ew9QfNUpNEUpZr5f1elibk63TgC1qyDUq4OrX4Rs1JZIrVXdadc8hX3nvh5RtOwhvwgecxmK2Cy7Ou//R5Df1b8JvTQ5OmUKk1L7oNaY/A/YLL3Xf9/C/3kLTynp2U3Ym9YRTWRFbHe0Z8DQRTOj5HF28yP/808SW1Kb0B57Xs6ftoquTryfVtNId0S+/jsybG/vkO23XXs0X0qMew3OEY41Mq++OiEgO+GRUJUSZ0niUhqLRrXuj2lJGZLnCAv7oxo7LLpQuOF884fS0PhiGiSyeX3FfP4YTD5nHaSzuuPkCaVJNAmFwwvjg2FnEdujPHQ2HvMOGCP9FIITaBYEQch+NRuMr1xhfk4pqdS1JI+T3HyvuXBKVjdtLbupeNGNs7blOKK9aEZoxIzLrQ3nDb4zMEIFnWJbYE7u+Ryr/qfxfwrKMYOxy9WwWX74uvnR14LkJwgktnbdcZ7/qGq6oYYrq18LB6IKl2q5wQufga4gYlyOMKxL7fkiejc13c/l1+WMPs511pnhqG6Hl0cTmMf+e1Vh04Xfy2k2ENeHrjGoRzts0+e0chLJuS+T9LwmboUP19GeAL2h+0FvQ6Icr5I0bk3rCNSb6wTKhZSvnLT1qvpHfqZv3ROZ+QVhnMhvRH7jzimuSLyaVqPzj8tD0aZH3P5HXb2HijHG5j+US3Rcxf1wBrTqHxVQGSEH/vGql/thnP8Y+XsEWvSyddbKz8422Cy5i84pS9DD2R/WvZo7RuEN/qcn6zWr6zadV3oucwFkMvRINA/uh1kEghNynlZXQUJxr4EnlAXF6EEZVtVCIBqL6EZVxKMBxjP6lTtKXDokk/dl3NNd7zMR/+iY4Zlx41gKtJMTwPOElc3aZHGscigk8jdDY5z/EPlshvDjBdcfNjk63cIX1zbiDvyOEiIKx4AqXxvd/jGo7/Oq2iviPa8JTP2Tz7UKr5rb/tHNcc71w7AnGBQ3TVD46XiSCGa9NRNVfaBO2cxAcRxiRSJm6/o3xDBzi1THnCZdVX/9npDZn8kcdm9R2mMoPVPJPqf7AM3eSuRpf9oV/9Pjo/I+1kvC+fZFZpxRI5XvSeOwC9cci734amfupeFxzZ9cbnV26snmFJt3NQQvQX0A2gbOc+4Zj1OxeKn83oVES1pxvBbAWAiHkPraouM7cqVT7x/yurEMIlWVt715td1DZsDa28pv48nXarr00ohoHQ6kbELhfFTZR2bTL6DEzI2f7jirrfgq8NDr0xvt6FNSjFLGbMLDtAFhSdRQrr95W/tDQ4ISp7vvudHbuQux5Kbm7dDKO8PTks+8Im4Zp7OtVsa9+DDz/uu3S9q7bbraddwm+gGo1gVM27q3oP7Bw0mRTBo7mKnnNSv9zz0feXKj5o0RI2b6oinGuyhhUGf9hffz+gaGps9wP3+28voMxnhMAchq+jyH3EcnBNzvB6ipSgKpaye7op0vC7y+MLvhUK/Eb09jSchXUmE+4r+/o+Bxbn5BGAsGJ4/wjxqpbS4gopfbw63eVF1t4ec3Osrv7hmfO8fTrLZ11QRruN32M6CsYlyBCSnjaguj7H9uvucD96MPiMSdZXRlYhtikyOzFoQtec912t9W1ZCIaDQTGjAm88Iq6tdQ4LZXA/DezENH4tMa/W1vW9aHI2+97+vQSjj0lbfcOAOmHQAiQtQjHFjdwXN/ZcX1H+ddVwYkTw5PeVkuCRr+K1F8srMyEu0o79ig0esycmfL7Swvllx/KHns8Ov9rwvJJ9qioAWNGEOWiH6+Ir7zV/Uj3vAcfIo4UTLqzlp4MbRKN0tCkudHFSz1P9HR264He97WUvptSWf+Q523t2vFHHWd1NZlFWftj+WOPG9NNeSGdUfCvjFhIafjNj2Lffu/p84jrtjtNHewNABkEgRAgB3BCi+Pzh7/g7HCTr//QyLwvCJeOCWNEEuUNO435hDPGiSdneyakoVlTKh4bom7ebURBq+aQEONZpUHF1+f52NLlBc+P4I9saVEpqaTHQrtN2+Uru39A7LsV+SOfYz2pn6oEGYjnlI17KvoNKpw8xZgXB5XCc2aUP9RX3byXSNbti6oQ/aMqqVvLy3s8EV+5wjtoKOtJV7MZAEgjBELIBWrpdm1Pubpjh7p9oxbwHXjeOaVcfgFbUJctPowtcrEF+ay72PRKaCgQfmuSFgoxpKZ5TFX5I46wX96hBr8qntS26M0ZgZdf8A8cowViREz5B9yYT7hxR0mH7kXTs7jHDI2FfIMGB559hcpMesaIHgLHEtYWnfvFnl+uLRj7bOV0u1zEc4RyoQlz1E27C18bxTU6yuqCwAJEksKzFtkunOi67R6ra8kEmn/EU76Bz9EoterC4D8ZY9o1Ghw1U1m7pWD8aL5xM6srAgCTIRBC1tJiyoYNkSULYh9/K69do2zaRf2xQ/1OZVDkCFffzR9Wn6vbmD+xma3NqcIxJ3H16zGsCfPmIx++V3rbE0xSDdk1tq6n7idHC0efWIPfJjZX3kNPCke1KL/vCcWYeSLUvJIE79FYi2JnZY8ZPRO2T/XdmU6r2FP+wMOhye8TyUaEjOkuR/SX0qZs3FNy450Fo4c4bupidUGpoT9Muz2y+OuSW+8unj2dLahjdUGQdvp7gPK+wc/b2p/NNz3G6mosFQtVDOznH/kqMdY1zbDBmcZgb3v0w6V7r+xY9MYrQsuafD0BQMZCIITso/lLI/M/CL/5TuzT5caavCplOJ7wbOJrPWu7IrHt6xh1DfPewgDPs8Vu6YzW0nln2S+8iD/iKIataYhS46EpbzKET3LVaW2PLzTtTe+gmn/j2i+/ni0qLr25u/JbSZoy4Zbdxpr12dZ3VN2zrfSOO6Nzv9ZjidW1HID+2lFfrLTbf9WSPe57H7O6nFRh7Y7YJ8vLHn6wcOwrxJbUanKQlQRO3binok//wslTa+/AUSVS/uijgVHTK4esZ8yZqb/T95Pyj+tLOnYrnjGBr9EpSwDITAiEkE1oLBCaPj3w0gR51UZG1ozGa4LI1CDvcIRw/L73P2W0vcHwrCXhd5b4il6Q2h7nuP46+38uYguqvSKcsnl9fPmPhE86gHFC9KPFWq8K1uWt8TakNmcXTRu/9+Y71d9KKxs8ppYeXZTNu0o69iia+Uq2zCdUS3aUdutemQYzYJjovxE4Jq5V/He4fozovudRq6tJFWKTwtPniye8mPfQ41bXAhYw3gDvLLFPe9XZpXZ2HNV8w4cHxs5INg1qlKoqoyiVqwuy5M+m0/rfa8bJU5Y1vvv4ms8w118p+ceNJR26Fb87nWvSvOalAkAmQSCErBH78qOKvsNin61kKGtMabCZdA5V3wxhjdkalKFlocg7X0Tf/4Jvebiz09WOjp34RtWYLCGvWa9uLyO2ZK81EZ6TV21Vt29nW9Q8EOrEM4xMWKJnwm1l6Ro7uqu0Q4/CmeMyv+8ojfjL738w+v6Xyb9eKcexjKz5Hn+GK67ruOEWq6tJDaIfBQuBp8fZzj9fPP40q6uBtNPfADLxDXpeanc237SV1dWkW/C1sf5BLxBOqGEa1HOgLDOaRrw2sVkT7rCm3OF1+SPrcHXr6UnQuIEcV3bsVH7do27bqmxar2wqYbTK9eiFmhwEEpsY/2F9afd7i956Az1mAHIDAiFkARoJBJ5/1j9irFYRNRbyTtFwmqpTqpyof4PKq7dW9Ho2OH6Gs8t1rjvu5BocnsgG5F+MsGpOMbKibFwttEh2Ro3U9pyi6a+UdOqupmc+oU2UN+ww+o6+MTaT1yekSryi9xPhNxYaaTBDB2f9Hc/SiFLWvTdXWEc67z9WV5MaPKvu8fkGDC16cwbhMviaLaSIwBsdR//Xt2jKVIavRW+A6CfzKh4bzKhcTS7caRqNxYnHZmt/qv2qC6R25/KHH8Z66/3r7dWIsmOHsnpNeO7c2Edfy2s3G3McBKG6u0Fit0UXLavo9Vj+6HEEy9YDZD8EQsh06taNZQ88GHn3UyJIaeq6Rohx3lTg1S0lvr4vhaa9436wh+vWrsSRd/Dfo/GYSemCGKd8Q0FTtrUvE3buoW7Zm55MqBiZsHsm95gJjnk28PI04+2UFWmwCs9pgWhpjweK584UWpxgdTUpQSQxMv+L2KeLbeddZnUtYAH9DRB+e0nwoomu2+61upY0UXdsKX/wf1p5rNoD+ylDYzG2wOHsdrWzU0epTTuGJGfbMkUAACAASURBVLAFzs43aqr/2P5zubZ3W2TeB4Hxk+Vv1xgLDPLVa2NDJHtw4rviCa1dd99fvcoBIPMgEEJGk3/9uaTjbfLKddb0/BA4ItiVDXvKe/aNzHrX0/9xqd2FB7u9uZcuzduaVDl2tLRTdyVtmXDz7sq+o+MzsMdM9KP3ff1fIGxNR2dZx5iouX53+UP/LX5zBnHlW11OCuivSFQNjp9SudJGyhfShIyjvwEo5xtoDBwVjjrW6mpST4lV9Okj/7jRmDpYLaoxWdB21Vme3o9Ip59dsztniw9zdunhuP6G4JTXA8PHKpv3VO+UK0sYja/oP1I8/RTxpLY1qwEAMgQCIWQuZd2qkptvl7/fYG3Pj8r231z04+/jP3R1P9I978GHic1tYT01I7VpX1g1nzBNfUcFZcseIxPOHCeekkGZUC3ZUf5wP80fT8OTkAr6EVv0w2X+US94eve3upbU4IXY50vl9auFZrUgD8A/EJ4zhmb0G1A46XUiOqwuJ7XCc98JTfmg2l2p4wopcnj7PeDqdg8Rkp6y7ixw3/WQ7ZxzK57oF3n3s2pNytBfLG1v0Nd/SNGbM4nNlWQlAGAhBELIUOqOTSWd7zCuDWbG4rz61yT1y74nn48vW54/chjf9ABHq0Lj5gzVzLg3yrAc36SFGZv6k54JjR4zHbulqcfMvr6jdxXNHJ8xPWY0/6Ah8s/VPx+fOYh+ECYGnp1gP/cc8fRzrK7GfIRn1R3lsSUfIxDWWnpAisxeHL5kivOWHlbXkkJa2U7/kJGMZiw6mPhv0VhcaN6w4JVnDzFcpZqEo08smj61om+f4KgpxmxGLtHr80QSIh9+HZr6uqtbbRnlC5CTEAghE9GIv/TunvFvfsms9QCMLt5iZM4X8i83Fbw4zHbhlfv//y1bEK/ERKgxliYZmsYdXsQ1aZrURg7EGDuazh4zkqhs2FlyU/fiN8YJGdBjJvrpwtBrs4iY5S0QOFYrDZf/b2CdOScdcl6rmShl1L+f7yDEeKubPvKW5SILFrm692SyaYpn2lFKZcU4eWTuVpm4sWiBtQhDNdbX/xnpjHZ8s5xdqj746oT4inVEqsYlPhqNiae1Kpo8lm9+nOn1EJs7/+mRXIO6vidHMipJ9FuMEKJx/pEv2y+7gqvf2PSqACA9EAghE/mGDKpcDyCT0mAV/cvPJinrdpV0uMc7cqvrtrv/OtNJbNFcbHVUbNkvSWYtGpel9m25gsKkyz0Ao8fMtPGlnXsov+1NQzQy5hNu3Lm3Q2XfUUvnE9Kw39f3KS0kG2Oispz+wsU+WRmaOsnVPV3tHKj+UvLE8/chfKqqlftpKM5wgtGHyaxkyLLyT5u0km1sUSNzNph7KCWSIBzTQn/mTd5yLMYdkVBT5ZQiVR1H+w0oen0Kk4tL1as7twQnzGDYarx8NBoXWh5R9MZr/BEpW/2P8HkP9tbjuO/xZxhNSDQTCpzy67bg66/m7Dh2gFoAgRAyTnTRe4EXJxtZJVMvD+h5jwZi5T37qbv3eHr3+yMTEmeB/fpLY1/9rH9D1nzrGiUO0XnDVQypXs+3xOmZsHD6+NJOPdLUY0YSlU07Szp0L5oxzsK+o6E3p8a+/ilLpw7uz7gsx/ufGWe/8mquXjrOytO4bLv4pPyRg/VDxn0XpQihclzZulv+/qfI/Hnxr1ZTxZhTlPx9EY7Tykri6361IRD+C6qofJP6dT6ezbqLra4lVYhNisxaHLxgouu2e6yuxXyhKZP1EFWNZmmKyjXwFr72XArT4D4k777H1C17Ai++nvg5WSIIodfedHW5jatv/dkEAKgBBELILFrFHl//p2hYyfQDd/3AV9F8/V5iKPU83v+PTOjscEtowgx57c6aLfjLGEfecfuVZ0lnmzk/5J+kNkbf0b2duqub91a73Xn1GZlw856SDndZ1WNGK9sdeG4CQ1MwvtEqPKes3xGa/Href/uk4+4oJW433/Sk/f5aaMHYL7g074H7Q2++UTFguLrRjFMMLNHKQ+q6HcwZyW4pl+mx3PKxnSlFCKWsb8jztjPb8c2Pt7oaM2nlu0KTZxM+4U+KcQpG9Q7pJZ5Ww4ai1cOLnoH95NWroh99l+gcfn13tHZ7ePYsd89HUlwcAKQEAiFkluDrr8WWrSZi5g0W/SeOJargGzhaP3Dx9O5rrOOk/1O/sWfgf0s7P8hoNZlJSGWVq5fnGfgkEVO+zIbYpn3R1HFG39E0zScUKteiqOwxc3K6e8yEZ78pr9qU2iGyikY1ldF/aOUVNMIyLGdcMUtyQulBsHzwtZnOrndwdRqk6i7+Sn9cVD7wWmeC3dnpdqFli5LOPZR1u2p8NuQv90XU7VuS3QhkOaPj6Ma9Ff0HF74+mQjZ8KWQmMj778trt5CEh8LSWMzZ6WLnLbeltKq/YvMKvE8P3nPxjbQimmiDGY4PTXnH1a17NnbhBgAEQsgg2t7toQnTjTFp2YIjROV9A0YZ1wl796sa5Om49ub4Ayv9w181molX53oUVVX9oXuHPSkef3rKKv6byvUJXym5OV19R/VMuG/saFozIQ37Q9PeYiibkiYlikoVRd8w16SQb9CALaxvnM7Qo1OoQi3brWzapu0JMixLhIQn5CSMVE7dicx9x3V7RvT3E086M3/4/0o63M8oSfdVIqy6e5tJdUEWq+w4+lHowldzZ+AoVUOz3zW6tiT4Rado3GEFnn59GDatk5/F1m3c93Xx9XkxwXGtRODln9fEvvzCdv4lqa4NAEyXPUfeUAuE3npDXrWZ2KxYg77G9EyoVWZCTfM8McDIhITzDh5GZSXw3GQiiAmeXqVxRU+D+S/0c3a5M9Ul/5XUtqrvaA91a3rWJzT6jpbe1L0wjT1m4ks/i3+z2vxHp2pUjnON69ova++4/Aq+VQuuTh1i/2O9eEXzl6nbd8W++iw8e378qxWaP1qtNb4SQtjQ1LednbsS0WnmZmvKful1tvOnROZ+nXTnHqL6fAyjYXn62k7/uFDON+h5qV373FiqXln3c3zpqsSvolNNdvXswjdrldKqDsjV4+7QtHfV9TuZRKolhIa10KxZCIQA2QiBEDIFDVeEp8/JpsuDf2D1TFg5dpRh9mVCXsofPoIrKvYNf5lWRIyD44NcMNE0GpP5ZnU8Q/o4b+ycvrJ/J7U9p3j6+JLOdylbdqen76hsXCes7Dt6Whp6zNDgtLdpVCU2M99aNBbnivNcd3d3dr2VP/yAbR54Nq+O/iO0PN51xz2xL5YERo8Lz/mYUYgpnVeqEEGIf/tj/Lvl0hlpmVx0SKzguOGGyHtfJLsd/SNVUmKMv2URCGs9nlM37fH17V80dRrDZX3H0ciHi7XSikRHwCqq0Lyh6/Y7UlzUgXHFDVx3dqp49OkE4yvh+djiZVr5Lja/XqprAwBzZeHBN+So+LJv4yvXEDE735NGJhT3zSfUMyHD6gcueY/3kc450//UM9GPV9BgWP+2rGzN//uvaFXLiKlsocdxyyWe3v/lm1q24pZ4xtmF08YZ6xOmre/olt0lHXukoe+oun1T7NMvq9G/4ZAopdGY/ZIzPE8PFI87NbHfYaV2F0ht24feeN3Xd6Syaa+eis0phiU0KIfnvJMpgVD/Ujm6BfHaTFiNM2fa/0DSiM0WfntJcMpEV9fsHjhKlVj0k08ZjU1w9DpVZUeHq7mihimu6185O3UOjp2sbC4hfAKnZjhW3bE7tvRr+yXXpL40ADBTdh58Qy6KfrLIaC5qz9r3ZFUmHDSaYVlPr75V8wmlM84rfvus6NcfR99bGF/5XXzVJuqLGwPhCMvWtYsntBBPa2O/6hLx2JMtHxontWlfNG28MZ/wt7T0mBEre8x0vMuYT5jKNevjy79TNu42bU1LPcYzsvuhW70DBxKXt3q/y4rOTncKx5xY1uO++PK1pi2HyHGxBUtpvwCxZ0QvB65eIVenQN1UwrDJXQilJi+5DllMj08a5x/8ou2sc/imFgyeNIu2e1f8m58SPe+palyR13Hd1Sku6mC4ug0dV13of/Z1hk9gF8oSGorFl65AIATIOll78A25hSpy9KOl+qGt1YUkx8iEvH/AKP0BeXrt6zHDcIKt3UX6D436tbIADQQ13262sCFx2dlCL+Edh9po+lRmwldKOqatx4yobNpVeZ0whT1mIos/Mq2XDDVO8Oc9fqd30NM1DvDiiacWzXy9pMMt8W/Xm5IJCccr236L//SddNo5yW8teYTn9Q+ynuaSfNKJ3YaLhAdDSKavzWMqo4XSxt2+Pv0LJ09l+L9/cLLn1IG8eoVWEkzwjU0VRTilhdBq/7Ve0ovYrrosMO5NRtYSKpsVYsuXMkqMSbiHKgBkAgRCyAjqb2uU33aQHJgvpD8ElRg9ZtTfe8z8jtjyuAZ5lX9sYVV1h2T0HTV6zHQ3rhOmZ33CjTuMvqPTx4mnmn+dkMaC8W9Wm9Xek0Zjzi6Xe/sNSvJyLt+kReGEMXuu7qxtKWWEpE+CcEQrC8rLf8qQQEhjUSYWSzbKUY0rKs7KGcVpQThOLS0vvf9e49J3InFIVbk6xZ7e/YnTk/LiUkbfXYTfXixdNGH/gaMCSeHiLqaKffM9lWUiJhiWVMeVVxgL2FhKOukMvkUD5fvfEtlZEZ6Tv9+k7tnFNcAK9QDZBF+3kBHktRu18opkx5hlCO4fPWayitT2HCMTdu6RrvmEkrJhZ0lHPROa32NG3vir8tsWwpmwo6OyIpxwhHf4sISGTh2KcOwpBc/0K7nlQSae9Fw7Ax/77isX0zMl62pUk/LbHnVnGcMl986hNE2LK2YpltBAJDxpUYIDaylVhCMPz3ukF2GyOBAaV6hU1jfgOVu79nyzPzuOsg3dxCUxMVM+SilF5R82MGpit1U1rjhPbJvgLOUUIg6XrV3bwPINJJGzV/q3XzAkr/8ZgRAguyAQQkZQ1u2goRixZ0TrfBP80WNGz4RPDrR8fmB1Va5POL60U3clPZnQJiqbdpdc3614ziShdVsTt6ys2qTtqiC2pMflUkoE4u37GFenkRl1GexX3ui4YV7otbnEluzYKsKx8W/X0WjMtKmSSZBXfEsjCrEn97YhGndYU5MqylGEVGPIscxV3jjD81ICeE7dUlL+ZN+iKVOJuO9zbbTtzfQoaKDhcnX3lgRnRlBV5eofJjQ7OtVVJYCIp51GxKnG2YdDXvonRN8Ryes22tLQQBoAzINACBlB078mmSy7knYIVZlw8Bijx8zj/bLu0Ult2hdOH196853K5r2mtT85CKoRjyvBFZATp2xYVbkefbJoXLFdfKrtClM7JRDO3fPuyHsfU388wcUq/xVLtL3l6vb1fFOLF2qjgfLQ9FnJXh7UKPHa+ZamZW/IJcZS9e98Ep7+urPr3fv+KkvmEKpl5crW7STBqfKaxh99GLFnxBVdsdURJN9NK6IJBEKGiavKqq1pqQsATINACJlAU0t352ADiaoeMwNH6X/09O6XfWNHT29fOPPVsu495ZWbjEtPKXp9jFUcIrbzTs0f8yzf4gRzty1vWGvC+4oyRGRct3VKdOmwhImtz7Bf0i409UOS5OpqhNBYRNmxxepASP0jn45/t44ISZ1BoJrKF9UXj25pVlmQU4wPNFcx6Dmp3Vn7Bo6ybFZ8fdCKmLojkGggZBihdaZ8BLjGzVmXVy3bmdBgF8Jqe3cwVM26rzyA2gyBEDJDgi3mNUoVRT9grDwlTI3/TfQwoPJ2+kEDxxnfx2k7eDB6zAj+gaP1B+h5vH/WfUFKp5xZPHta+SO9I3M+I5zAmLeiehUalxmWunp28A4cwuYXm7txxrhCuNOElc1VlTuige38/5hR0X6I/drrQm8sSHozhIajytZdZpRUQ1SOBJ4b7n9morHkY5KfL0UTjm/KFh5mTmWQc0jlUvUV/QYWTppMBBtXWMDaHVowlOEDR7U9WxlVS3SqPKVC42YprihRrLeYLfIqm7eTRIa6EFatKKVKhAiu1JcGAOZAIIQsoUfBWJy4BfGY5sJJTcVjWnJ1GxrH+om1VFBLditbN8eXb1R/26p/qzEqIYKQ7Di9BHGE0XjfgNH6Q/A8mX09ZvgjWhVNnx4YNzowYqy6vczoj2fK86aqNB4Xjm2S98RDzo63pGRIbSys7fAnH/6pokhnHc/m1zGjpv2JrY/jG9dRt5YnFbaNeTuyttVvXl0HoldI/jkWVFb37Iwv/To4blJ08TfGd0ryB+VEdVx9RbIbgZym74jCb31kv2iSs8tdRLIxfBYczGhBX3VuTrk6GdOXhRC+RZ34tz8ndFuW1fbupZEoAiFAFsmCfSgAjcvEKTiuu8h1Z1fp9LbJTKtQd2yIfbksPOed6IdLtdKAEW/ScFKZrew7Ouj3HjNWtxGvLmJz5T3Qy37RfwIvvBR+e5G2109EsXKYVvW3RSmjalSOc/ULnXfc6L7nbq5+qg56tEAplWNmDBnVxGNTtRQYf9gRXL1GyuYSkuzVV1Yr22NOTQdCBD7+1arSLj32e/dqZTuVTeuVtTupQo13RfJPtqwKzRvZLrwo2Q1BhlO1pE4tGTtVrmLgs1K79lyd+qzdodJyktntu9RdWxMfC8MWOEiRO8UVVQNXt65eVUI3JfpXdpzRtBRXBABmQiCEzPBv4/qosayZeNox3mFP2M69NPkueVyDpo4b9J+b48s/D4x9JTxrIQ3K6VjfubLHjH/QGP0PxloUmX3gckBCyxMLxk50df8q+OrrkfcXazvLjAyQ4IVWIwdSPQcSieda1HdcfaWz842C2TMG/3GnpmzE6C/KHZmyjpecxDVrwCxdkfSGCI2GTKjn33CsunlXaO2Mf9wta6xEzwumXflW4vZrLubqoqNMjuMOL1C3liV1dswYOLq3ou+AwonjGcmVaNayUOInp/TdjkNMtlWvqYxdfaI3JZovSuMJLq8BABkBgRAyAcvXa2TMDNyP/v2uxpxdr/I+/RRXXN/cuxRPOatwwpmOmz6o6D1Q/n49kZJt/X9oLGHUyuuELOvp1Tfrxo5WEU9qW3BSW7XXhvCCebFFn8ZX/qj+Vk6pyiiVEzv1wzv9YerHPRo1js/015QYx216ZuCaF0knn2a79Bz7RZew+XXTUKpavpdGwyTJK4SUIS6JK07h2Ce2rkkbT3VfDY41vQ3sfqii8kfUc/XontJ7AespmqvbTcEJb6lbSpK5TmgsVT/7I/t/ZnKNCuSfMz4QVgulGRVxeWMoR2IX/Vii7QnRiJLiigDATAiEkBHYegf4stGP5l1335j/4ihixlLgB7xb+4VXiMceV/bwI5GZi41MmPJDakJUwT/gJaPHTBb2Hf0D16ip+8773N16qHv2Kr+ujq9eKf/8m7ZtL42FNH+5FouxLjfrcBGbiz28SDyhuXjMSdwRR3JFJqf6gzOGLamKCWuvkRRnrQw66rOU8Twoef+7nz+8udWlQGpRRebq1s174v6yO3oTLondO9H3qKxv6PNsXSfJhmmEWSzh5qgG7NMAsg12oJARuGb1SJ6didE/ZvTRaMx2fpv8Ec+kLA3+ftf1mxRNnORr3M8/8jWjXX6qpxQaPWb0TDiK0TRj7GjWZkIDEbm6DfUfqf2F+/6GxrRQkJHjxO4gkt1YrsE6XGEdYndSGkp2ZpGs0WgKz3bTqJy6jWcNqj8PUWeXy123drO6FEgHZft2T69+4VnvRed/ndQADWPgaIn6W2mamoTVVpqvLNGTa5QhNs74pgOA7IFACBlBOu54/fBd2baLsJXvSVXlGubnv/Q0caZjWV7icHuHPkVYzjd8QmVjjBR/k7FGJvRVrUVh9JjJ5ky4HyKxrtQPvk1MZbxP+rlliRaIqptT16+Fqmv3mnNCPduaFf2pMg3arjgj/9mRDJ8p7x9IKWXndoYTvcMG7Fl+Iy0PJRXnsiUKVmsIaIYNGa1GINQ0rpGHdWbQBEgAOCQEQsgIbHEj4YSmypYdVW9JKiuu7p2Flq3TVwEnegYP1r+B/cMnpicTEk30DRqj35GRCbOwx0zmI5KdcLwZWYtTNvzAMLckv6F/0ny7td3bqzcc68BU1mP+Qo7pYKwoE7Vf1a7glVfYgnpWVwNpQRhtb1D/t3jcqXm9e1Q88hRhbelbHtYixJnwbGGWVUtDtDyaynKqR/MHqvG1aPSgzvWXEyC3IBBCprBfdF7k3U+MP6kad3iRs2vXdFfASd7BgxlNM8aOpi0TDh5j9Jh5vF9KFuKr3Yi7kLHZTZjOwnHRL5Z7lDjDmz8CVlm3SfltG0k+EHIsW5xnRkVpZPQQNhYXdd/b1dOvD5tXZHVBkD7atkDVH9zd7op88FFsyQoiWTnCPA2MSdQJfq3ot4pqWmlJiiuqBmXbzgTPW1KNsvleJg192gDAPAiEkClsF57PHfaCtidI43H7BefyjZpYUARn8w4dqh+n+p9Jy3xCIxPy/oGV6xNmc4+ZjMU1L0y+9yDhOfnHDfGfl4sntjWlqr+KLl6klUeJPbmJspQSu8Q1yYZARY0RZVRRGaoSG2+7+HT3g3fZL7rShN4/kF1+j0bE5fUO7bP30k7UH8+awZ81wnrqVOP0FGGUrWsZ5rIUFpQwGo+qG8oSTbOaxnryiYBACJBNEAghU/BNW0pntwlPm6cfJkrntbFsFKWeCYcN06Oaf8SracmELKMSn9Fjhnqe6I9MaC6xWZOo9kWyW2FZrcIfnvWe6YFQ85eEps9hku+OqAdCm41v0NCMolJJPxoWCJvv5Oo2kNq2dlxzuXhGeyI6rC4rO1GGKon2OtJvmfiN08RYZ4hWnQiQTj3bdXcn/6CXiT2X3wykMJ/1SDSkJva1QuSN61JeU2LU3Vto0E8SnKVMVa6wXqq7wQGAuRAIIWMQztXttvDM+cTpFE840cpKOMk7ZChhWd/TE9LTd5QYPWZGUap5c6zHjNWEpsfpBzPJb4fwUmjyLP39yTdpkfzW/hCaNk1etYEISR85aZR1uoUjW5lRVApRTeMbFBZOGS0edzKxpaNfVM4yojUnNKnHcHwig6KpogqHNzChx5JZCEvDQRrxE/u+t4Hnkcdii7+MLV2dwwNHjVMhjYuUn3cm9EIQIi/fULmUq/VXTeW1a9XyMuP0ZSIIwx3eKMUVAYDJEAghg0ht29nOOy3+7a9cvSYWl8JJlT1mGP/TrxAx9esTVs4n9A8aQ5jKHjMZcASQG/hWLUie7a/LmdQQx6rbSvxPDS8Y+4pZ167V39YFnx9PiJD8YEkjaLVsQNxeM+pKIcKxyvrdsc+/kU49z+pashtVFKFRnToLprIFdRMbhUj1Z5+48lNdWDXoUUf782QN8RR5Bj1ecvXtNJ70pzVTsd5CvsHh8g/biHDoQKh/WNStW9Wdm7gGTdNQ28HJK3+h/hix2w99U0qJQxKOPTz1RQGAmRAIIYMQ0Z73yL2l3R6tPO1tNVbyDhpk9JgZ8Wp6e8wQY31C9B01g3BUE65BPWX9jn3LmSSBSFJo8nvSBec6r++cfGE0Hi5/sq+8bgexmTHTRlXEk1tn0PWff0c4PjBijO38c8UTTre6lizHssRbh7izs7XsgdjO/Y+z+w2B56cZ5+ByEeHt3OFNGOazhG7N8cq23fGVP9stD4SaElv2BZPgLlQPhKIkHNEsxTUBgMky4LAb4C/0YwL7NfOYeNzqQipxNu+QIYxGjR4zacqEwr61KNB31AxscWO+WRNl7VYT9nX6q68wFQ/2ERo3Ek87O8mN+YcPDc9ckNR63H+geljlxFPamLCpNOBYdXfAN2BI8YwZDGYPJkkzYTh0BiG8p9fj0cVfKT/9xoi5eXAintqMmcj/PnfyoAhDI2rsk8X2y65KR2X/Tt2+Jf7Fz4RP7PtIo2z9Ai7jh68DwH5yc58LWUyQPI8+zNgz5p1Z1WOGkH3XCdPQd1TlfQMq16x/HD1mkkdsF54RnZvYKflD4jl1p7+06/0Frz0vnX5uDTeixQMvPusf+gphRXM6a6oq17CudPoJZmwrHfQYHHn/8+CUSa477rG6FsgsbHFDz4BepTf11HNFTg4cFVufQXjBeHSJfPgFPvzBZ56+ZcRdkPrS/lXko4VaeUWCVwiprNjOPJF1JbziIgBkhow57Ab4HdeoudUl/B0neYcOJSzxDZ+Yrh4zvG/gaEbTPOgxkzT7eRf7Cl9kgpopLxyRBPnXrSXX3+4d0c/Z4dbqjuzV/KW+/n0CL00nnJhoh4ZDoYoqnn4MVz/148pUzbhMmvzTSPTNcL6hL9ouuIA/PMM+7GA1xxU3RG9bHBw7k9gSmLGWbfijWgjHNI6v3EiEQx99EY5TN2+LLJrvuLZTGmo7ICpHw2+9R2VKpMQ++JwmnnQGpjwAZB0EQoAEGD1mhlBC/OnpO/r72FHKMOg7miS+RQvppOOji781q3uhvh1td7D0tkdjn3ye99hDfNNjE/o1KkcWL/APGB776iez2xSpjquvNG9r/3YnGn9MQ3VHGfVFTSie59VNu339BxRMfM24UgrwB8J6nuwdXfKVsmFXIqkpu7BOt3TmGfFv1zKJPDRCaFQNTX3LcdUNDGfNxyS+7PPYlyuIKCR0a1Vji/Olc09LcVEAYL5c29sCpAoneQcNZij1D5+Yth4zRt9R4/AIPWZqjggO+9UXRRd/Y+ZGeY5QGhw/O7roC/t1l7s638i3OI5IB54RR4O+6CeLgpNmRhd9RkMKkcxcnosqKt+0gXRWOxO3eeA7khWx9dHs+UWBZ6aa0ghH/xCFZyy0XznbcU3H5LcGuYRreKR34KOlXR7NxYGjrO2is4Lj3zAeWgJfIkQSo4uWRr/61HbWhWkobj9UjQVGjaOBeIIfeaqq4tFNhATPkQFAJkEgBEiYngkHDzb6jo5MW4+Z3/uOosdMEuxXXOt/6mVtt5/hzMvVhBCbTd1aHhj5amjCm8IJR0htzuCbt+AaF3KFhfqbnUtgQQAAIABJREFURNm1S920V/n15+iXy5Q122hU1o/tEj3RnjhZtl3YTj+ANnmzB0RZV/fbw2/M1/b6GC7pdyNLqEx9A4ZLZ57F1TnMjPogdziuuzn8zrzwjIXEnmvrm0ttz+Wa1FPX7WQSadNCCA3HA8+Mlk5vR8R0j6GNf/VpZN5n1RhbocqO665ieFzzB8g+CIQA1cHZvEOH6v9OXyZUOf/AUegxkwy+URP7NRcGX5pBOLPb2fMs4SX9iC32+erYJz8Y8z9dknENkFIaCdOQzFBi9JDQb2bK8hL7oZS4ba6uXczf8gHvTZaFo0503nylf8QEYjehQSgRePmnTf4RT+UPfyGD3tsmze1MOULMP7+QOTjRM6BP7MsV2i5fQsEpe7CeQsdl5xtdyviEAp7+RROd/1lk1gzHzbelura/opGgb/DIykENiQU8ReUOK7Zf+p8U1wUAKYFACFBNRiZ8Sj9q9A+fQAQp9T1mWEYT0GMmOcTdo1t45jxaHjHzIuEf9NxudMmv7CYf1aNgpPI+OWJL7Q6WxuL2y88TT0nrjB1Xj26hGXO0XX5TDtP1T1Bw7Jv2yy63nXNx8ltLnn7wHV/6Zel9t+kft6Q2FI87b+5kO/dyk+ran9FupLS89IGelSOQE1qZvno0yuY58x7pzdWxbIVxoflxnn4Plt3Vh1DOnH68GcN+w3XBCW8aJ4wS2R3pj13jKvo+LbZpwx/ZMvXV7RMYOyr60TeJD3GnxmiFtumsEABMhEAIUH2c6B08hEGPmewhtDrZ0eHS4ItvEC6VI9BI5XKF6Tl6pZS4RPd9dzLpbMpCFb5pK1f3m319Xkzw+sYhsEQ/LPY9OUiafwrJKzJhg0niOGXdNnn1piQ3Q2lEOuFUpqZLkxya/rwFIuHXFur3lJLtU5Wt53XdeZeFgVDnuvWOyPsLIu99RWw5NQpROuUM2wVtwrOWJDpmQeCUDbsqej9ZOHUKEZ0prs4Q/XSBf8hLJPFONvruyCG4bu+Spr0fAJgNgRCgRqp6zDCMkQnT2WOGIZ7/DUSPmRpw97gz8uZ8rSSUGyPQaCzu7HCl7cwL0n/Xrq63hV5/S9lSmuha1QdFJDG2bFVgzEt5vQckvzUTcKwJQ4sjmgnTLA+OELMa5x6AohLJ3F64NSLYvUMGxFfcaNYV6UxBONe93SMLPmfiiXbNITZb+J2Puf598oc+k+rQJf/yfdk9j2kV0cTHJNN43H5le/H0lHe3AoAUQSAEqCkjEw5iVM0/8tV095h5oj96zFSX0PIkV88uvv+9YEqMsZiicfW8eY/ez3AW7MO5w4503nq9r98oc47R9c8NJ/ife812ySXiCW1M2CDkEOGYk92PdK94ZFiODRy1tTvHdlHbyNufJjq7mOgpUgw+P5mrW5z3QO/UZUJl869lt/VU1myvxlVZSomNd/fsToRc6wAEUHsgEAIkwZhPOMRYi+KZtPUd5f2DxugHA57e6DFTbe4ed0feWxD/dl0KL62kATXawbsfvF8/VraqBNdtt4UmvaVuLTNnJiHHaSXBiv8NLp79VvpbKUKGc3W7K/r+ouiSFTk1cJST3PfdHf3wK0ZOeGkN/WYq63vyORoM5fXuY36LLIaRVy0v6/ZgbNmqajXBorG4o+NF0tkWjFYAALMgEAIkR8+Ew4bpX9VG17h0zCdkGZX4B45hNGpcJyT4CFcDW1jP0693yXU9snp9MxqL2c47xXXPvRbWwB3W1HV7h4q+pl1uJaIQW/BVcNIr7u73m7JByBms0+MdMWDPhTfRQDwlTaEsYmt/gbPzFcFxs4kt4Qtr+sNXqG/AaGXTtvxhQ9niBibWE/nwnfL7HlfW765eS2RF4+p7PU/8l/ApaKQMAOmCo0mApHGSd8hQo+9oenrMcITReN/A0ZRS7xMDGRbXCavBfslV7oe+9A8db8rCCRZQVLae2zt8EOvKt7YQ1113hWa+q6zZzghmfI8QY0icf8iL9vMv4Ju2MmGDkEPE1me67u/i7z+KcDl0AZlweY8/Hl3ytbphDyMm/CFijcmjoYnvyD+s9gx80n7J5clPH9BKd/ifeTYweioNK9VLg/qXkBrPe+RhC0crAIApEAgBzGCsWT9EP6b1DXslHc0Y9vWYGU0oY6xFgUxYDaznib7xb3+OfrQsJWsDppR++KWp+YMfF09qa3UpDFtY33VXl/L7BxHKmzOhiefUraUV/QcWTXqdScFwOMhqeQ89HFv4Wezr1UTKndUX+cbNvIOfKO36EKNWZ8wCYYjdHl+5oeS6bo7Ol+bd11M4rnXNDue0QGlkztuB58fFV6wngkSqeXLHWPnmynaue3rW4K4zmuXtlADSDoEQwCSs6Bk4mGrUP3xiuuYTSr7BY9h8j7vnf1N7X7mFOPMKXh6556qblV+2Z9fS3jQec9/X0dW1m9WF7OPs2Ck4foq8amt1jyP/DZHEyOxF4Wveclzb2ZQNQs5g3YWeQY/vveq2xDtzZgXHDR1jXy8LPDdZz3jV+kVj30VpaOJ7kfeW2M5r5+x4jdT+fNZTkEi/GarE1I2/hufPC7/xjrxiPaWkGsNW/9hIXOab1/eOHEZsrur+bmYjNBrVAoG03R+rv/Q8jsbBYngLApjHuE44mNE0/8h09ZhRBV/fF/gjjrRfdn1q7yu38E2PLRgzsrRTD3VXkAjZcH2VMjQWtd9wjnfwUIbNlBDL5td1db+l/L4Bpn2VEELjjK/PcOnM9lzdxuZsE3KF7dxLXD06Bp593RiFkTs474BByuoNkQ+/IvZqpjJj9KhEK+LhNxZE5izmD68rnXOaeMJp/DFNhMMOI/l12N/X9qSqQiv2qHt3Kpt/k1esii77Mr7sF63Mx1BOD5Y1+aJSNeIU8kf0F5odV4PfzmTEZg+8MDY4flI67kyjjEQLJ79oO+s/6bg7gH+HQAhgKqPv6DBjzfoRaVmLgmOpP1r+UF+hZSv+SMy8qgZb+4sKxj1T0ukeGlIzfSGKyjRou7Jd4egxxOqpg/tx3tQx9Nob8ZUbzbrWqm9HXrPFP+zp/OdHYZFr+Dvi6dUrtugz+ectTFZd2z844vbmj31Wub6zvGJjTTqpsoTYJT1aKOt3yWveZpi32AIn63IzNsefPXupRqNhGglpPj8NxRlWIAJntIGp2SdMo5TG85/uY7/ixhr9fmYjhIbCNBhMx31VBkIaj6XjvgAOCoEQwGxGjxk9E7L+4WnpMSMKyvqdFf/rV/T6FAbLQFWH/dJrC8YEyu7qZbRSMGnQo/n0NBiPSueeXPjyKLbIzKaCpmAL67sfvKu0yyMMFcyKb0S0BV+dbb/qUtu5l5mzRcgVbFF9z+DeJTf3zLGBo3yTowtfe7nk2k7KxpIaLopDCMNzVee2aEhTA+WUlhm7j7/cgBCWIVyy/bT0NMjInn493d0fSGo7mcx4a6XlLCGhDEcxZREyQaYeAwFkNU40esywxPfUK2nIhESSwm8vDl02zdnpjpTeUe5xduzCut2ldz+i7fBnYrMKPQ1Gw/Zrzi589VXWW2x1NQfmuPrawOmvxpf9YtqETP3zEpJ9Tw4R552WsY8arGK//AZX1yWBl96o7qS7DCced2rhpJdLb79X2bA32Y+S/gliuZR866gaJYqn772ex7EQLkBOQSAESA1O9AwcRCk11qJI9dhRfdsyG3hurP3yK1kPDqCrx375tUVuR3nP/xrNUTKq76hGqRJ33n5V/oiRmZyLiDPffU/X0mWmdjYShdg3qwMvveDpM9jMzUIuIHm9ekUWfKFs3EUSX60hG0hnnl/8ztTSrvfEv11njALNNIrK2Ii3/8N5Dz2ONAiQY3JqZwqQWTjJO2iQ0WMm9fMJ9QOj+Pfrw7Nmuu7IuQ7gqWc7++Ki2Q3Kez4a/egbIkoZMRRNVhgb6+3zgLtXL8Jn+pUQx5XXBU59Nf7tWtMuEhqrEoqBFyfZL71EPPlMc7YJuYJreIR3aK/SWx5iaK4NtxNanVI0c3L5/Y9G5n1BhMzYF1WisThX7PE+9z9nR4xDAchBCIQAqcTZvEOG6P82MmHKx46ywQnTnTfdTFwFqbyX3CQ0P75o1hu+YYODL06jMcXK5SgopdGo0LKxd3g/++XZ0TyWuAvc93cv7fKoMWXJrPc4x2pl4Yr/DSqe8zYRk5v1BDnHcX3H8Lvzw9PmVbszZ8bjjzi6aPrkimGDjH1R1NJ9URWN0lhUPLNVwXMjxFPbWVwMAKQGAiFAihmZsLLv6PCJKc2ERBDk5WtiX3xlu/jyFN1FbmPzCvOHPWdrf7av39D4t78alwo5Nq0VGP1jZH2v7Ox+nffJJ7jGzdJ678lxXHtT6NXp0SXf1bAlxoHom4ouWhp8ZZz73ofM2ibkCt4z4InYV8u1beVMhncJrj7iLsgf+qx06um+PsPkVZst2BdVMfZIceLk3T27eJ54gi2oZ0ENAJAWCIQAqWf0mBlKWDa1PWYIQ1UmNOtNBMJk2C+5Wjz19MALL4QmzlB3VhhjfdNwKEYZRlGopoinHJ3X+0HHNTekqcedeYjkcPfsHvviHnNH8REi+J8eZb/4Qr7psWZtE3KD0PRYT7+Hy+58glA2xwaOViKOazpIbc/0jxwZmjRbKwkap1rYdMVCPQoqCsOo0nmtPY8/YjsP/X4BchwCIUBacKJn0CD9WNmX0h4zHBf/4nutbAdbkHHrE2QRrqi+d9BTzo43BUaNCs9aqJUEjBifolhIKZVV/cBLOOZw152dnbd2/WMt6axjv/Ryqf2E6EffmniRkBE4dVtpRd9BRVOmMKx5m4Wc4OzYNTpnQfjdTzOrHZR5uLqN8ke84Oxwk/+lMdH3lmjl4ZSfojL2SAohmnB0k7xHejhu7EAc3hTeHQBkBgRCgHRhJc+gwUbf0eETU5QJCccp23fGVv5gPx+BMFlCq9YFYya67vwqOPG1yHtL1B1lDGWNroZmvXCqRmWZETnxlKbOzjc4O97MFmb5qybYXffeGfv8O2O1ZfMugxNRiry9OHz1DMcNt5q1TcgNRLR5BveLfXudtjuQewNH/yCe3LZoUtvY1x+HXp8a1mPhngqT90VVFH2PFCdOUWpzrLPzjY6rr2MLMUYUoLZAIARII07yDh6iHy77R6am7yhLaDAuf/+T/fxLTN5ybSW2blsw6gzlkV/D786JfvBhbOkqGokxlCG8YJynr+4LSBkqK4ymMCzL1c+Xzj7Nce3l9osuJa78lFT/5/3SypBGD33Lg2yBHvrX7ZdcZrvkzMg7n5l5kZAwNE4r+o4Q25zJN2p64Nq0hMpLo3+vx/j7TKv2Hw7+fCb/hJv3egmtWuc91qP80aeIRpLbo2b6iyKdca50xjl5//0lPPvd6MLFsWU/05CxL2I43liPvmYPXaXG0FCq6nsk/sg6tnPOctxwmXTWBcTmMrn6g9Wg0njcqP9QD4FqceMkWo3oD5PSOBPLsKHFWuXeQNOsrgMAgRAgzfRMOHSo0WNmRIp6zLDKhtWMmd0egfBHHJ330NHuu+9WVq+JfLww9vFy+dc1ypYSRtaMY1DjUMaYxUT+cTxKjW/6ygNN43ufEocgHn84f9wx9v+cJbU7n298eBrmCvKNmtVdsoQqNKl3BKVsnlN/Jg5+KyLYCye8qg4pNf9kh6ax+QcYTEtcBcXvz6YxObPe75RydQ889Nd15132q2/M9DlvxikPlmt02AH+L44rnjfL6H6U3NuJSCKxe5LYxJ9cdz9ou+RaJsmDav0lq5e5q33+jvBHtsx7rKX7/p7KL79GP/kwuuQ7ZcM6ZfNOGlL27YuMNVsIOdBsQ1p1WodqzL7kS9l6bvGIo4XWx9gvPkc8tS1X90CveIpxDRrazj1d33ccOhDKstiqZc3uRWh+lO2s043zsBlFfzkEhs1HY3CwHgIhQNrpmXDIUMKlpscMx8Z/Ws9oKsPi020yYssTTjpd/2Ee0ZStG5QNW9UNq2M//6Cs2qmVVdBIkEYj+x3os043sbnYhl7hhKZi82P4o47hmzZi8+untWxB4pulr2Epm1+o/6Tt7hiW449okr67SxpbWKT/WF1FUvgjm1hdwt/o73DhqKOsriKtiOQWTjhF/3E/wKi7N6tbd8u/rpJ/+VFes1XbWkbliBbwG98Cf90d6SHc7iCSg7jy+GPrC0c1FY9uzR3RiD+8MbGZk8xrxnHZ9Y5Lr0r45jU8g5b3YK+8Bx6p2e+mGMHsaMgEOGQEsILRY2aw/m/TMyFhibbdT8Nh/VvfrG3CP7B8o6P0H+ac85xVfxEPar4yLRzcLxBy3iLi9honvwEAUoCr20T/EU85fd9/U4WG/Wp5CaOqf7vmRinr9hCHm9gy7KvBOHeZ+mNRVt8JYz8M8K8QCAEswoqegYOMHjPm9h0lhCoxzbeXQyBMJ9HFFrusWCkMAOAvCE+cBbwToxABoBoQCAGsw0neQYMYTfOPeI2IQqZPKwIAAACAnINACGApzmb0mGEY/4hXU7hmPQAAAADAgSAQAliNlbxDhhGWNdasNysTZnb/dAAAAADIEAiEABnA6DEzhCHEhB4zVN8Mx0h284oDAAAAgJyFQAiQGbjKHjMM49czYVI9ZijjcLDeOmbWBgAAAAA5CoEQIGNwknfgIEbV/CMr5xPWKBJSlfKt6hIBDS8BAAAA4NAQCAEyibFm/WAajwWen0IkqSbXCTVVPKp5jVfvBQAAAIBaBYEQIMNwNu+QIWp5Wfj1D4hkq/Z1Qo6Kx5+cksIAAAAAIOcgEAJkHGLPKxz9MiF3hyZ9UL3rhKrG1c0XTmqZyuoAAAAAIHcgEAJkIuLIy39ptP6HykyY6HVCqqj8UU2FZseltjgAAAAAyBUIhAAZinV6818cxVAaen1eoplQU+xXXcDwYsqLAwAAAICcgEAIkLlYV37+S6Oodk94yoeVY0cPemtF4xrk2y+/Ik3FAQAAAED2QyAEyGisq6Bg9MsMuSc8ef7BrxNSOW6/7HLhqFZprA4AAAAAshsCIUCmY135hWPGEvaeg/WY0Shb4HT1uEO/edoLBAAAAIBshUAIkAWIw5M/agxD7g29NveA1wlpLObseoV4UhsrqgMAAACAbIVACJAdWD0TVvWY+WffUVnlmtbNe+whhmA9egAAAACoBgRCgKxR2Xf0Japp4ckLiE3a97eUMqzm6XU/3/QYS6sDAAAAgOyDQAiQTYweM6NGE3pvaMr8qvmENBZ13nGV8/ZuVpcGAAAAANkHgRAgyxiZcMzLDHtv6PUPGEqlc0/Of3o44aRD/yYAAAAAwN8hEAJkH+L05o9+mdF6yD+vL5wwii2oZ3VFAAAAAJCVEAgBshLryCsY/bIWquDqNrG6FgAAAADIVgiEANmKuLycy2t1FQAAAACQxRAIAQAAAAAAaikEQgAAAAAAgFoKgRAAAAAAAKCWQiAEAAAAAACopRAIAQAAAAAAaikEQgAAAAAAgFoKgRAAAAAAAKCWQiAEAAAAAACopRAIAQAAAAAAaikEQgAAAAAAgFoKgRAAAAAAAKCWQiAEAAAAAACopRAIAQAAAAAAaikEQgAAAAAAgFoKgRAAAAAAAKCWQiAEAAAAAACopRAIAQAAAAAAaikEQgAAAAAAgFoKgRAAAAAAAKCWQiAEAAAAAACopRAIAQAAAAAAaikEQgAAAAAAgFoKgRAAAAAAAKCWQiAEAAAAAACopRAIAQAAAAAAaikEQgAAAAAAgFoKgRAAAAAAAKCWQiAEAAAAAACopRAIAQAAAAAAaikEQgAAAAAAgFoKgRAAAAAAAKCWQiAEAAAAAACopRAIAQAAAAAAaikEQgAAAAAAgFoKgRAAAAAAAKCWQiAEAAAAAACopRAIAQAAAAAAaikEQgAAAAAAgFoKgTDLhEKhcCjEEGJ1IelGK+l/EEXR7XbzvGVvXRooiS37RtvhY9ha9yoAAAAAHIx+sMZx9qsvIw6H1aVAohAIs0xpaelvW7aQWhMIq0KgTpIkl9vt9Xr1P1jz8OPB+MoVkTnvRt5bomzYQqMRhqktrwIAAABAYighUv0tqzkEwuyBQJhlWJblOC7nA2HV9UD9werxLy8vL7+gwOl06n+2oBQ1Iv/ya+S92dEPPomvXEXDcYZwhOOJ6LKgGAAAAIBMRinRD9hy/Ug1xyAQQgapyoF64rXZ7V6dx+OybHSoqmzaEF04NzpnYeyrlZovpIdxwgtEtFlRDAAAAABASiAQgvU0TSOEsCzrcrnyPB49Cep/0P/TmmJKdkQXzY9+8FFk0ed0r59SBjkQAAAAAHIVAiFYo+pioJ4DOY7zeDx6DtQ5HA6rciANlMa++jIy573o/M/Ubbupouk5kBFEjHgAAAAAgByGQAhp9UezUEmSHE5nQUFBXl6ezWazbFakEo4tWxad9170g0/ktZtpRCaswBhTBJEEAQAAACD3IRBCOvxxPVDPfk6XS8+BLpdL/7NlBWkxefXq6Lw54Tkfyd+vrmwVwxOOw9BQAAAAAKhVEAghhf5sEmOzVU0OdLvdgiBYV5GibFofXfhB5O2P4t98p1WE0SoGAAAAAGozBEIwH9W0ylVJObvDkZ+fn6enwLw8/T8tLEkr2RldNC8yZ0Hss6XqTp+xSA4vIgcCAAAAQC2HQAim2dcslONcbren8nqgw+GwNgfSUEX0k4+i8xZGF3ys/raXKirhBCKKFpYEAAAAAJA5EAghKX80iREEoapZaH5+vs1ms6pZ6L6q5LC8fFlk3tzIO0uUDZtptKpVDEdEvOEBAAAAAP6E42Ooib82C3W53flerx4F9T9b1ix0H1n++cfo/A/Csxcoa9Zp/jBDBLSKAQAAAAD4NwiEUA1VOZBlWT37VV0MdLlc+p+trktRN2+OLHgv8u7C+DcrtPKQ/sYmPE9Eu9WFAQAAAABkNARCOLQ/moXa7faqZqF6DrS0Weg+6u7tsSXzInMWVraKqdD/prJVDHIgAAAAAEBCEAjhX+1rEsOyTpfLk6cnQY87L8/ayYFVaLAi9vlHkQ8WRecuVrftpapW2SrG8guVAAAAAABZBoEQ/uaPyYEcx3m83j+ahWZCDmTkcOzbr6Pvz4/MXais30ajMcJJDCsQK/uYAgAAAABkMQRCMPyRA0VJcjqd3kqSJGVEDmRU+ceVkYUfRN9dKP+09i+tYjA0FAAAAAAgKQiEtVpVDiSESJU5sKCw8P/snQd8FkX6x3dmy9vf9JCEEEJCQq8KCPYCIiiIBQunZ++9nefpeXpyf8udZ5dTz3aWs2EBewURTqVDQkjvhbQ3yVt3d2b+u2+Qkrwp77xv8r6B+X7ysUB2dt59Z3fnN/M8v8dmsxmNUeLJSdSyQu/Xn3s++EzeuB23dDCrGAaDwWAwGAwGI7wwQXg4ss8kRtOBnXGhmg6UoqZcO6qv8q350vPBV74f16N6B8cBf4og04EMBoPBYDAYDEaYYYLwMOJAs9DYuDi73a7pQEGIljGAnQ557TeeDz/z/vAjKtvzm1VMlGxXMhgMBoPBYDAYhyDRIgYYAwUh2B8UCiG0Wq0xfpcYi8WiycJI9+w3FK/vf2u9X3zjWfWFWlhNfDKAEicwqxgGg8FgMBgMBmPAYYLw0GSfSYwoinar1W63x8XFmUym6DCJ6QQpOzZ5v/zC/cGXal4R7nABoOlAyLYEGQwGg8FgMBiMQYMJwkOKvSYxnWahVmusPz9Q04GR7tdBqCW7fN9/437nE2VrHmpqY1YxDAaDwWAwGAxGpGCC8FCgUwdCCA0Gg81mi09IsFgsUWMWuhfUUOP7/gv3+5/J639Bda0cBwHPdCCDwWAwGAwGgxFJmCAcwnQxC9Ww2+3RYxLTCW5rkdd/4/7oS9+3a9WSBq3XzCqGwWAwGAwGg8GIEqJLPDD6A8YY+jFbLDF+bDZbFJnEdKJ4fb+s9X76teeTL9SiGiLrVjEgaipbMBgMBoPBYDAYDI4JwiGHpgPtMZ3bgbFmsznqdCCnKts3eb/4xv3RanVnCbOKYTAYDAaDwWAwohkmCIcYycnJKSkp0WQWuhe1ON/33dfulauVTfmoyeG3iuFZiiCDwWAwGAwGgxHNMEE4xIi2FEFUWyGv+971/ir5p42otonjeGYVw2AwGAwGg8FgDBWiS10whgq4rUne8IPng8+93/6glu3R/gRAkelABoPBYDAYDAZjaMEEISMIiOyWf/3J89Hn3m++VfMriaz4rWIMke4Xg8FgMBgMBoPBoIEJQkZ/IPL2//m+/N790Sfq9lLsZFYxDAaDwWAwGAzGoQAThIzeUEt2er/91vPhp/Kvebi5leMkZhXDYDAYDAaDwWAcMjBByAgAqiuXf1rneusD+ZctqKbxN6sYc6T7xWAwGAwGg8FgMMIJE4SM/WBHo7xhrfv9Vb6169XiWo4DADLLUAaDwWAwGAwG45CFCUIGR7wuedNPnk8+9375nbKjgsOq3zKU5QcyGAwGg8FgMBiHOEwQHs4gZfuvns+/9n78mbK9GLs8AIhAFNioYDAYDAaDwWAwDhPY1P9wRC3d6ft2rfv9D+SNBbhln1UM2xJkMBgMBoPBYDAOL5ggPIxAtWW+tWs8H37iW78FVe9hVjEMBoPBYDAYDMZhDhOEhz64pV7+9Wf3+x/6vt+gllRzHGRWMQwGg8FgMBgMBoNjgvAQhng65C0bPCs/9371rZpXQTDSUwSZDmQwGAwGg8FgMBi/wQThIQdWlbzNumXoF1/KmwuJ26vpQE4UASdGumcMBoPBYDAYDAYjumCC8NBBLdnp++YH90cfyr8U4BaH9uUCUWBWMQwGg8FgMBgMBqMnmCAc8qC6Ut+PP+pWMWs2obpGXQfyPAsNZTAYDAaDwWAwGH3CBOFQBbfWy7/+4n77fd+6n9WSWo5wzCqGwWAwGAwGg8FgBAUThEMM4nbJW3/2fPCR75s18s4yDmN/NXlDpPvFYDAYDAaDwWAwhh5MEA5nCBz8AAAgAElEQVQxXG+ucFz3AFExBwQgSpHuDoPBYDAYDAaDwRjCMEE4xMAd7ZoaZFYxDAYj6kCYIEx3KICQE2B4u8NgMA4vCCEq4gjVsYADgqD9k8E4PGGCcKgBIAfYE4vBYEQZGMOUWD4tjsPBT8cAwK0dqLKFzcYYDAYl2oPHIIgT0gHP0xyOsVpcT7wKm2IxDk+YIGQwGAxGaBDCQWz/683ms8+nE4SuN19su/ExTmDlUhkMBg1EkaVZRyZ9/B8O0ghC7KhvnLdMLa4BIpsYMw5H2LhnMBgMRmhgAuxmw9Rp0D6MrgG1oJ5gBDgmCBkMBh1EmjoSxg+nOxhVV2BHqx67zmAcljBByGAwGIzQIBhabPzIsbSHq6ikimMBowwGIwSkKVOpj1WLa3BrO4DMoIFxmMIEIYPBYDBCghACMxNgTDzd4bitEdVVcIAq84fBYDB0CJ85nvpgtbCAUzHHvNsZhytMEDIYDAYjNAiWjpjA8ZQvFNTQolbWUVpBMBgMBsIwxc5nUsaLaigleWxKzDicYaOfwWAwGCGChIxc6oNxRSVudrFqOgwGgw6CsTg8jU9OoDweqcr2YuYvyjicYYKQwWAwGCGACTAKwnjaBEKOU3ZviZYEQhURLNMeDIFkCGdnGIOPign20R7MA2loRxwSWfvstKVEBQMXQUcWovKpGdCeTHc02lONKpoBYI4yjMMXJggZDAaDEQKYwNgYITOFugE5vzCM3aGGqEiaPMp8wRJtbssFW9waQlRZ4fzX+xzGbJ9hiKINAHHyCMsFS/3prEEOAJ5Xdxc6/71yqEY+ax8XYOv1y4SsURxCQR8Ooevfbyi7a4AQqY8PhIkZ1OtKalUx8Tg5yO5cxuELE4QMBoPBoIcQBO3xQlom5eGqV91WERU7hFg2HHe87a776I72ff+x81/vRMUHYdCBFdP8k2133Ut3tPudl5wvvMsNUUGIMEyz2u+6ic+g8mXBXtcr7+mrIVxkPj4AQJxAH7Wu7CjFTicAbIefcfjCBCGDMVhgotfv7gKEbAJJjx7gRwbuAuoRRJ2Ns6+pFwiBGSnAnkh5tKMBtzZy0RCsBQGfnU59tG/rdk5ROD5Mc0pMiIoGaNT9VmwNcDwb1geC+BFjqA/2bd4cxq4MMgQjPjkFJNDWEa0sJm0RLeLHC2Iufc0JVFrptxhlt0M48AfeR26vmEEJE4QMxgCgTeYQ4si+wBtdBwKrAcaaD9KEAOAGJ5EV/67CXuWhRxzxUTA5jn4Ix2clAas5gMwOE7itTZviE0LwHien4N++I00n8vo+AJs87IVI00bRB2tV1KD6Bv2SRhZMoNksTaXWA0TdVkEwBmF5qRICYg1CevKAjG2MsaONw4ioGDd0+P9o38AWOOFwffhgAmxmYfxI6uPVrZXh7M9gg2BqGrRQVo5Ri0pRS2vEcggRgSlmPp12NQfLaslONh8OFYQJUv0GY8MMJx9tPu8cPoUypZMREdgNwGCEj70PRBVYjGJaGkxPFyemi2PH8mmZMCEd2A3QZuwqCJvdpMOJm6qV8gJlZ4m6vRzVV6EGh+5PwAuUyjAkY4w+EYEUBc8N7TIahIT/vipkZQ6gIOzo4FRVE4Sk2Y1bmlBVoZy3U9lciqoq1ao9HOb0CTRThhwWx4awNl9Wix0uIJnD2CEaNA0mGYURoymPVlyopixc8XJEUayXn2f/w5+CTWTrF5og1AY21h5WBDe6SEu9Wr5Lzt+lbClD1ZWopsn/8OGHaugjNRjDmHghcwTl0R1NuKEuUgGT4QBI0zPpl3UKq4nbCyRLWLvUX7TXrpA7CsbZKQ/3eJWCEsDqoNKxd/lbgTEWw8wjzRcsNpw0TxiZE+luMYImCiZ2DMZQRxMMiq4DYVKC4cixpgXzxWlTxZwsmJzZ97FZe/9t6vyX7FIK8+TNO7yrVvnWbkZ7mgGUuGBCL4iqGuaMM5+/1P8/wX2OPgE89P70o/vtb4AQ4UcHUbE4MVnIHQdtcQN3FrhvuXyvTFjon+9gtaJA2ZLn/eJTz+frUGU9AAInHq7PUm2MCbwwehx1A2rxdu1Kh7FHdBBND2QmwDTKDSLc3KxWVOgLBOEBSZNmwTj6omq9A/eF9+7NujrTf06fUrJL/mWzd/Uq35otqL4JQDGoh8+QRh8AcfF8WlbfvxoIVFuj7qmPZMxkyIgTJlMf699hi+BQQcLwbGCKoTsY79mDyltY+HRwEM6/qCQDgyCOH2VaMs90xiJp+kwOiJHuGYOSw3USw2CEBcIRRQZG0TBzovm8swzzThLHTAlpditZxIkztR/LxZcrBZs9733o+vfbakW939G7f68rLJsWLrBefyt9H3pFqSnjMIr8o4MgMXs0tERkWwkKI8drP6Yzz7VXF3k++sj5whvKjlLAi4djrC9CfHo8P4IygVBD3pUfDYJQEwTiuEwgUc5mUEOrWt4UnoUSQoBJ5LMp9yrp4Q1i7lTtx/K7y9Siba63/ut++V21cg8QpMPDfZEI41Opd6pRRT1ubAP8kK2lCbXHGuWyDkGKUrg7YoJQ90flhNzMEKLWd2nvcWYO3F/0FXCFA4RPjTfOO9Z09mLj8ScBG20FSEbUEOlZHYMxZCGyAiRgXDjbev1VxpMWAIMpvO2LY6eL9003/+7Cjn8+6XrpPc6H+l6tJxyQeGEi/UJvHyBZXps3UI0Hh8qnjeJghE3h+PQc6w13mi/4nfOZZzqeeQU3uagVxRCFYMwnp/DDUimPVxVlU0V0TMWQOHoiR5sCqBZt17NMw1KFDmE+PYFPi+QES8iZEnP/FMvvf9/x+OPuV1YSl3oY7IETadIE6oPVwnxOJeEZAIOPioWsRDiStnKM06lsqwYRWw4j2lNXnDSK+nh5Zz7n9YbNDuoQRkGaFgQmg+G4I02LFpgWLRQyx0TFch4jHBzyj3gGYwDQcwVladYE+z13GOcvHND0J2HUuLinnjeedJzj5nvVyqY+Ch8jxA9PFicN1N4Cqi9HteXUk+awQQgQBXH6oG+h9ABMSLXfv9wwf67jhrvkjflAGrK7BDQgPi0NmCkDd1F9GWl3RL4eNNG3N/gs+hGlFOaFK0Rb93tMSedTM8LSWigImWPjnlphnHey47b71KI6IB3aM2YkZE2iPlgp2TV0Z8b6kEtN42Mp72K1qohzuyJWcEVfBjUKOfTfHdpVEzY7qEMSFROsaBdaHJdhXDTXfPY54uRpwGCNdLcYYYbdAQxGcBBZgfFm+63XWm+6FdJa7QcJMJ15IZ+Z2bzsKjW/shdNqL3XYWqqkE5fjql3lMJKVNWgh5BFFm0GYDTqdjLRhGHWCYmr3mv5/ZXer34CUpi3i6MYIE4PwWK0vAS3Rc6ccB+6oYhNHEddc4Iov5aEsTcwZRgQI+2ysxdoOv08IWNky2U3yJsK+1iQGrpgAu0mYXQm5eEEy+t3D+USlCo/IhuYYukOVkoKsCYII3UXYwISbTxt9i9R3Er5bjYZDoBe+UbVvl4+JdFw/Ezz0rOkY4/jk+gL8zCiHHYPMBhBQGSfOHFk7BP/Zzz5jEE+tTR1TsJrzzYtuRjXtvccO0qko8Zw/EBFLao7txAZgYjPCfUkK0soVacGCD5lZMKbrzZfeIn36w2H+nbKPoAUihfF7lrs9AA+0vqZYGiLpXbGI952XFMbvg0iIB09NkxNhQdx8lEJ77zatPg8Na+aOxSDognC/LBkfjilSz527CEtrVFRS5MOAMUJlPaqGsrOKuLzRWoJg2CkvZShjdLgFLe3qRWVkS97Ez0QosdAYRlaTNKMiaYLlxjnnSrm0m/AMoYKTBAyGP2FyF7DSUfE//tFIXOgtuB6Rzry+NjH7m/5/W2dafSBwIZpRw1cB3y//hINvup63lpWAoilXM8eUGBiWvzrLzTOX6JsLwOHftqVNhygkDme+mi1KI/DkX8REUxgYhykXfxGDTWosS58DpNAzKa/pAOEkD0x/pXnmhb9Dje6DkHzJKLyiWl8CuUuk1q2G7U2DVVRQQgQBHEytVEwRsUFHIngkFBF7Y0sUC7A4YYmVNJ4CA5pCvQtQRmIkM9KMy06xbT4DMPsY7hoCVVgDDiRfg8zGEMEIvsMJ01PeOM1PjUzgt0wnX2BceUnnve+CxC7pb3XLQZhwkCt5BGPU9lYEhWr4ASJE8cAQ5RuwfEpmbGP3t901hWcTKLDLmXAULGQm8RnDqM+XiktjIYlBj09ZsZo6rGNqprV2mbAh2PrXBsyZiGUMh4DhzTjeNvdNzpufwgQaQhHRwaG8FmpHKTc/FRLG0ibk4NDNnlYEIWsiXSHEq9LrSjjIlXEr9NidPx4+qj10jxOUTn+MJ4M62bpih6pHm81nnCMeemZxrmnwXhahyHGkOUwvgcYjH6jq8FjJyW8HmE1yOl7BybbTdd5V/3Ioa5ig6hIHDtSyKaP/OkdtWQHbm6IjkJbSMgcFx1CIjDGeYvMy85wvfDeIW4wAwBplx1/ulvPmSRBWqoAfcT6ftwGhGgIQURiDr0GQ8W7ODlMFqMqEnKGwWHxff9mJLBefZ3nw1Xymu2HXOAokGaEUEuzcDdRceRj6elAmhiOhSmUAgC3dqg7KwAfsacxEA2e1SvVXVsIwkEfy0M5f3dUrHJGBBURrABRMMwZbzx9nmnJEjF3PAeH6DhmhAoThAxGXyiqkJ0W/9IKfji9sXUYkY6YLc0a71uzvWuFA6IKGZkwjrYAQF8oO4pRUxQU2tJ0h8gLY6Liu+gZaLvhWs/KL0mr91AORuIB3uN0vbCa2mAzWmrc8SAUl0K5aHu4DEUIQXz6SBgbpUW9gNFqvenqlg036Pr/0Nr91ouOUILVkvxoXp/qHT0Hb0w2tFOaRqLqEtzhjdhg0E8LvZ9u8nK/0LbAHxax/Qei26SrflvdNOP848znnScdMQNYKD1mGYcMh9ltwGAECyacGcY+dp+QO2DF/YIEmGzGk07yrd2szWG6/I04Z/zALXYqO7bqVyPizwyM+Xi7mEuZ7TNoiJNmGOcf637jM3Bol7eCYMg7TyIME21CFn2IlLyxMHwOk4jPGBU1FqMBMJ22SJj0pLK56NCZRmMCYwzURUeIoig7iiIWMxkGVGF4NhAoh5xSuJ1TZe3lE94+BQWQBDab7RtMCELaeOUTY8RZU83nn2088QR+eHaku8WIFtgtxGD0BlF91msuNC1ZFumOHIQ4Yzw0GolCDt5dAYbpA+Yog1V50+ZoeGIQgoHJLoyIliKEPQNMp5/ueffz8OylaI3om3BEf6njvdtxQGuWB53/dYht1wSNfn38lwUR8lvwKtDuDv0G8V+cni8PwVhIHCYMp3SUIa5WXNUUnuuvJ0Tx4uSBivoOC9rdZz795LZN+WF+GhD/l9i51XzAIOf2f4/+cc719lVSnhlhITOdOkwXN9SgipawxdLvu9OJPjIP3HoHPNh/BcJ1vxN9TYcfm0XdgLKphCAViIdYCPGhhZ4lKEOLJOSONp9/hun0heL4IyPdJ0bUEfnpHYMRtRAV8Rkp9jvvjLYCU0JGFmcwcopnf8cw4RMtwpgJA3RG1NSgbK+MYKLIfjDms1NAHLWRyeBhmD0DJibh+paey4T0hSZuFJXjVCCJwGjkRANMssAUm75VCwFxeFF1G6f4iMdDZIXjRH3TJuBQ1dvx0H4OAERjTxNQInto40UBEIyhxovqtnjaB0faxQEG/frwI2zA5k9oBByubsctLu36YI+X0wtPS4FLpREE45NBLOUOoVpZjFsbw+QwSbQvOpQyHoODdPSxwPQ8p4ZjpWNvrTNVe7YAo0H7BjkowGEWmGzlOjWhNs6b3aimncOqNqklXv2r9A91PnyiCAkpI/gYyqKyamUh8blC6gzxZ3MRbSRzwCjpFWt4EZhEPjOWE4S9Kx0QoJIW4vJxSCGyj3h9+h0ERU4ITYjqJXyM4njagAvtHVlW2X+LUa3n2t1Kea4DANCw76EaSpsHtnPIorvNiabTTjQtOcN43CkgNl77vkiHkzrOv/8AizUqMgIY/YMJQgajZ7BsvWoZn0FZnawr4cu60a1KDg4N1SZV4sSJfGpSWNrvjpK3kTjbo2MbioiTMqOjJ33AjxjDZ6SiuiYQfH4RkfUcD2AzGuZMlKbNEo8aJ+aM49NzdOUj/daaionHi+rK5J1blE27fevWKVuKiIz11foDrw/G0G4znX8RncMNcTncK1eTNk+AVzuE1ssvA1QVwIjs9Xz4IW500swY/Ave+jZJotU4a6Y4ebp09EQhM4dPzQIGYV/SJvGppN2hVuTL2/LldRt9azagupaAKUPikZnUiz6ooh472jUZQ3d4V3iBHxldRQi7I04cw6eloLI99JNpRdc/mooGSTbDtHHC6PHi5EwxN4dPGwXjUzmJ1/XePjSx5FVxS61aU6rsLFC3FesDfkc5cft0naSP9hA/EOKzMzna0G4lr4S43ByFpYy+TKNwgABBFCYNlyZPFyaPEcdlCumZMHkkMFmAUTjwRtYuAvG48Z5KtaJIyStTNm2Xt29DJY0EI8CLtLnKBBgtAm3+JG5v1r6U/obLqor5zFP5zJCDOwTo/fxztaCc43lNHptOmyeMoXxH+9Z+q2wr5qJhoXPgAID4kG/tVnnDbof8N44Ebb0TNNoNq8jQakn++QftQTHgp2OECSYIGYweUBE/PMm87PwQW/H9uMbz+SfyT1tRgwuaBenoCebzLzQcfXJIrQZwdFT50WOAMSakZntG+bUAu1zRkdqExbHTIt2H/gGAOHmk/L/tQRzS6QAOsDQ9x3TOAtOCxUJODjD3WHERWO0wKVmcPIu7UJ+cyevXOJ97xfvFj0Qm+zyH9I3unIy4Z5+g+xBq4Q73Byu57rUvFSRMSY1d8Qhd9hFubXa/80Hwh3VWyuKNc2dp18d40ml8ZkZPHQCa/o2J5UdkGo5ZwF2P1PIyz0fvuV56W5vBd9mclMbTb62rReXEq3R1eKJsCwuTU2EyraMM0YRTR8C/AaaYMIY58InDoT1RxXVBr3RgrO/oAk7MHSEdN9t02gnSEUfDlGQg9eFoAqwcTEwQcicZT1ysN9PRhEpLvd9+5XnvM3lrPvGikNyJIC9Oos9JVgsrtVsMSMGcXXf1kIFZMhx9hHHh8cbj5wnZ2TC+j6gHfTzHxvKpaeKUo0yLOP0O3LNH+XW96+0PfF+tRY3teuGTYGUhInxqLJ88PLijfkO3GC2v60/kCJE9lvMXxb/xCheyLZn3sw/c/3lLl8rae1Ag1j9crV1Auqaazj9X3lwQFZEvAwoiuKE5aCPoINHDvPU8FiSkJJlOnWNaehafTLnrzogITBAyGIEhWDXMmyNkjqFuATdUOf74R/fbq7X5on6vAX1SLW/Z6X7to5jH/2y94mb6znXZHyMcEATD7AErZq1N4vJ3cCQK3ppEXx4WaO0fON0aJw93OEHPG4zAJvKpyTCBcobUBT4tPYjIHEXV3qbSrAm2Gy4znr4IBhnECO0JxvlnGeed7ln9UduflyvbSvyhntrfYOkIelNWZUchbnECqavoIgQLmRnaaemaVfM2EacnCJHSuSto4M3nzrdeeZnh2BM4wRTMCXkhc7Ttlj+aL7y448l/Op94lXjUfVuFQg59lKZStC1cDpOEIDE7C1oo/R7ljetar7mLwwGkHzBYQIJVe0QY5y2UZswJtcOiCSbEBBdypktBGcZYDMfNtlx8vuHY4/lhGdTnh7ZEOCVRnDLTes31vnVrnM+84P16gy4LKfyNCAG8IE6cTtkV5FXLgkmn7LwOiTbzkjMsl/xeOnIGkGyUp+ZETcjxC881LjxXLdjufOEF18vv4jZvUBdBH3KTsoCJUqSh4kLc6OrzjET2GefOjn3un6GrQd/3nzVfdAN2eLRXHqciOCxeSKdMHyBuByqooH6CDTEGrl4UIURF2iQBWo3ikdPM555uXLBIyAxTXBVjEGGCkMHoEcuSJdRvC1RZ1Hz+Jb4Nm4Fg9nug7UMkTtR253JpyhRpxgl0jeP2Fk63jd4379PmNJI0dRZda32fzuWUt+0A4QqKCwWE+dQ4IYuytAbxtDUtXaYU7AI91owj0G7gR6ZJs460Xn+lNHUOdU878S+99yNERw8ek4XcNPtdN5jOXwYtIZShg5Jp0VJpxozWa2/1fPItEAz6nuq4EARP8dYe7gJFyJ6ob7VRIRfsIIqih7r1B31HRTGcMN1+9+3GU08PZQ6nfSOxy/9umD1buz64up3jeT7VzqfTxjURrOwqCt+cEgkjc6nrgPl+WS9v3u43H+6us/VB6P30u/aHXzKfc2rsY4/AREoTnU74nETum/79qn9sA5vJcvYC6/VXS0fODuPEA5jjjPPONM5d6Pnik/aH/i6v36EP+KC2CjVVa5L44ZRrTNjlUQtL+5lBSmQZ2o2WZWdar7tWnDiD7owBEcZOjn38GdO5Sxy3/1nesO23laD+gIRRYzlA+Y0o5bv6/B3tU0tH5sa/9ByMCzV60Lfmy+Zl1+BWT+dSDsGYtyfyaZl0raE91djRGB2VdYcgxL+6gRQg8eLYkaYlp5gWnSkdOSN0zc+IFFEww2MwohBE+PQ4YQrlsjHxdLRcfaNvw1YgBUqvEnnscLne+IBaEKrlpcTn2Z+5gTAcnSJMnErXWp+gqkq1sD4a6ukRjPi4JD6V0oYRN9ZwXieE5l5yn4ibKDurlB2lntVfxT37sPmsi2g729lcP3ZREOYgslyy2P6X+4SR9DvSB8Knjkp4+z8tV17tfnMVBwifQd+ssiM/gODR91V4YQz9Pqqyo4LDiOtHVXp9Gh1ntt99q+2Gm4A5PEHRptPPBlZTy0XXoupmYWQOn5JM1w5u2aMW1IOw3BraJRV4fgL9vpmaX63n1PW+XeMlzldXEpcr/rXXgclOfa7+hp+piIPEeMYx9rvvMMwJLU6+F4BoOu1sw5xjOx59tOMfr3AK6n9yI1GRNDmbT+oxKrt38J4GVNbS97PRr4qlORNiHvqz8cQFdOfqE8Psk5NWT3LcdafrlQ/1pZY+E611i1FNTI6jPqP8887eF7yIrIjj0uJfWcFn5FKfpRPfmq+aL7gK1bUdEJ6NYdYwfzg0DWpRDapv5vghXjVn8Om0OgOYT443zJ1tPneJ4cRToC1KS6cy+g8ThAxGAAhSxDG5fCplLIr7zde9X6/TZik9/wrEVXV+bzSa2C3l1wLiU/ZvPAIOCGLHE8+BgMWgCAYxFsulv6euF6dsXc8pvuiovIxhegqwUmYmKMWVqKGJ6305HwL/XqiA612Om/8sTZou5AyUdyunFzFTYaw55uE7rVfeEN5aXsBki3vycbWwSC0pF3JolZviVXfUBNhxIhwwm8XxtHFB2IeKSvuT1UZknzg5K/aJR4wnzqc8Vw8YT1gQ99xjTWddBuNTqXUmqinlPM7wpOdpl9RilsbSXlLVo5aU9H2TQgBFi/v9bywXf2M8/SzKc/UHPcTXJ4waZv/zbZbfXcbR7iT3HxiTHLP87+K06Y6b70Z17f0uk4iE9JHATBmmq5bmaUqvj1/SbVGR9drzYx76K4wfWI8NGJ8c9+xzwCg6n39Hr4Da+8AkBNotQjZlwAWHFVRS18vg1x5u/DB73PNPhr4dKm9a13zR1ajO0SVZV5pGH5qIKiuITx3yZVQHE0UlRAUWk+H4I8xnLDQuWihk5h4uMbeHAUwQMhgBQfyILCDSzBJIe6vzuVc4LPQ1N6PM8CaKW95+cElAnlfzK9v+cG8Pp5GNJx1lufxiutNpyBvy9eg+KSoeF+J0+pJZqLSaeHyBt227oX1eVN3geuc/Mfc+TH1G3Fjb24RJloURSfGvPWM48TTqU/QCTEiJeej+trvv5ZMplzZQQyVuC1RjjRBgMAm0fpi4vRU1VPdhTuhXFMZTZ8T9a4UeSDkAmM5Yar36a2CWqEPm5F1FuMMZHotR7ZJKZvpL2taK6vq6pJ34k5m9a78KSRD2vvukl8D2mc45JXb5g0LuoFbRMJ9zIUyIabnoGlTb0T9NiPnsHA5SrsUo+bv8kc89iwqEOROIefhe23W3Ug+zoAAGS9zjTxGXy/Xqqj6MhXX/4UQxm1JT4ZY6tKempyFHVAzNYuxTDxmOP5Wu/X0o+ZtaLr0WVTV3E29YHEsfFyMXbI6OVc6oxx+xz+n2wpnGU082n3eWOHk6MFCuoTCilqiY4TEYUQcAepIMFfLGdcqOEj3lvTcIsNrpltZQWam8fmfX9nkI+B50jgwMc07055JRobiU3QVR8+IkUgjpcGpxsP4fUFm/iyOov77q3c/Y1NCTINT3vqZnJ7zykjh5AGsEG+cuQNVlMIYyJFKtKEMtLQEMCbSpZGY8TKLcW0B1LUphFeglrk9Xgx7zuafEvfgCjBnAmpO2O25H5fnUh6OCSk3Vh8ViVE+IykkECZTfFKpvVkvrQH+r0gG1ag/difaebndjT3+lW26KXMwDN9tuv0cTJ6GchQ7jiQvj//Ov5mVXkQZXH7GjhNNEoziB3mJU2Vnpj3zu4a9VDMwg9qkHLZdeT30KGiRz7KOPydsLlc3FvQxOQjBIiIWJlBH4al0jqmsIHC+NCeBRzCN/NC/9PV3j+1B2bmy+8BJlR2VXNah9d0aBHxWKwVhxtFUYji5+qxHKp8QbjptlvvBcwzHHwoS0SHeLMVAwQchgBAJAGEcZReZd9z8901rsbbKrNS8dNZ7ubeRZ9SFuc+rFi/uDvpMjiNMnUZyoE9TYpOzeDfjoeFYIkB9FnfFC5LzdQYpwiNvbOOTjqCoraKi7A7vYaSpCnJKV+PZ/hFz6r6ZfAGi55BrqDRC1sIY43d3LjRCCpEljqIUQqiwhTqXHYC3/3qD5vHlxL74IbQNrXC5kjhUyaOeU2nSpbFfYXqMEiWOz+lpI6hFUXtTbJe1Gb2q8TxQvbm0P+PjSLgm0m2P/+Wd91EUO49YHIusAACAASURBVIkL4p5c3nLxLZxKevOY0RSR2SyOodyVJbITVZb2OAAw4QQU8/igq0E/MCk95m/3NZ95KYd6rn9LsHREFkf7bEelVQH9h/X7F/ns91xtvf42upb3oeRvbjr/YjWvOsDAVhE/MkkYQbmAQtqbUWH9AHpvDl0I0bcEsQxtZmnKFPN5ZxjmzRcH+j3FiAKiY5LHYEQVfsHGJ9IlSRN1V1UfjguaSLOajSfT5ETh9mb3mx+D/m9YIQwT4qWJ9J4ialExqmiNikQLFQmZCcJI2hmAs13dUROkpxyGMfHUalCfc5Q0gu7zUUUVMpLj//2vAVeDndCqQU7/9ndyJOAV076LsfQbpyU7ewmZJorXePqcuBcGXA3uhTbgk3i9SnEx9UXoBhKyJ1O3phRsDSoKnc+gzRzTOtpciztaAOg2MPw5YwmvPWuYdwZ14+HCfM4y+X+/dDz+Wm9hk9qj2GwWMmjDdB0OtaqqJ4tRosr2u66wXnkjXeOhYzrlNOP8Yz0ffd/z6iEWx1KWpOf0h8PWgAEX2v1rueIc+/3LQ4wrQVVFLZddreZVBew/IYhPTIWJlOEDalUxcbcFGMOHM/4yoUDihZzhxsVzTYsXGWbOGYTsX0aUwAQhg9ENwBGEUX091cFE9//sdeuPqD7T4vnCaJpZiOfD9+UtBX1khhx4LoxhcpI+d6fFt3kddbpjeNFj6oalwfgkusPVqkLs7uCCnAGIR4QQTla4Ezuauy5CIwzshrgVf5eOOIq65UGCYKW4MLDFqDZpGEuf1+f7ZVdPg0o3qZ+aE79iBbRHe1Fj0upQ8+vCZjEqavMw+vxYeXNJMPcplsZPoT4Xqq7GzU3cweW8iarySdb4154zzDuduuVwAgT7H//k/epHJa+yp2RCgokwdhiIpXRbxbWNqKiBC7Spqw1jw/FTbPfeG0nLDd5gvfpS76o1gf+W6K8pIZu+eq2cXxCgVdlrOvOUuH88rpe+CAFUXdJ88WXyzwW9qFk+cwQw0lqMlpRjRxt1iZdDCj0iQ9FXP5NiTKfMMZ29yHjyPBhLufDKGLowQchgBIJgVNdGdSQURvVWi1w3XkuPt99xE9fPCmwHgFvqO/7+fJDOBESalcOF8G6W1+dFiSDUnX6GZwBzHN3BalkpcQYrCIHhqGPpTsfp2aQ7cWs7OLB+uj4JU+1/ud142pnUzQ4axO1SNpYF2FPFBMRahdG0W0xERaU9mBMiDOMtsU8/yg+nl0aDhlqez/l84UlD0i5pnF3IpTWDVd2orKa/2kO7yEl28Uj6zFVlewFudR0YK0i0Nk1C3FPLjVGiBv3AxDTbrVe1XHlPp/gJgB6mOxaIlKpALS/Q40K7b4Np36ZFjHngvoh78RuOPl6cnqNsLOa6S2KMYaJdyKZNCVO86raqLkOOyD5pzuS4558C9hAqqeo5xqXNF1/q+2Frr5kRQJhMX6NFKWAWo/psRHsaA6PBeMxU4+mnms5cImTlMF1w2MK+eAYjEASgvBK6shDmcxY6n3+Nk3H34lREVoCZj33kL+JkmiLyHX9/VNlZBKReqll0R5WmH01xrk5IRyMqLYsaRxkgTAmhStvOSuL1dU+H6wnty5Km5UpzjqM8H0Heb7/kCH/gTJQoXtPik2w33E7Z5uCC6suJy9U9AYkQzNvjqEsmoj1VuDGQHybRtyRj/vIHwzFz6VoeZOTCAm0GHJZiIf5LGkttpor21KKmun4udhAkm048SQyhmIrvlx8PeiYQ/W6xP/AH03mhOoiEHdO5y6QVrykbiwIoIh1VyBxH/XyTd2zRfVm6/TlRZcsFiw3HRX4YA1u8NHuO/GsB6DbZIxgLCQl8Kq0vVFO1Hv5wwMNB90weNzz+5ef4FPqnNKcH4jY0//4K3/eb+wqEAYaJlIWC9ZugLD9q3muDjoq1J632b2FMumnBSeal54pTpwNjCFVJGYcETBAyGAEAUJR37UQNNfywoN9t0lEn2e64on35c5wM9fQS7ZVJtGkD5jhFGJ0e++gDpiUXUHTJs/qdjmde10tL9R9MgM0oTg4hS6SyWq2ooDa6CC/axZQmUn8WopYV6PKsn/hd8qw3XwljKQMXUXmR/OPWg8x4EOLTE2MeWz5UsjKU3Xm4oz2AzMAEpiXABNqpZO0eVNcI+K7fBVF8psXH2a6JWM5VsChby4mqhsViVL+kqfEwljYhqmYPqm3ofkkDgBCMs9ruuoU+c7KjRV6z9cDEOd0Pdtki6y1/oGtwQIG2OPOycx0bH+yuiPR73GQQxmdSN65srQwQPUEIsBist1wXbHR6l85pTyx/OjutO/RvGI6b5loh6mntXVZ2CILD0mAC5aa0Wl6Jm5v2Dzk98iU2/t/PimPo60DonepoarnyOt/Xv/ShBoleFoinXZPSHjXKrqLwZf8OEX5zDYUpCcZjplvOO0s67gQ+OST1zjiUiIp5HoMRdQhQLar1fvm55eKrgz4WwJi/LBdys13/el0tqdNLuktGfnii6az55gt/J2TQFH2SN/3ouPEe4lT7XW1ZhyAkpg4XczMpztiJmrcLN7uC3JMcMARed92ggsgepShQOlxA9Ben13r9heZll9GdTsP1wfuosXV/tQ99+0u1/+EGMWfI2LWpu2r8e6rdv30sTQ+hHnRJBW7zdB1UerCoLeaBP3P93sKNMNiHyovDt8mADbOo7XM5VFxKXH1XCiWKCnhsf+BW6YhjqM/lXfeDWlGzL4FQa1OakhP72MO91eKLKOYzF3U8+jyud3QtQUEItNmF0Zl0zRJvG67pGjOp/7mimE49Wpo8japVLP+yxv3eKjW/lNP3cAiwxRnmzjAtPodPTqfrp5gzAUgG4lW6B80KE9PofaGKqnGba29NV4SAzRC34nHD7JPpWuuEtDe2XH61+/0vYV9vHKIicfwwmEYZkYtbHWpebZAGY0OWfa6hVrM0ZYLp3MXG+aeGqNsZhyRMEDIYPQB414uvms9aCqzBJ61B0fK7q83nX4prSnFrI4xPhmmjgECbqVKwteXSm9TyxqATHgjiR4ygLjOl4du0LpKmCAeiYn5ULEymTE3BbR3Kzqre/D86F/qJJgV9wCTabvx9zPJHqL8y3NHi/u+H4IANSaLKhmOnWS69kq7BSIDV4kJtRhrwr8ScELadS3Z0HVS6T71su+5ycQpNKHVEwO0OtaoiCL/fvtoTRtE7P/n9HnsqLeD/J0LajJBPS4y5/1bLVSHswRLkeXcl8Sh7k7v89kIxD9/Pp9J7Lw00/Mgx4qxx3g/XgYPVu264ZYsR0rPpmtXDdPfUdrUY1S4IzxkXzuOE4BfRiNr+twfb/+8Z4pIP+DaJ+/1POv6+IvbJv5nmn0XRTz41i9O+LK/cfYQYptKpVh1Ukrd3NQQTTgSxf7/ftPAc6tY43QW6peWKa/ujBv2/jfj0TD6G8nWAKgqI7OmxGschg76yKQOB53NSTQvnmhYvkI46LkCZEAbDDxOEDEZggCD61u90vvCc7bY/0bYg8SPHaj+hdMP38/etl92s5JfTpb9Lc8bRKzptkr5+V5SU7iVYFXKyYTylowwq30UcbQQpmszp1rT2EYFfKwIYZzWceJz54mWmhWeFooQ977+lbC3aryd1D0lou/VqYKH0xIsAslctLwywA6ZdLgEIufTbWb4deV3/CCFhVKr1mmup2xx88B4H2l3bR93zfqJdUokXxoSQ1Ld5J+FkTul6q+p7IPqsFwq5KcZ5J1uuvkQcT+8lw/nLkHg/XwN+M8Qiimy5bIkxCopM9AowHjXH+2E3s01C+DHJwEa7xlTnQLUtXYv4EQ5YrYbjaJyo3B+92/bnfwIgdY+WVAvrWi69KfnL4TTJ5yaBz4xVt7R3f54JmdQWo0Qu3KU/IYnuUBlz/22WK0O6eYniafvTve73vggUjxAQxA8bQR1NoOwuIB53WLJ/o5F9rqEJNtPJJ5jOOt14ymkwISXS3WJEO0wQMhg9ALSplNj+0FNCdqZp8bKIdMH15suO2+/DDU5aMzQSSmwYaihHtbVRk2iB+JRMIFrpDgY2u/3B6wK7peq1yEx8SgqfkCrkTOQzhnNcSBMFtKe64/EV2ut4n5jSXs+Gk6YbFywJpdkDTuCVN2+UN21TS/NRXS0wGoWMLHHqdMPRs2E8rWdgN3CHSymoDJCWhjA/LJbPpMx2I6oX5dd1NSfEiuXS88LlLIod9fLGTcrWbWpVKaqvF1JT+BHZ0syZhtmzqUtKdketLCQeJWDJgaDRLmlKDE9bYFO7fKYz5htmTuvuYgWTkmBMrDBitJCdAxMov7IDz+Rc8SJqaN2rWLRup8bZ776LOh3xQJTtv/q+XyvnbcKtDu1/+fh4aeaxhrknCBn0NVT3IU6fBkyiXqT+oE0hLE6iX9dQdu/021Qe/KzQrsmoRCGTxhzI/cY7+m6bFGABTjsLrm/tePr5+BeDFoQAAmAUSJe9fkRgio3PpEwg1CtwbqoAABLFa73lIuud94S0bqh4HXfe6XzqdSAa+tWM9hjnoXgk/eNC3Vmlh08fYhajRC/9oruGCrzh2MmmRfNMi5YIOWMOWd3LCDdMEDIYPcND4pBbLr89HhPTkt8N5plRZVH7o4+5XnyXKIDStUJ75SfZhHH0+5NKQQlq2BOeMmshos0AIBQmjaJuQBw7XfsJY496hjiffFzZWb5/mZ9okzxoveHK0GN1iOL2fPKh8+kXlS35uN3p377rnEAhIEBhdKbl2ous19wYlpxPVFVK9jg52M1iFCM+cZiQRhmHjOvKcUvTQdk7KuLTh1kuvYS2p/tBjTWuFc+631mtFuue8n7ZCfyjBwGTQZo5xX7vbcZTFoV+Ik6/O7YFdJikIMRLqk35rZffEo6O9IH2kd1vfrQvV5Agn+Xii4UQgof3Nrvtf+3/+Kf307W4pe2AIU24F1YKmanWm6+wXnfT3lw1WoSsETAxDtd0SSNEYhZ9Qq9anBcggZAgcVw2MFHdgPriC+75rwX5l51E7gCSLahW/a+PbncxQmJ6GkymzcGrKyXt7Zh4LRcujP3bYyGlj8pexx23OZ/uVIP9vJ8IECRxLO1KgaYFKwLFPgxdECZI5QAWskcYTz3GvPQ8acYMYBo60SiM6IAJQgajV0Qet/iaL74l5r5C6y339L8iPDXY0eR69UXnU6+oZTVANAKRcs6pvSGk7DFCOm2xOG3Gs3UncfmiI+WAAEmSxo+OdDf6xvv1qo6nXj9whqS7bswYY5ofalgdKs5vvftuzwff6xGugtD1eyHafL3ScfNflC3b4p5+GlhDqgOmoZTlE1UOFDeLYWISoC2wplZXo9ZW7gBBSLBiPvtUPj3UL9fz6fttdz2g5JdwnAREoesyikJ8azY1bbo05pE/2q67I8Rzaci/lmhdD70dPxgmDwNWSj/bwQJ1LH8E7Wnbmz2IMJ+eZLnqqpCaJNj5r3+2/+Wf+q4jb+j+qEEVzY5b/4rKq2MffzKUfUg+MRVaYxBp2Z9GqMcFiMIYygRCDXlzYaA/xnzaSLo9GdvN18o//YJqHXqoeTe/EwB57GiRN6znhwW3Lka8TuKRu2ktlU/JgHbKTWmldDdq3GM6aU7cU88AU3AC9WBw24N/6nj6VT1SNJiMPmCQhCzKlQjs7FBLi0Fw5XyjEj1FEGkjESYlGOdMM19wluH4E/iUzEh3izFUGfq3BIMxoGA9DoNPSuJEE5G9gyAISVur7/sfdTUoGEPLekd8djYw0wsD35b10fKI0L0rTMLoaPfnVEt3td5yN3EqB6sR1Xz+mcAUUpUnZeuG5qVXKEXl/plToN8A/q0AIrpeXQmTE2MfeSLE5E/510KiyAFTesQZo6gTLNWCKtLu3j/1xwRYJfOF51P3sxPnc4857n6EdCg9rl9AoCsZD2677a98app5yYUhnU/14srqMKbXirPCEy47cHg+ftf9/hf7argT5DOfu1DIok5C09to/9sDbfc/DojQ4562Juwx3/H06+KUCZZLr6M+E7DFA7Nd36vfB8J6nY8RtJHPbgcqbwh0F5Bea6n3huHouYmr3+149HHvFz9hR7s/VVfQh1jnW0CAuL698ZQLAxS66BMIQddkVyBMzKAewMrWMjFnRNzLz1PXnvFD2h95oP3RF4EQnBrUDcayEmAS5QIKbnGoRQ3d46uHDMS/JYh90GwSZ44xL1lsPH3+YMW/MA5lomO2x2BEJUSWod1kvfoi280388Pp4xWDgh+Zk/Duux3/eLj9rys4JUB1+/4CoDQnhOmax6X8UhRaKa3wgQkcEQuTQ5l8DDi4sab16hvV/KqDZoQI88lxxgULQmlZ3b29aenlalF137GgmizkTa4Vb5nPPluaeVwI5ySovLoHi1FOHBeKxWj+gdNo3Xz1iBni1JCcTlxvveS4/SFO4fsOruYh8akdy58wnjwf2unXSlBznVpfxYVvk0EcG9WLHaiqsO1Py4mP7A1Y0GS83WReGpKM17619r8+ocl0ju9VDEDAqdD57Mvmc5YCG+0mKuC77LkRjPn4YUI6pQ5HNaXY0RS4bgEJXrD9hjRtTsLbR8lb1ns/+9637gf5lwLi9BDZp18FKGia0B/CHY5lCAjFCbSVYzDi1Ja4l54WaMsA+iHtjz3Y9ucnABG7x6X3cSRBYu5oYKWMIkalu4jTOyQtRjtdQyHkRw0znjbXtOQ0w9EnAkNI0dQMxj6YIGQwAqH7dHml2RNil//FcOJpg3xyYLDa73mIT0lz3Phn4qPUhADyhun0jjJKWR5uaomSSk0EI3HsKGCJjnKIgcDNtc2XXOn95ucu+wMEqeL0SaFM94nT0XL9rWpRZX93p3mI2z2u/7weiiDEzhZUWRT4BQE5IZtaEGJld36XfRXj/GNCCUtWtv2v7fYHOB/kxH6NVSBJ8uZ835efmc6lzwpGDQ5U0xi29FoIqOPfBgHibW+97U4lb39aLFEV44wZ4hH0Ml4t2tH2x/8jMuhPSLym8+Uthb4NvxjnhbSwcjAYpidTpyaqZfW42dHVYrSTUJUGlKYdo/0Q+TZcWy/nb5R/3Kxs26Hs3o3KmzQdq59BF4chpcBpbwcxl7ISndYHyxXXwgTKuoiddDzxt/Z7HweYD1YN+lGF9FwAKXdilZICXdPCoWO1stc1FMFYi/GkY0xnLTDNWwSTonp5lDEUYYKQwegGJoTI1qvOifm/v4XRtjFYLJddhxob2u55HJD+ea8diF61L0HIos+QUbbtwm0ObXJC3UJYUcXMcYCnnAEMNLi+vPnSa7xfrAuk2bDp9BNDMTBwvvS879sNQUkmbb7o/WIDaWsCMbRRVY4OtbS6W5iZf8NzeByfQelgTtxuZWvl/lUGwgGL0bQgBJcX1eu49wFU7wguTo9wni9CE4SFu0iHLzwB5NqtOiKeT08KQ1MDAUGOO+7yvP8dEA/8sNi0eG6/KwQEoP3v/0CVDUG4H2Eib/oprIKQM8ymtxhVi0qIVw60I82jugrt70OfXGlilc/MNmk/C87jsBfVN6hFhb71P8g/bpfzd6KKRl160ilD3WLUzKdnUHZMEEFoatD1+vNtf/oHh3iatU697A3PT8ikPru8oZAgdV/plOhln2uoyEszxpkWn2Jaco44brw2MiLdM8ahCROEDMbBIKy902P+erv99j9ykVYgttvvUTbtcL/3VbBTT4JVcfxY6qp9erTs5h1EQSCQB/pgo1uMAn4cvbgdUOSNa1uvv13+ZVeA70gXPAZpzknUjaO6cuezrwY9AwAQt7Wr1SUitSCsrMANzu41FQhCfFoqn0jZLKovJ+0d+7ZQtOmOYeZYYTS9nYzni1W+rzfsS2zrN1DZXqlXpKT1KVHLw1afk2AkjEjnk6NSEGK1ffmDzmff1K/w/krpHLAaDSfOp25V3vaz570vgl3fUSsrqc8YCCJm0xd+VEt2Bpw+AcDL2wqI2wPMoVitdAMa+bSR2o/h+LncH7XhVyD/utHz4ce+H35FdY162K0mC/s9HjU5JORkwriw9rDfuF571nHD/ZxXz4qkOZ4QaDaLY2gzOLCM62pCqTE7GOxzDR053Dj/aNPS8wwzZwIL9ducwegXTBAyGAeAMSfgmL/d6S9GH3ktBARDzF/v963fhOs7glxMRfpSokC5hE8Ur7JjI8dFx0okwdBmFceMjHQ/uqJdJddLK9oe/Duubw+o2ImqSNPHibn02aeelSvV4qqgIyoBIF4PaqgXaWe8StH2HmoqID49i3pqouzOx86O/dlcRJGmzQLmWLrWiCq7Xn6d+BCQgnyRadfH7SJuB7Wxp+9/O+kODATiUzKAMSTPoYGA+Dra7vpjx7Ov+9Xg/rGgF9WcOVHIor8fPW+/i1s7gi2OohY3U59R00CcNsPe/78EmAV+NHUKHJG3do183gsP1d218vZfDUfRLwP1iZA5Vvsxn/s7tXiH58NPnK++peZXBrNbiIT00REpS+B6/bnW6+/jPLRqkNNfB8BgEWkNxlBzg1pVEqUWo4QQBWmPST4hTpoz2bT0bOMpJzPXUMagEZV3BaN3CI3NWPQSedn1G0R/Hsc8eLvttnsj3ZX9CGOmmM46zfn0m0EsqBM9UUqaRe8og5tb5K3lUVGBkPPP3kxWMYu+oOJAIG/+qf3BR7yrf+AI32OBY4KEnDHAQlmhQZvCuld+zHFUoU0qIl4v5Xm1T7djV081FYTxafQWo4W1xOMBol/fdo7S46ZQdxKVFvjWbqasgQbozT+I4kFle8L25NImp9Mzo23LAjVUOO682/2fVYGqwyFx8mRgplwUIO4Oz6ffgOBj0flY+kRT4mwlXtf+rWmEhVHJfBrt/nlrs1raHDi/GgLi9rjf/K/hqBMG4TsVRk+y3TnJfMnFrlf+7XzqFVTT2nexdaKPXCEnc/Bfvd5P33PcdD/nIaEkQBJM4MgEEEe5o44b29TyxhAzMAcEhDmTwTAry3jGGeYzTxNy6R+MDAYdTBAONfRJDA5f/atIAyEQRYKR/jSMNETxWa9aar/jnkh3pCvm8891vfC+XgCjn3YFuoIyiVOOoj6junsL1+GKFh82bQYwLA4kDY90P/ai7PjV+a8XPf9djZo7/NPlnn8VQimUPKXSPHV7KY0s1zdATHwKpaW+HhiaF7imAuAFwxRqgxyi7i7Y71yqddJolCZQOlto+H78njg6KM0htKOC3KHaB6ovxy0NHAzPnBJAXhoTXYsdvvXfOu68R16fr+cNdhsF2hiQZtMHWyp5G9XKBgorEX4E5U4yp+fENmpCFOzzTMaIHzYcJlDeIGrFLs7Z1tPjEQiS6/WPtIe24ei5dO0HC580wn7XX0ynntZ68+2+NVv7yi/Qa7qKkzMHp2/78H6zquWKO0i7womhTTsJNkzL7dtPuAdQaSFx+qhLgwwYRDwyw3zhQsPsE2B8ovYAVvJ/HuLr/tp0BYo5U7mg4/kZEYMJwiGG+dxlhulHda9aO9QAmg7U5gS4o1Xe8JP7ndXq7obIfigiK9LMsTF/eygUGxXibZc3b1S2bNNNydvbgdkijBgtzZ4lHTmTcp/HjzhpujA+Xd1W0d91TYSFcWlwOH3ev/zrduz1AH7Aiy72B0KwOG2UPmAi2w1Xq2/9Ovdb//V+tgbtcQBe6mNWoQkeKEiTZ1CfUd68Gbe10+S5aac2mPgkSj8k3N6IGqoDGOEQoquBUZRigCge9UDnUoxhSgwMoZqL/L88beZEs0NICBwWDwxWuvOiynrU1MMGUfA90YSlkBMtuwG4ua7j2WecT72Mm12Bh7fWYV4QJ9D7i8pb8jiXk4NBP1v4kfRDRa2uwS2tB7xiEJ8xAkiUA0AtrcROZ483JgSkw+e45U9Jn46HyYO3jCVOmZX40QeO629yvfVZb48mvaarQcgZzDInxPPph62X36o/NsPwGFf5kWOpd1+Vou0hd2AgAKiqzfmPdzuUNzgc+cXxMOAfZsk/r+PTmBvqkIEJwiGGMCJH+4l0L8KAWr7bu+pj9wefK1vziUuNsMT1p5TELL8fJlDOoYm3w/3mq64X35J3FhCX74DJNAI2s+m0Y2OWPySMppxJQ1uMNH2qsqUY9M+skhBVmjoZGmk9AAlSNudxOHoeD0jKnRzB2GLiaW9/9EHvyjVKYRHxagpE7JfHj6aezIZQylequ6qIolCshWsSGsbH8imUWV5oTyOqrw+wM4kIPzIOplPOcYnTo+RVAH7vGNZLiUzIhFbaNFfZqVaW0I5RIs2kf4qiogri9FJXLDi4LcxnJ/IpyWFoKjSIq9W98v2Ox55VdhQB3tBj5CEmMM3Gp2dSn0gtqCAIg6C3V4mYE0L1y6Ia3PFbrLIOFKfS50Cq+eXE19uNqckeeWN+86VXxf/7OerbkAIYOyz2+WfUxvN8X2/sOY6dA4k2Pi1z0Hql4fvue7WhAdIq8P0QTfhCYSz9zStv3R2dKTd4T3soFSyjDn1RUtXDmhhDh2iZ8TEOE3BTnfe7L93vrZbXbkB7HJpwAkLQdWnDjh4seuUFxlMoPc3VsgLHLbd4PlnnLygmdrUA8RD3u18pO0sSP3xD0IUNBZBPzdImj/39dYDFCVOoSx3g9ha5YAcA0eHK7c944Ufn0jeguDmk6tV7g5+E7gWK8k/b5O07gGgJwr9Em+vnJsN4ais/gpvrKWUwQYaTpnEiZVgUKq9F9e0Hlxno7BASRmfAGNqNtZoK0uQ8INAOCxnZ1Ea+xNWBGur3BwEGBSCGI4+lOy+nbzJsDderU7+k2ZkgJpKOMqimzPPRStcb78s/7/AnxPYm0f3ZdynQShs7gGRUVxb0o0kvdhIvjKcPrFXyNnJk/1DRw3QnTqdsi6hqaX6fHwFIRu9nPzSdfk7sk8sNR8+jPFfwQHtS/HNPN568CFW3BIwoIQiJE0dC22BWMwe22271fvadursm1HhRjGF8jDB6BN3R2rsAFdZGf0M+pQAAIABJREFUW77uXvRZUHTkaIQFPZQgKq8zo2eYIGQMBsTrkjev97y7yvPl12h3rW5gqG+zREedce0dMyzOdtP1dApKLSloPv9ieWN+j7tGEGifVMkvbn/40fh/v8JRCS2YZNNmMZ3qqA8Q1l724nRqAz0OVdepBbXRknaPMZ9gF3Jpd6UUj+PG65XdefZ77jfOXUjXCDCYLJdf6P3ul6De14QgYVgKMNM6YRAFNdbSjElCtCFmPJF+DqoW7ehhDV0VMnKAgVK9KIVbiezj9ks4BBPTqedAmjIhskyR5kpUJIwcJs04gu68Gsqu3eGbuiH9koZlszEosIwbG30/r/F+9r33i+/Uij36c6pftW0wnzIcGKlHNSJed7BXjyBFnDhBGJFJeVKsyv/betB6kMALGZRrTNoYVgqLQD9Wl7THvrypsGnxxZbLz7NefbWQRe/yFRTC6AnWWy533PF/gASsRaEKI3M4YVCT6PjhWfYH7mz+3c0Ak1DWf4n2OrDFCiOy6A7HTXWopQGEKfuXwTjEYIKQMbCoxds9qz/3rFylbNqN3R4ARU4Uo2odjKg+y9lLhTE0e3e4vaXlyqt7U4O/AXiTNvdSy8uEUTQTET7NDkTBH1LS18XT9IA9ThxHu/6tzXfzf9UDooQo2SEkICZOSKVdEm6t9379k1JaKox8wzj3NOq1YeMppwm5j6HddcHoZAzjkg+IUgsWCExWmugmTfDkZBqOO4b2vJrgyQs8zCDgx9LHvyl5FURV9iam+qtLw+GUNo97oTM9worhxKP5dMo5JXG1qTtrObqdye5olzQ3pBrf/QNzKiYuh1pbppaWKtvLlK0bfD/twI0OTVT3nQ17cFPAGhNKojXdt2ZafDL1ZjKqKlYLq/dvJitImDwcpFJ6/+LmVnVXQz93P4AkEofc8ejLnrc/MV1wpnnpWdK0oyhtkILBfP6yjsdfwbVNAZ5XgIhjxw/+ZpT5nGXudz7xrAy6pu5BEMKnJ8N4yrQ0VFGPavcMfQsGBmNAYIKQMSDgllrf92vd773r/W4jbmzRQ0NFIaQ3wQCBCbRbzBctpZMKrpee832/sV9bnTxADe1qKaUgxM1uDqH+zCT01KypmTCevs61b/1WDqNQXHDCiPZxYEoyTMqgO1wtr0ZNLQBYvV//jOqrqPN5YEKKefGC9oefB1z/t7U1ZZ5AP/ECAq8bq/Y7TnjfWYls/v3ZMJ4yG1b76pVN5QG6reeEGMQJlDpKb3dX6f7EVK01QYBJ9IUEtM5Am10ljcFdX+1+N0uWKy+h/l5QXSl2toGwGPB2+qxOpfWhJcj18tPytu29r92glhbS3q4Waf90Ea8Td3QQj0/7GgAv+IMXgn0mY2iLp+xwJ8EmSqlIGJFkWnwu9Qm9P23ALc0cL/52fq3BDGijrMKHqgo52RvE+OE10W9AtW0dj77g+td/pVkTjPNOkY6ZJU2ePnCVAPnUkca5R7pe+bRr2jn2+w/nRMLnA4ox/3e/vGEjbugIIfwEi5Mp3wWcbg9b6c/+pX/sMBiHMEwQMsIJkZ3yrxs9H73nXb1WKSzX5n96aGgg7/IogaiqOH2c4Uia7RTUUOl84a1gQkABcXVQnEgD1zn9hor96pdhxpH0OkR1q9t2R1OWBREnjaAugKGW1ZB2NxDNqKHJs3q19YrrqfthXrbU+a+3SIe33wvM2nQ/pFBAflwmx/P9ihPed0pZESdmWS6/gvqkuK0etzYH2AHTI1FNYhalsQfxtKtdksc0QUgdT6sNUGusMHqM/HNBUFG1RPWaLzrbMOt46vMqRaXY0RaeTQZdFRupYxexq9W54jXfxgLQx3vcP3qAjv61AhjahFgb1SFYg/AGPjld37Hs//mwbLniAj6NWgZg37ffExkDad9dhPiR2UCgTFiQ83YQr4cDQe6R6rLQRFw+71e/er/aAGPN2icSZ+Yajz9enDBZyBoBE+jDpwMizTja9crH2r8P+lOi6fk4KZdyDYK0NxOfi3p5TsydYrvrOsetfw1mWa0LWJpI73CrFGyOplcbgxFdMEHICAtELSvyrF7pWfm5vGE78SkcEIBgGArjSzWddion0ERA+b77QS0sDyImkAd8CmV4GHbU92viS/QgNHEifW03ta5WLS8CFKUOBgpimEIf/qrqJuNQn2ghzrvqM8slVwDa5Blx4gzDKUd53vs6iPi60FzjjMcfBxPjSGO/F9SxNuuFMcvv44dRRthyuoQuRXsaAliM6vaSdjiccosVt7SrRRX6rlQnflNyGEdZ3FxH01Lzj/f8d1UQglmWxQkjY/7yp1BKCOrWr54wWYxizGcm8Gm0l7SpTS2rg4I54qZcQQCgOHksB0k/vzUiy9KsCdYbb6bf0a2p8H714/7aJNp5eV6YlEnXGqdbjNYQFQWrB/cCNTWu3VkicWIlv1jJL3S/+gkwG4SsdH54hjgjx3j08cK4yULGcA6EmuMnpGdpb5yu11lPKLDBlEy6NtWqSvf7r8Tc/xR1r6xXXev58DPf2q09mqD2jvYOzRhNfXZlR1StdTIY0UX0TPsYQxLcusf7/Reedz/z/bAONTj8cqR/pvzRACbAajTMmU13tO/ntQc61/WBioXsJD6DJlaHIK9aVdyvNxlC/LD4EOL6OFRSoVY0Uaum8AOIv+oUJfKu/M7rBgTRt3aTWlwgjqWu+QYsFy71fvKtbqUdlojBvhCyJpiXnOxc8W6/FtQR5oBqf+AW06JzQjkpqmjCjg4gdF3mIBiL40dBE3UeVyWuc4bXqch02hkdY59W8ir7VZlDUUG8Le6Zx/kMer8l3Z+kbBe1f28XtEsqjM0EJsp8PFRdQVq9nDDIL3FAvM5QjjcumM//9Unc1M7xfV1GRYFJsXFPPAbj6MtyeFZ/jGqbwf4lPwINBmkc5SOFIB8qKej6KCb91bf7AdoTSdAP0Z4kCtHGsLKzzPvlmg7u33xqjHTEVMPJs02LzxJG0T/6QKoF2s2kHeuycF9Ptbt4WgagrUiEapucj79tPu8ycSzlmiMwx8Qsv7fp9Iv8taaCfIqqmB+ewOfQGoz5XOqu2sF5dDMYQxEmCBk0ENWnbPzJ/eGn3k8/V3fXElX1l64aIjrwNwhCwrBUMZduxZEo+aX9nxoSLEvTj+CTaTK7SJtT2Vq4f3elt7NgmJzGZ9JmJelrqD8HE881wCDMp8TwWbTpcIpP3VK1N/oRAuxweVauFO+hLwJuPOkUISdTL6bXT/P0kCcf9rvv9n63QS2s7WNBXUGcSOz3Xm+/674Q5YpasI3DAbutitnjqY09lJIdurfwvr4BQBQFt7VT9tIPTEiNuf/u5otv5BTcu8kHkX388Pi4Zx81nDA/lDMSVVaLd4fvvYnErPHUBi1K/ib/JR1kIO5oCeV4YdR4yxXntC9/HkBzLyKKyDJMsMW//A/pKPr4XuJpc7/5HkcOOI0m3iSDkElZEpa42pXqSgAOGgB6KRqqO50g7F/HAf7nyd428R63Z/UPntXfdzy8wnrL5babbwMmqtI1gXuEpTET6LdbK3eh9lbnihfjnniWrgUNwzFzrddc2P7Ii8FOGPR88rhEYVgK3XlxQyV2OigL1TAYhwFMEDKCQy3Z6f3yK/d7HysbC7DTCbTZDM8HUZwtqiCYT0uFyVQZEYTD9R39fbESDhgEy/+3dx/gcV113sdvnaYuy5blJjvuKaQHQkkBkkCK0xPCZtmFpYay9A2B3YWlhAABAoGEvLCQhUAa6YnTQ4rTm+NuyUWSbclW1/S55bznSrZjSxqVK1nF9/t5HD+KrJl7NDN35vzuOed/PvFRf/Xl7A0rne3tQ7ue6oaOX6CG/a8Ryq54w/dtR53sAeiV0/Xplf5ubu/YJLo63q7/oWqZ5U8UfeWrvms5qMUVsUuWdf7Xz4f2zqkq2bS/A+2lVy+e8qcbW//5U/amHaoMY31ij7Bs+Z8xv6rkB1fFLv3XkVe/tPoOgPTQFP2Q+f7vduVa+XTu/y3LjY8oEErRiz9a0rCl8zu/EOmsaoZ7n49CPjaWt6r21GNLf/KD0Aj2Htx9f11Ja+U2VR+NFObNXVT0+SN4SFdv6f2QjgXN7WxVnIyi+7/8V/Tlr+VelZ8jz6j9zne1HeHmzCMXlP3imvCpIwrw2aefyL2wRjX3edd1hL6gQq3wWRfH3dXubGx8+zR0XK2sqPzP1+ozqxV3mM+Frif/7/fxn/1tv+Z531fV7ssubkui81s/dju7Sq/+mZ8Il3PkI9nnhq6xwP/uF7lVK1UlnPrrfUVXfNpY5H+qRdHXvp5+8MlhXFnbzdVnVqlFPoeLrU2b3NZWSowC+UzOfjzGnFc19JnnU3fcmn3qVaex2StSZwyyhfFkIIxDq3wuKlBVedvuNQlDOIyVjl58Wtjv1nCZx58Sue7+7uDc8PEn+DuKJBKt1totE2iVhfAGPLUSv4Fw6xa36+36H96s0ZdWW2+uDJ14ku8WRS88L/6r34v27BDqzqtuV7My7MlkvYVOPGXq8r93/c+P0w8+4bYn9nl2vJmrxuLZ0bM+UPjFLxjVI5kJuYdtWW9s7idVukIrjBmH+l6aKOy12/fbQsMbIbRFa8rvHb59R0Vf/Y65dGnXT36Ze/4tkdu3ByzUsB46fknBpy4vuOxj3mYJI+Y0bBCp1OjMOhPyIS0wfT+k8uHzTtWxn/+muTsbRSatFvgPhFrFjCm3/LHz2/+Z/Nt9oiu1/xuOMA6pil50TtHXv6pPHdGGHCKXjv/yd8J2913vJ4RtLl6oRXw23qnbKJK5fdagCsXQQ0cep1XN9XFv5uGvKuLPees565rqhtN/ubf461/Tpgx7loTbGHcTmf2WuMuzuLRAX+T7JedabzZ4L4Dm9vhvbiq77nrfLz9t6szi73+z7dLPK8PcltA8cq6/I0pObZNIZikxCuRDIMSArERu5crU3Xdm7nvCuyDtjbIYqhmdsFVDh8uY4Xc6oqJEPnB6+rbHe5dx60NmOWPpvNIfft973IZPZBLZJ1YMabFi9zikcfjRPo7Sw96yyWncpg66tmcMdfcA/JYYXb/NTabeXg4n7yZnp+64bSSB0FxyZPi9J6TveVIdfPKk7rQ0ilxSDY2gKmM3Y+E7yv/8V2vdytwLz+VWvyHSXqVTY0ZV6Jj3mMcepfsb4u6Ps6vB2dnez6wq11ULS81DfGZON97s7GzY7+PGK/PjONta/bZ0P5EPXxg+9YO5l16x3ngpV7tRsR01HA4dephxxHGhIw9XC0a2TcI+rJp1Ip1ShlbtdxCuqxWWG/P8PqTtu5yWHaPTkuFQDd1as91t7dILRlAQyJvuO6Psxj8UfObF7NOP515509ncrhaEzKPnhI5/b/g979Fn+l8FvVf6vjszjz/f5zqabcz1P003t36lcJ1e75Ddo9B+hI5/t1ZWILrs/FeXhBKNqGE/FYycHVv2myurdL/kSqcYs3yuwXM7mtxdTfIlp2p6+pZ7ij73acP/emwltuzS9EcfSv3p3mFNHA0ddoTvI1ob35xA1zqBiYdAiH65Tv3m9AN3p+9+OPvCmyKZ9aqG9p2RNekJtajY941jF12UvOHm3Bvr8n6kuULYGfPw+VP+9kdjoc9PMmvla9lXVg5lao23hcaiKmO+/8vq1ppat6VrIl1DVc1DfRbll+zaNYq7fw9A1TOPPe92Nmslfvdp1IyCf/2n9H1PDvqDqqY59dtFIqmWjzQQ9jCXHin/jEZ1y7zsLRtEop89FYRwtalleqXP5OnuanZ27OhTudSw6zd0b7Q4CqlGjZSET/6g/DPyuxqAvapBWLlhFBbOz1v+V1GiT/U5XOM0NdsNjeNw7UZVRTxlrXtNn+OzOOq+Qke/y9uo/QBw25q6rv6F4mj7vbi82ramscR/y61XNyuiz9agfosJm0sOK/jcP8V/dKNXNapvJnTk50eu8JOX+hvcttb23mLBW4NXUalXzvXXWmd7g9vaLN/WvD11Wzvj199Qdv0N/seoNaPkP7+Te+pFu6FNHWKtKU015r/D5+GEY9fUjFY5KOCgRCDEftyOluzTj6bveijz+DPujnZvUtokqho6fHqF/xFCrWx6+f/+qvWyT1vrN8m+jWru82Fjy89yS3Y+Yh89q+T73zUO8b9sI3nLX0UqN6SnQDj67PkjmWflVZSZUNdQNdVcfKy/mwrXsjfV9Pp1VMO0NtTmnl8R+fB5vhsVPukk84hDrLcGWwCja3ZNs7OtUSv3OeV17Fnrtrkywep9hrKFGzpqnjKkScv9sLc2OTs6e72GVVW31q/zJh+OZF+7MeVYtRuHUVh4YPIhPX6R7xqh9pYG0ZYah3dmVRG2lXnsucgZF4z1oYcjfv2vrNc39n58XKEWF5hL/Q4/OhmnYdt+oULG41zGaWvSq31dt1L1km9/V7Gd5I23u11x755VTVVU4S0NtdVYuOgznyr80ld83LFIx7PPr1Z7DyAL49BKf3ssKd5LrtFpjaua95CqRih1631Fn/+ssdT/FkfGIUuLrvxi++e+M6ScZrv6rFJ9VoW/Y4lEwlrVoLKAEMiPQIhurpV7bUX6vofS9yy3a7aLbM7buCkUPthGBPtwdm0byc3No06c+shdiRtvyjz6uLV2m1cyTgjFNIzDqsInvCt68bLI+89URrCnn71pbfquRxR9iKVoROhdi/3VremRfX7lBAqEjtArC7SZPmvKKam0tbaudw/AmzWqpO68aySBUCubHj3nQ9bK3wzy/qmqim3l3lxhvsN/n2mMOZs25Rmxc435/odqnU2r+vmuDMxrtjs7thmH+K+tP5ZEKu5s2zJ6H5quOd//sk9n01uj1IzhE3puxYsi1aHGSsetDQPKrngi8cs/vr334F5CqLEiY/ZCf3frtOx0Guv3n6arikTS3rQldLTPWehqrKT0mutil1ySuvN+e+1qZ2ejsGyjcrqxeEn0gjPD7zvd3xty7rUXnc3b+m7sETrK/yRPe8Na+Z68+81B09zWrvgNvyv71Q2+71Aq+NgnZK8js/yFQTd3Fa5jzKnWKnzO7LC31bqdQy4CBwQSgTDo7C1rM489nrrjbuuVdfIdU1VDiqEdxEOC+1Pdro4R3oU+Z2HJj35adGWLu7PdbdnurdOoqNIqp2il/vfO2ivxmxuc7S1Dfjq0kVSUcZq2OLU71AH27HaFMvDcKO/qtu/j9+ZtCjJ/nl7hc6mSs22zu6urn5pyqp598kX5y+rT5/luW8FHL0tcf7NIWANXRJCdmMyTLxV87HMTKGYPwM1Zm9f2f7VeE4bfnccUbzfI1f1MLfMmH8azzzw5WQKh7AFbq+uGOr1tYD0lRhcd7vsOsivXjEdFGY9qmtlX1+Refjl8is8qWQeUs6uh/UvfcNtTfXenFK6rH1KhTfE5Yu/uarfrd6rGPueypoqcbb2xQRnR3p9q6Nj3yj+Kk3ZTSW+9bqxANUc0Nzx9171uPNmn6ptrzPP/krM271d/WNXN9G33F37+c+Ziv9M4vTxcXPK9/8y9cLGI5wYr0+Xo02apUZ/XIOzNG4V8bNlzAsiPQBhQbufO7IoVqVtvyz31ir1tp1frWjcmf9XQYbNrG0blfrTiCvlHWejz2nO/cq8+k/zj7f1c5+6XEGppRB/BKn9rzWq3Y6Cq3GqRNshubxlXyYrR66ba+vRqNeYzENp1G4W360Pv1qiGYTfsyDzyRMG/fNJ3y4xFSyMfODH198cHvrCtamZuhQyfDfIX8X2sMSMyOXv1pn6uCLhCKyk05vm9wOE61ht1/XzfKzTqZB55uuBfPjP2xVF8cBo2iUR2dF7erquVFxnz/Y5+u46zZsd4BULvsJaTvPnm8CkfmHCLsnKpji9+xXq9Js+J6YaOWKQMYUPXftm1G0TC6n3Pqpn5x5PF6YQaHfHMZz2qFY3CR7C9dUP6tgd7V72SZ3F5TJ/vtwCV6+Re2LBfoNJ1Z1d78rc3ll73W/9t9SrrvK/wi//S9f3fqANvZKKq5tH+Sw1ZK+tEOjORlscDEw6BMGCsVG7NqvQdd2SWP5V7q0ZxXNlnDWAO3EOzV9WLbEINT7hVTCLV1fHN/3Y7UoPOpdn985YTWjrfmOF/WNJ6c4ObSPf/kekKJWSW3/xLfe7c/IOEoutHP0rf/kzvbbV8UxXj0Lm+e72512q9HkDfyq5efUstfe/dBR/7uP8cooejl12Uvvcpb4bwAJsQGLq9aUfm8UcLLv+UzwONIWdHg7Ojs++YpzdUO3W6MdfnjnleccKdTf0+1Koeyv5jhb15gzHf/yLbMWNtXKk49pDnbw9EuK5RPtWYNdffzb3B/JamgQbzDzD5xKXvfTz3+ouhY94zXm3oh2N3XHll6vaH80+pcEayO4u1sZ9pul7Z1Vdrcq+sCJ90hu97Hl3xn/3c3tHc60HwzuKqKr3K55RLt2WHaOtU93+vk5kz+bf7C674jLnY/4VIqegrX808+lTupQ19B3V3k++yumEe7vu5E079pskxTQMYPwTCgBDOtq3ph+5J37U8u+J1kch4Q4JmaKJd3h1jqq47jQ3WulWho04c77b01nXND7P/eHVoew/2sIwFh6uFfivsC8da81q+6/1e/7V6SuQD56ixgSYyiXjad8G9PvclVMMwj/C9bbfsAdT3rrq+h+xbZJ95y65ZPYK9lZXoaWcah86xVtUPUlpGaMk/3BK79HJ/m46MJXvTapHL9JNvhauWTtHKfE60c7Zvc1tb+y/noGtOU2fq1luKv/1Df3c+lqzXN8letToagVC+PLXyCq28yt+tnaYmt71tPOe/6Zrbnur68bUVt71TRqJxa8b+un72/fgv/pD3RPNKjOrGoUt937/15sZ+vuvVlckmfv/H8HvfP5L126Ml89RDqb/crRp9PjiEN+VSH/5+hj2sTevcrnal1zUI+TJobkv+9qbS637j7257yPeWkv+5quXCTyqZfNsSCsUwjPk+K3WLTMKqWTtxXqjAxMQZcpATifbM04+n734gs/xpt6lNuMrBXTV0eGR/tKUr++iTEy0Qpu64Jf6T33tdz6EPj+l66MSlvsfTRDqTe3lN3hEz1zEXz1JDA84X7WyzV28fzVELI2T6DWwiE7c35VkOp3RXRGhrT9/3YNHX/QdCtbgsesEy661fDPwuqhpm7qWVmYfvj55zie9jjQ1r3WaRyfbTlVSEeUy175Exu3a709KpGnm66ZqR/MMdBR/7uD57gb/7HyOuZW+uH8VZmuZx83wnOnvtVrctMb7z31QzlLnvyeSff1/wsc+OYzN2c3Jd117d9d3rVCOS9ylyhDq1WJ/rd5qunbZrG/t9AciHIn3P49lnHgufcqbPOx8lTmN9xxe/5Xbl+rtKJfTFs3yHIntTo0gkFbV3z0HVw6m/3VdwxadHOEgYOX1Z7PJzkzfe1n/nxBX6vBK9yudzJxIZe8N2SowCAyMQHqzc3KvPZx58MHXXw/aGut1VQ/UQ18h6U83U7XcVXnGFWjiifZZHUfbp5R1fvlLJucrQy1cIITsl4aN97tCgeMtO1jnbWvvsFPf2v3tXZ42BriM4DTUilRho/uSwyB5AZZFW5XOXNhFPWzXb8u7Spnq9o8zyRwq/9OWR9KpjF1+Q+PWfREdqoKWVmirSbtfV10ZOeb9a5LNm+tCJXNr3DHB7XZ3iuv3+k7nU/5ROe/MGb5pxnteFauj2lu3xX1xX+vNf+z7EUHk7yGn+XqJuZ4vdWDd6gwxiRA9p3frxn/8mH0ZL7frPn4SOOtp8xzvHsSEi1dH539+N//wPXkU0Pe+TK4RrlFSYc3yuQ3Ma69y2pj4bOXTzyiPlOq764dRH3qkVTfF3/yPnJtrbr/ictWZTngu+auhI/0vcnQ0bhe2qfdez65rT3J684abSX14/ssslWvFV38o++qyzZZfSJ816810XzFNLivzdtb1lvWhLDVwADAD54GBjN9RkH300efvd1sur3Y64DDyyW8yQYD6qYeTeqEne8qfCz/jZ7mnUZZ5e3nb5Z5wdcTU0nHPTFVpViTH/MN/Hzb3xukgn8vZ3VVV+Hg/8eZ+rrXHj8d5zivzyegBL5mglPkvtOdu2uk3xAXoAqmnkXl5nvflS6IRT/bZRMQ89JvKhd6duWd67fkOvY4XM3Itrun76s5L/+bHvYw1F9qkH9VmzjYV+iv6JXMKu35jnE0H4HqpVvJVXqwZOL6oRTtz018hZp0c+cI7vowxK2Ln0fTdHz/onNeznEoDb2unUNea/YjJsxgL/tRmttavHPxAq3hJZp7617ROfq7j3Dn2m79ndI+Js39T+719N//1J1QgN0uMXrjZ9qlrsc5W13bDT2dWW79KPGgrlXnyr89v/UXrtr8dlcrhIdnR89Yvpe/6R/+ia/7NY2NaWdfm6i6oeSt5yb+HnPm2MbJDQmL2g+D+/2vapb6jC6PNR4xgzF/iuvGpvXidP/wlXAAmYYAiEBwm3qyX30gupv96e/ccL9tbGwFYNHTZvowS96we/jrz/NGOh/5LcoyLz2AOtn7jC3daZd219HsKxQ0ctVstKfB/aenW9yNn9H1emzcIC87C5A9+DvbbeG4getWlsjjFnkRry2QOwald79T8GqBmjqm4inb77gdAJp4zkwnbB5Zel//6Itz3XgONOss8U//lN5uGLY5d83PexBpZ94oG2L/zHtMce8Xdztythb6rrZ8av4+rTivS5M302y3WsVzcNMjdS05SU1f6F/5h6/3xjwYGpLuPaHVd+VXWzsQt8lpa1a2vc1qFWeBqEfEgri/U5fucuWjlrZf2oDcWPUMjMvVbb+i+fKP/f/ydP2DE+eGb5ve1fvcpeX6ea+WeKvk2ETvCfWp2azSIxUJlKmUgT19+qT51efNV/KUMsDT1KnF0NbVd8LvP37jTY7+Mg38OnhHW/daFEJmOtru1/dFTpXknY0pG4/obSX98sfBnlAAAgAElEQVQwwjnVscs/7m2GfPdT+51owrv6oR82yBXJAeTerBWWNbxrrEDwcIZMbsJK2+tWp+68K7P8sdybNYrtBLtqqC+G7mxr7vjGN8tvuUUrGKeJo8JO/v63Hd/4oduVHW4a7Gabhx2rDjilc6CDW0lrw1t53w2Eq8ZKjOqBpxs5zqbRm8bmzTAU+pKF/nsAq9YLW/YABrokLPs3mUeeLL6yRS3xWXlPCp90qrlkUW7lxkFqq2qaSDsdn/+2GotFz77U9+HyyT5+X8tlnzWPmKdN81lVyN3e6Gxt6zvjTjiuVlWpV/otTtja5DZ3qIMuljNNe319279dMeXWm/Wq0d6iw053/Pe349f+tvx6/7Pa7K1rR6s5wnH0WTONGT4DobOj1m3rmDgLotRQKPvE6y0XXFL+/24IHT1Gi7Hd5m1d1/408eu/iJQ95PkvYiTr3OzNawZ5f1PlO0q487u/cjtaS35wjRot9n2sYck++3jHV76Ve23dAKlYnsXmIXO1KT6vGDpN252GjgGm46pGOPm3+wqv+Kyx1P9upT33U/K9/8o+95poS789GCuEGomYS/xuGyvPt9q6cdujBZg8CISTldNYl1n+QOrv9+eefcONJ+VT6QUJP1kCsk8TTt/7bOe3rir7+c+VfNUvDhj5VHb94HvJm+5ShDZIycp+eZ+XYfME/7t7u62duTdr8u24LVyhVZZqVXMHakI2bW3ZNGorrITQorIH4HMBoZdO19YP/lOmkVu5OfviisgZ5/k9kKLGSmOXnZ178yfy7gb5SUN3W9Ntn/hK+f8qo5kJXSv+u+u6vv0zt73DXPBh35PD7a1r5DPd34xfR6+crfnNzNamtW68Y4DNLfeSLc8+81rrR/+1/HfXGYv8T6fsxdmxufNr307eep8WKzGW+t2ETXa7X16t5N9xZZhcrWKG6vfak7Vls5vomlBbbMv3T+u1LS3nXFb646ti//RxRT2AH0MiE0/d9rf4z663Vm9RjdBQL591jzIZh/jfcyL75iAznz2aDIVm/Od/sTZuLfvZNcYIdmwfCrerJXH9r+LX3uS2pQc58YVtzJqnFftc32jXbeh3T9e3aarb2hX/7Y1lv77R3yH2Mo84rujL/9b5nZ+r2t58K9RQLOS7wFiizd6+mb4uMChOkklGJDuyzz6dvve+9AP/cBubhUPV0NGhmqHEr29RbKvkmmvGsDCAm77/js6rfmSt3uztAuJv1bsMhLGi0OEjuPi9/k3REs87CU245pHzBk6qoq3LWtkwaius5G8ULTQX+VwSKc8Rp6luSCtGXCd15z2RM84dyfXj6HkXdP38JtGSHqi0TA9TFzIT/vMXi79TW/SlryojXmtkbVzZ9b0fpm5/RHXlL6sbCxf5HqTNrnxL2HZ/Y6rCWDrDdz19u3aHm0iq6pBmWspckf3Ha83nXlZ2/dWRDyzzd8R9uOn77uj8rx9ZKzcrWkgrLzPmzfV7T5ZT03+FSV+EeVS1/4d0/TYRT6nmxNpiWwYzt7Gz7ZP/kV7+WNHXvxw6evT3JxTJ9vSD9yV+8/vsilWKqwxv+q7j6DOn6HN9bp0iMkln464hTdP1ImE488CKXW+eW/S1zxZ88lOa762ABmhPNpF58J6ua36Ve3mdqptDSMWuPq/a97ar9ls1SiYjT6IBfkbVQ6nb7i/8/OfMJSNaSSgVfuHfMw8/mX121e7fyxX6tGJ1qt8R9dYuu2Z7vsudAPYiEE4yif+7sf2K73SXeDO7O3+qsHIH8oC6auoTZb3KAeV9kJuJG261N28t/dnV5uHHH+gD5l57Pv6LX6bvfExk3RGtTXJcvbpiJFX7s6+84k2wzLvnodOdzQZKGvb2WiWbHbUeswyEZUV6pc+pg05zu7U5f4nRfWlm9skVTlO9Pt3/NEVj4WGRk0/0UtmApWX2/LQu4nbHN6/JPvt88ZXfDL3rZH8Htes2Jv/3f5O/v9XZ0dqzoagaDo1gBEw4a3b0PwKmaqGj/a+tdTbUKLarhIb6wlBDIXv99tYLPlnwqYsLv/glv9uIi+yKJ+K/+k3m/mdEWqbcsLAsraDU97Pstmx3Wxp996d7UzXzUN/L7YRdu75n6fOEI/vcrkj99eHMw8/FLl9W8LHLQ8e+Z1SmkVsbVmYfeTh5853WWxuF7VWEGmD6Yr+E6+rTKvVKvxs/1m9wO9qGOk1X9V7Gzo6Ojq/8IPW3uwo/9S+Rsz6sV/md8dirJQ01mYcfSf7f33IvrxE54b1pD/pICG/zG/No/w2wN9QLx1UHfsy9PQk7Ejf8ruy63/o+UA+teErx965qOfdjStrbllC4jnnsAi3m8/KZW18nWpPKwFP6ARAIJ53YOZeFjjh5SJ3dkZAJ0DBUw3BaG3OvvpK67XZ7VcNQ5n1Nbl4mjGQeean5rYuKvvapgk98yvdm3ANxMrlXX5YfnOl7Hnc7k6oRHnip26CEcEInHKGG/Y4SC9d6ZX3eDeWFN9JmLh3koq+1YbXIZkZrqpjXAzh+gVros8i4u7PZbewcSsb29jzY2ph96vHYZf/m71jd96IVfvbj6XufUNyhJWJd9nHM9L3PZJ96LfKh9xV88p9D7zxRKx7SnEyRaM29tSp161/T9zzpNDSqemj3r+m4WmGReZjPjZsVJ+1s29zvmKrs3Jp+94OW4cXemrc4YT5qyBBJO37tzem/PxK9bFnsEvmOd7iiD6k76DRuzb3wfPLW27LLn3MTubenFArXPO4QNerzFeU0tzo7d43WHpsyV4SO9L3WTrU3D/shHTvyLVTG785s4le3pP58T+hdx0TPOyN86mnmvLmKMbwCUW682dnSkH3xmcyDT+ReftNpavOWRZiGOuSLC/tz9Oq5aoHfOZPbG92u4U3T9YakhJ57eX3by98wFvw6/MF3xs4933zHEfqM6uGWuxS5hFNfb735eure+3PPvW5v3THMh0IooVDoSN9bg7h2w4ahvOS8PQlvva/oC58zFvp9x9gjcuqZRZ//WNdP/yDfKr0V8guO8D2ibm1eIxQxAa+fABPNRP1cQR76rGr5ZwwOZNfVpO++M33vY9Yba0XKOvjTYA/v4m7Y3dnV8fUfJ2/+e+FnLo9eeNFIho/2IZwd9ZnHH0rddm/u6VfdZKa7Nz8ac31VJ3zcySPYkr7T3rJhgOV/ajiafuzuXM2ripsnNGpq9okXFVcdrbcT2fN2tmzvvPpKP4u2NNV+a72qD7UpqmLGr/+dtbU2byQe/C5UEU+osbBI2EO/iddvTuVStz+cvutR88hFsuscfu+xxuJj9GmVatTw4r1hiGxWsSw3nnV3Nlg1b+WefdN6c1XurQ0iY/WuHaXK8OUk/vA7taBg2A+abH9Xl1Vbrxp9HjRv+WihPsfnwKPIZHJravIWJxyAzMx6xKlvjV99U/I3fzGPPTJ80jHhE08w5h6mlhV5XeFo1LsSkk4L2xUdCWd7bfa1l3PPr7FWvWXXbPdeBIa57xUBVTPs7ds6r/6Wn2dZU511daIjN2qDDJqe+NPvtWl3Drsx8lnOWrmXN/bzTE0o3U+f6LIyy1dklj+rTftJ6LBDjcXzQyceYc4/VJs+Vy0Kq/JnImHFMOWDIFIpL7J35UR7i8we9pZNuRc22lvWW2s3i4Q372DkldLkPTjN9Z0/virfTpsD0VTrlTXeaJU5zPdY79NEvmZMe1OjXXtn6qa79PmV5sKlxuGHhI473Ji9SKucrRaGVU1Vw2Hv1SUfikxGcR2RtkVnl7Ozzt66IffienvDRmvDRqeps/uh8FE8XL5ulORf/qiW3jX8l5wqz7Lc6+uG9JLzBgnj7V/5Rug9R/t/O+0hT7pkqxo1laz33GXfeMP3c5d55OnRupQDHNwm9ucKxpzbulOGlvTfH8w89pzbkfTeUOUHVRCmjO7L0FVFt1Ztaf/Cd+PX3hA5/QORM08OnXCSVlExzEqetkik7Pra7Ipnc0+/knl2hezjKt7F49Fb9ukK2Tl2Ojdnnrjb1+el5tTX2xsa8n7ey2feVpI33e9VHMnP+8QdxU6qoVuvbs69+BufN1e1QWp+9jrWSzW559f5PNbuI6revM3hniWa5oUWoeRe25h7bV3yxttkVNAqCrQpMa28XI1G3PYOkUw69Z0ik1McR7hO9xRus58hZU0TyWz8Rzf77Yd586X7LmGVIVM/ZJZW7rNeortzh1M3UHHCQXSfhiLlZJ96KfvUi6pxk3yN6bNL1MKINmWKfNzclhb5yLgNnSJnCcfxyuFqec4s+Sw/tzH3jzU+W6IN5xU1KFVNXHeL7x7z4BvuTRBeLPRWnYnWbOaplxX5DN6kK7r3x3sSw4ZWWqLGCmT+cXY1e7MC5Os8lVOEIxy3+93GUM3R20FXvgBe2Jh71ucLwHt/81Hua+/Nvdt6N3c2tdg1TykPPeldsfJOf0OTD4WhayXFamGhfAN3WloV23Jb025zwhvZ233Wa90LBf0+FKo3gyD+07/4f8kNeX27PE0yy1/IPLjC34H2o3mXdbzGG2Z2+YrMA8/4uxvvoT7QM6qAgwKBEN3sbPbFf6TvezB916NOXZPsCHbPthqNTbcmre5tiwynri3xu1uSf7pDqygxj10QWny0vmSBcch0feo0rWyat9ljqfe3cGy3Y5e3VKWt2WnZ6TQ0O5u221tW515f42xpFalE9xoM+ZCO9v5U8nPaUbr+63f+SyDKrteg2+iN/QKMnrA0NnT9gM/BHsCeYQTvayFkR9DdmRBuU/fSH69qYXeg0hRDUwctZGqO+u5njjFrvuq3Koa1db0ycHHCoZCPwd6zxnGdTW3eQIpoULqHS5Sex0ftXuo8yP2M4StqMAfgmZrAdFXduy+fzCQ9T6I3JtjU8661e21eT00mzThQ9VMnwgug+xrH7q+FInKOs7G1+7Tf81B4L+nuJRvaUM/6IRqzl5yX4kad/Jwd8qQPAP5wjgWdvWlV5pHHUnfck3t1nUikVC3k9Y/ZwnUv7yM5orjyI7szc9/LGeV5+T2tKKpGot68Pvn5Her+W7hKTvZ9FZHNiExaJDPekIXsCmmG99GuhUarIEU/ZEfCGv7Y4L6CNgI8YcknwusLKupo7eg4QqowFs7xXRfEWl3rTYHTRq8X7q1t9l6r6jBXYWGi6Hmr2f0kTowX+XjpeQx2PxQAMM7o9weU27Yj++xzqdtuyz79mrOj2fuINnwsTgiM7oGI7m0VTO/KblqIVFIRie5/E2L3AJu6+ye9Pn34ACbAfpsHjC4hVNM0j/RfvdZeu1U4zpieCAAAYPgIhMEicglr1Vup22/PLH/KWr1JEf4WqQdbz5Sefa7qksZwUFJ105x/qL/bCivtbK/lIwYAgImPT+uAcJy6LekH707f9XD2hTe8tfuKwXb2APJyhVpRoFf73DHPTcTtTVuo7wcAwMRHIDzIiURH5unH0nfcm3nkGXdnhze50Ryl3Q4AHLyE45hL5qiFPt8rRNMue1PL7kohAABgAiMQHqyc3KsvpB98KH3ng3ZNg8haqm4qps89fQEEj20sWKKGh7ef+Ns3rtugOLbvgjQAAGDMEAgPNnZDTfbJp1K33pl78S23I66qplfqetzLbQOYXFRhVM/3vUI2t/JNYduqyTsPAAATHYHwIOF2teReejF1+23ZJ160t+zwNjzQqRYDwBdXqNGI8Y5q33dgrdnWvb04AACY6AiEk5yTsdavTd99V/q+R3Kvb1AcV9VMciCAERGuFisy5y/2eetMp1O3mc8XAAAmBT6wJyu3qT79yEPpux7IPvuK257yhgRDIbZrBjAKhKJGC/Sqef5u7ba3OY3bKTEKAMCkQCCcZEQmkXvhmdQ9D2Tuf8yp3ykcoRohlggCGEXCdc3j5qqFhf5u7mxvdupaFJ3PFwAAJgE+sCeZ5J9v6vjS90TGVrWQopuqTt1QAKPOMRYsUlSfQ3z25nUi56ghPl8AAJgE+MCeZNyuTi8NskoQwIGjusbCw3zf2tq4ahTbAgAADigC4WSjaYrK1l4ADhhXqAURY9Es33dgvbp5FJsDAAAOKAIhAGAfrquXTzHmzvV3a6/EaMMOtqQHAGCyIBACAN4mhKsWl/kuMeo0bXNbd3lzGQAAwGRAIAQA7EMI49AZvhcqOw3NTlOLqpuj2ygAAHCAEAgBAPtyQ0cc6vvG9sYNIut426ICAIDJgEAIANiXay46yveNrdpVLCAEAGASIRACAPZwhVoc1ebN9n0H1uvrFYX9UQEAmDQIhACA3YTjmFVVxpzpPm+e7LDrWtgaBwCASYRACADYQ7haeaVWPsPfre26DaKjRaXEKAAAkweBEACwl6svmamaEX83tusa3a6Eouqj2yYAwGRiO4oQ490IDAOBEACwlxo+4UjfN3Zq6kU6q4YKRrFBAIDJwXWFbcs4qFdXq2FqTU8mBEIAwG6qpts1NanbblLc4V/cVUXm0ftVNXwA2gUAmKiEUBxXuDmtuDB07BEFl10SPu392rSK8W4WhoFACADYwzASv/q7Iu7wdWPhTRY1+VgBgGBwhbBzqqHpC2dGl50WPX9Z+F0nKyqfApMPzxkAYB9eSRiqwgAA8hI5S1EcraQwctpJsQvPjpx2ljbFZ3lqTAQEQgAAAACDsR3hWqqhh45bFDnntIJLPmIsWqJoLBec9AiEAAAAAPLYXS3G0edURj743tilF4be9R6tmFWCBw8CIQAAAID97a0WU1QQOvodscvPj5x+hlG9ZLybhdFHIAQAAACwR0+1GFPTF8yMnn9GdNk54RNPolrMQYynFgAAAIAict5GglpFceSk98YuPT/ygTO0KVXj3SgccARCAAAAIMB6qsXoWui4xdFzPhy9+Dxz8eFUiwkOAiEAAAAQPN7UUG8DCWNOZfjUE2P/dGnone/RiqeMd7Mw1giE40zTeu/3JYRwHCfvDYQ4sA0CAADAQcyrFuMNCWqFsfC7jotdtCz8oQ8b1YvHu1kYNwTCcaYbvZ8CGfhsr7Zv/1TTPMAtAgAAwMHI20DCUg1Nnz8zev7p0fPPD7/zREVlamjQEQgnGWPmTFVmSCEUVR3vtgAAAGAS2F0tprwk+sGToucti3zoLK2schyaIYTjun27sCrd2nFFIBxnZt8RQte1crl8P6+VTlE0TXEPcLMAAAAw2dneRoKqboSOmx+98OzYuecZXrWYcZtu5gVC2+41qiHTYCjEKOV4IhCOM9M0e10UkaeKZVn5fl6vmqdohuLmnVMKAACAQNtdLcbVZ08Nv/+9BR+9KPSu906EajGu6+Z69XKF0HSdEcLxRSAcZ6FwuO85kBtghHD6dH12iVPbrBj6AW4aAAAAJg+hCNuW/2lFkdBxx8U+ck7kjLON6oXj3ay3yUBoWda+XV8hO8OmqfYpsoixRCAcZ+FQSJ4VYp/aofIUyeZy8jv9XixRC2Pmorn2xp2qQiAEAACAojiucCzZNzQWzo2ee0rsootDx71T0cLj3azestmsu38tfdnjDYXDOoFwXBEIx5k3QqhpYt/p1KqayWQcxzH6LC/0/tGMGUuPUR54TlEoNwoAABBg3kIjx6sWM6Ukcur7YhdfFDn9dK10HKrFDFE6ne475hHub7ocxhKBcJzpuh6JRJKJxN7zQJ4S2Uwml8v1Gwil0PFLlFDIG2Ln3AEAAAggb0gwp4ZDoRMWRM87J3ruWebSoxR1nDv2PTNCZcDL9wOyx9s3EEby/zzGBoFwnMlAGI1EEvF4r3MjlUrFYrF+bxI+8SS9vMxt7lR0htcBAAACY2+1mJnlkdPeH7tsWejdp2qFZePcKNdNJBIdHR2tra1TysvnVFf3+2MyCqZTqV7f9HrCeXq8GDMEwvHXN/jJ86qrs7OioqLfn9dnzg29+/D0XU+rOiV6AQAADnb7VIsJH3dc9JKzI2cuM+YsGN9Gyf5qMplsb2+XUTCdTtu2rSpKYZ40qHQXTUyl0/tVlBHCMIx8QyAYMwTC8VdQWKjr+n51ZVQ1mUo5jiO/388NVC1yxhnpe55i1igAAMDBzJsaaiuqayydGz371NhFl4aOPkYxxjNByQ5qKpVqa2vr6uyU/VXXcdRumqpGotHi4uJ8N0ynUjITavvXj4nGYqZJXYxxRiAcf4WFhYZhyDNk7yUT+UUqmcxms/kumUTPPKNr5i+c7W0qm08AAAAcZPZUi9ErSkMnHRO75JLIB0/VpswcxxbtzYGdnZ2ym+q67u4cuCfgySaXlZXlK4EhtXd09PqOvElxUREVZcYdgXD8yTNHZsLW1tZ9zwd51nV0dOQLhPqshZEPvy95050Km08AAAAcNHqqxYRCoXcujJ57VvS8ZV61GGXcykbsXR/Y0d6eTqedveOB+w/0yWinG8aUKVMGuJ94V1evb8o7KSgsPCDtxnAQCCeEkpISGQh7fVOeeFVVVfmumhR87J9Tt9yvZIWicVkFAABgMttdLUboM8ojZ54SvfCcyEmnq7G80y8PNBnw4vF4pxcDB8qB+/58SXFxYf50J1Nlus8CwnA4XFRUNPqtxzARCCeE4pIS0zS9xbj7zBqVZ04qlSooKOj3JuET3xc+6YTM8ufUELV6AQAAJqE91WLUgnD4pONjF50ZPft8ffYh49Wct+vEDC0H7iV/Zlpl5QCTP1tbW+W97Xs/MhDKAMkCwomAQDghxLp17TOSLs8omQ/lyZMvECpaqOibX8w+8zKDhAAAAJOMNzXUUg3FXFwdOefU2AUXhY47QTGi49OWvesDu+uFDj0H9pAxsqxbvh+wLKu9ra1XXJT/W15ePtKmYzQQCCeKioqKzs7OfU8V+XVrS8uMGTPyLc+NnHR67LzTk7fcr4YiY9VMAAAA+CWEsB1F5LSK8sj7jim4/CPhk08er2ox++ZA+UXfOjFDpBvGzFmzBhgebGttzWazveaLRiKR4pIS/63H6CEQThQlpaXhcLhXrdFMJtPa2lpZWdn/bTSj+Dv/kXlqhbszwSb1AAAAE1dPtZhoOHTkguiFy6LLzjIPPXZcGrJvnZiR5MC991Y5dWpR/t0m5A/s2rVLJsBegVCmwVCILbUnBALhRNFzmaR5165eZ8uunTunVlRo/W5IKJ+/JUcV/vunO791jaqwkhAAAGCCEYqwcl61mDnlkdPfH7v4nPC7368Wlo5DQ4To6urq7Owc7vrAge8zGovNmj17gMVLra2tMn/2OoquadOmTfN9XIwuAuEEUjltWmtLy77fkSePPIXkiTQ1/zlT9MV/zz77XOaBFVSXAQAAmBD2VouJmZH3Hh+58EOxcy/UZ41DtZgh7hvhj7yf2bNnh8N5u6DycE1NTX2bVFpamrdMBsYcgXACKSwqKikpaW9v73WK7tixo6y8PN9KQjVaVHbtT5pXX+DUtSgmTygAAMD48aaG2ooqzKVzIx8+JXbppeZRR6vmWIefEdaJGQqZ66qqqioqKgb4GdmARDzet5zM1GnTRrElGCHywwQiT4zpVVWdnZ37flOeM8lksqmpadasWfluaCx6R+n1V7de+hkl47KYEAAAYKy5QjiOIix9WnnopKNjl34kcupJ2pS8nbcD5O0c2NmZSiZHuD5wAPKeS0pK5lRXD/AzlmXt2L691zd7dpugvuiEQiCcWEpLS/sOEsqvmxob5ZkTi8Xy3TB61sUlP9ja+fUfKK7KLhQAAABjpKdaTCQcOmp+9KILo2efZh52/Fg3wXGSqVT7iOuFDpG8f9kpnb9ggZ6nyEUP2X1NJpN92zC9qmrgG2KMEQgnFnnq9h0klHK53LaGhoWLFg1Q0rfoy193m3Z1XfNb1Ywo+X8MAAAAI9VdLUZ2uLSZU6IfOjly4bLIKaerkcKxbMLb6wN7cuABmBfal3DdSDS6YOHCSGSgbc/i8XhjY2OvjqtscHFx8ZQpUw5c8+ADgXDCKS0tLZ8ypaW5udcgYWtra2lz84AVmdSS739PZNPxX/5JNcKMEwIAAIw6YXVXiwmHIqedEL3gw9Gzz9dnzZPdsDFrQE8O7PTKxIx+nZhBDy1z4KJFiwoLB4q+skn1dXW2bfdqkvzfmbNmsXpwoiEQTjjyfJ45c6Y8yeVZ1OuySn19fUG3vDc2Y6U//ZlaXNB19Y2qrSkGw/EAAACjwZsaasncZy6ujpx5Suwjl5lHHqmGxm5IcPd4YHt7xwGrEzNoAyLR6KBpUNq+fXtnZ2evhsmbT506tays7EC2EX4QCCciGfmqZsyor6vbNxDKr3PZ7JYtW5YuWaLnqTjqMSIl3/uxPrOq88ofue1ZNWSORYsBAAAOSq7wNpBQbG1aWfSk46OXXhA5+VRt6thVi9m3XmgqnR6beaF9yThXVFy8YMGCaDQ68E/Kpjbu2NGreUKIUDg8a/bsA9lG+EQgnKCqqqra29ri8XiviaNdnZ11dXXzDjlkgMWEMjwWfvrLenV1xxeutGu3dy8pHIMmAwAAHCyEl4G6q8WEQkcsin70nOhZZ5lLjx2z43t1YpLJ9vb2A10vdFAyy8m/p02bVj13rmkOMtIgm7pl8+ae1va6k1mzZg0aJjEuCIQTlK7rc+fNW79uXa+Jo/JdYOfOneFweGb+XSh6RM8433xoUceVV6XvflJVDaaPAgAADE5mF8tSNUWbMSV65qnR888Jn3LamFWL2Xde6BjUCx1Ke2QInDV79vTp0wccjfBYllVbW5vLZtU+k0XLp0wZsBAGxhOBcOIqKiqaMXNm3datfXfzbGhoMEyzsrJy4HswFh5WcevfEn+4qeua652tTaoeYpdCAACAfu2uFlMYCZ90XOzic6NnnqXPnj821WJkCO3q6urs7OwY8zoxAzRJ/l1WVjZ7zpxBFw0qPWmwpkam2b6TRSORSHV1NbVkJiwC4YRWVVWViMdbW1v7nlpbt2wxTXPwbT3NWOFnvxz50Ifi112Xuvkutz1JLAQAAHhbT7UYRZhL50Y+fGrsIxeZ73wVVH8AAAwtSURBVDhWDY/FkODb+0ZMmByodPczpVgsNmPGjIpp07QhbGYmf5FNmzb12km7h/x1qufOZbLoREYgnNDkSTV33rxMJtNrW095askTr7amZv7ChVMGzYTyaZ67pOwXNxT+2ycSv70hdftyt7VLUU3V0NmuEAAABNSeajH6tLLQu4+JXX5J5KRTxqZazL51YiZaDpTNkOFtWmXl1KlTB10x2MO27c0yDba19W2/7K/OnjOHjQcnOALhRBcOhxcsXLhu7VrLsnoVHZVvH7UbN9pz51ZOnz6UuzIPP77st8cXXvFa6q4707c+ZG/aKnKOqpkyd3rJkGwIAAAOem9XizFDxy2JnndWdNnZ5tKjx2BqqJcDk8m29vbOibE+sEfP1FD5t2EYBYWFPTtDDDEKKntmivY7Nih/QRksZw1W9gLjjkA4CRQUFMxfsKCmpsbZv8BMzzjhli1b5Kk4c9asQVf69jAPP7bk8GOLvvy17D+ezDz+ePbRFc72FjeR7P5HXdV1drQHAAAHHdVLPZalqEKfURE565TYBeeHTzlVDRcd6AO/XS90Tw5UumeBje/6wJ4cKNsgc2A0FistLS0pKSkqGt6jkU6nN9XW9qqK30P+mjJYzp07d4gdVIwjAuHkIM+o6upqmf3E/mV8e75uaGhIZzLz5s0zBtifcH9acUV02SXyj9vVbq17LffiSnvVWru+1t6yzd2RkEdRhKt0v2EBAABMejL/hM3I+4+PLjsreu55+sxDDvQBZSKSSamjW7p7/0Clu+fW03nryWNjqee4PQ0wQ6FoJBKJyiQYkyFQfukjtsnfa8vmzZl0Wu0vDRYWFs5fsGDoXVOMI56kSaOyslK+c2zdvLlneve+/yT/t3nXLvlec8i8eYXDvLSjFZeF3/lB+Ud+LTJxkUi5HZ1u+07R1e52tCgq5WcAAMDk5zp69SLzyGPUUMHYHDCTyViWJbNWVVVVTxQbm+MOIBQKyYRmmqamabqu+x67k33Rxh07tm3b5q1+7JMG5b8WFBYuXLRIHm7ETcZYIBBOJtMrK1Uhtm7d2ne7T3liJ+LxdevWzZo9W0ZHf5MQ1EiR/KNVVCrKolFqMgAAQBDFuo13K0ZfOp2uq6trb2tT9ow67qtnbFCmQcqKTiIEwkmmcvp0GfZkJuy1Yb3SnQnlN7du2dLe3j579uzhzgIHAAAA8pFhb9euXdsaGnK5XL9jDz3rBucdckgkEhn75sE3AuHkM3XaNDMU2lRbm81me52NPRGxo709EY9XVlZWzZjBYD0AAABGQgjR2dm5bdu2eFeX0j0I0fdnZBqcOnWqTIOsG5x0eMImpdLS0iVLl9bW1iYTib7npPyO6zjbt29vbW2dXlU19G1kAAAAgH3JKNjU1NTR3t53yVKPnvIWM2fNmj179vhuoQF/CISTVUFBwdKlS+vq6lqam5W+c7hVVVPVbDZbt3Xrzp07ZSasqKhg+B4AAABD0TMqKLuRHR0djm3LpNdvGpQpMRQKzamunjZt2tg3EqOCQDiJydNvwYIFhYWF2xoaLMvqe0mm57zNpNP1dXVNjY2lZWUyFhYVFem6Ph7tBQAAwESXTqe7Ojubm5sTiYTMe/m2TOzZzLCkpKR67lzZHR37dmK0EAgnNxn5qqqqiouK6uvr2zs61P7KPfVsOCMT466dO1uam2PRaFFJSXl5eTQaZYUhAAAAZPDLZrPxrq627lIUuVyupwOZbwqo/HnDMGbMnCk7oow0THYEwoNBQWHh4iVLdu7cuWP79r6VZnrs3Qg1mUolksmmxsZwJBKLxQoLCwsKCuQXejffO9IAAABgsnBc17Fty7JSqVQ8Hk8lk6l0Wv6/0t1pHGApoBBC/l1aVkZN+4MGgfAgIc/bqqqq0tLSHd21ZOzuqd79/uTeZJjNZDLpdHtbW89pHwqHw6GQKf8YhvybNcEAAAAHGZkAHcvK2XYul5NdQfm/PTM/le7O5MDdv56fjBUUyD7ntGnTGEU4aBAIDyrRaHT+ggVTp01ramqSSc9xHE2eq3lO173JUOke90+nUqlk0vsfIVTSIAAAwEHHy37yz55OoLrHoLeSItGozIGVlZWUrz/IEAgPQsXdurq6mhobOzo6erawH/RUH8rPAAAAYPIabmfPdV35d6ygoKKiQqZByk8clAiEB62eWJhKpZqbm9vb2tLpdM8uMaQ+AAAA5NMzg1T+ret6aWlpxdSpZeXlJtvNH7x4ag9ysVisurp6xowZ8Xi8paUl3tWVsyyxZ19RwiEAAACUPfNC5ReGYUSj0bKystKyMvaTCAICYSCYplneLZvNJpPJzs5OmQzl17bjiO6ZAIwcAgAABMrekUD5t67rsrtYUFBQXFxcVFwscyA9w+AgEAZLuJtMhvLkz2Qy8Xg8nU5n0ulsN9d1931rAAAAwEFm7zCATICRaDQSDsu/C7oZpkkKDCACYUDJN4JoN6U7/sko6DiOlcvlLMvurkSskAkBAAAOIqI7BOq6HpLkF4Yhv2anMRAI4YXDnl3p5ZtDwXg3BgAAAMCYIRACAAAAQEARCAEAAAAgoAiEAAAAABBQBEIAAAAACCgCIQAAAAAEFIEQAAAAAAKKQAgAAAAAAUUgBAAAAICAIhACAAAAQEARCAEAAAAgoAiEAAAAABBQBEIAAAAACCgCIQAAAAAEFIEQAAAAAAKKQAgAAAAAAUUgBAAAAICAIhACAAAAQEARCAEAAAAgoAiEAAAAABBQBEIAAAAACCgCIQAAAAAEFIEQAAAAAAKKQAgAAAAAAUUgBAAAAICAIhACAAAAQEARCAEAAAAgoAiEAAAAABBQBEIAAAAACCgCIQAAAAAEFIEQAAAAAAKKQAgAAAAAAUUgBAAAAICAIhACAAAAQEARCAEAAAAgoAiEAAAAABBQBEIAAAAACCgCIQAAAAAEFIEQAAAAAAKKQAgAAAAAAUUgBAAAAICAIhACAAAAQEARCAEAAAAgoAiEAAAAABBQBEIAAAAACCgCIQAAAAAEFIEQAAAAAAKKQAgAAAAAAUUgBAAAAICAIhACAAAAQEARCAEAAAAgoAiEAAAAABBQBEIAAAAACCgCIQAAAAAEFIEQAAAAAAKKQAgAAAAAAUUgBAAAAICAIhACAAAAQEARCAEAAAAgoAiEAAAAABBQBEIAAAAACCgCIQAAAAAEFIEQAAAAAAKKQAgAAAAAAUUgBAAAAICAIhACAAAAQEARCAEAAAAgoAiEAAAAABBQBEIAAAAACCgCIQAAAAAEFIEQAAAAAAKKQAgAAAAAAUUgBAAAAICAIhACAAAAQEARCAEAAAAgoAiEAAAAABBQBEIAAAAACCgCIQAAAAAEFIEQAAAAAAKKQAgAAAAAAUUgBAAAAICAIhACAAAAQEARCAEAAAAgoAiEAAAAABBQBEIAAAAACCgCIQAAAAAEFIEQAAAAAAKKQAgAAAAAAUUgBAAAAICAIhACAAAAQEARCAEAAAAgoAiEAAAAABBQBEIAAAAACCgCIQAAAAAEFIEQAAAAAAKKQAgAAAAAAUUgBAAAAICAIhACAAAAQEARCAEAAAAgoAiEAAAAABBQBEIAAAAACCgCIQAAAAAEFIEQAAAAAAKKQAgAAAAAAUUgBAAAAICAIhACAAAAQEARCAEAAAAgoAiEAAAAABBQBEIAAAAACCgCIQAAAAAEFIEQAAAAAAKKQAgAAAAAAUUgBAAAAICAIhACAAAAQEARCAEAAAAgoAiEAAAAABBQBEIAAAAACCgCIQAAAAAEFIEQAAAAAAKKQAgAAAAAAUUgBAAAAICAIhACAAAAQEARCAEAAAAgoAiEAAAAABBQBEIAAAAACCgCIQAAAAAEFIEQAAAAAAKKQAgAAAAAAUUgBAAAAICAIhACAAAAQEARCAEAAAAgoAiEAAAAABBQBEIAAAAACCgCIQAAAAAEFIEQAAAAAAKKQAgAAAAAAUUgBAAAAICAIhACAAAAQEARCAEAAAAgoAiEAAAAABBQBEIAAAAACCgCIQAAAAAEFIEQAAAAAAKKQAgAAAAAAUUgBAAAAICAIhACAAAAQEARCAEAAAAgoAiEAAAAABBQBEIAAAAACCgCIQAAAAAEFIEQAAAAAAKKQAgAAAAAAUUgBAAAAICAIhACAAAAQEARCAEAAAAgoP4/LtsQla6lTXMAAAAASUVORK5CYII="
                        }, void 0, false, {
                            fileName: "[project]/src/components/Icons.tsx",
                            lineNumber: 228,
                            columnNumber: 9
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 216,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Icons.tsx",
            lineNumber: 185,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0)),
    UpRightArrowDark: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            src: "/assets/Icons/UpRightArrowDark.png",
            alt: "UpRightArrow",
            width: 12,
            height: 12,
            className: "ml-[4px] w-[12px] h-[12px] mt-[1px]"
        }, void 0, false, {
            fileName: "[project]/src/components/Icons.tsx",
            lineNumber: 239,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0)),
    UpRightArrowLight: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            src: "/assets/Icons/UpRightArrowLight.png",
            alt: "UpRightArrow",
            width: 12,
            height: 12,
            className: "ml-[4px] w-[12px] h-[12px] mt-[1px]"
        }, void 0, false, {
            fileName: "[project]/src/components/Icons.tsx",
            lineNumber: 248,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0)),
    HamBurger: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "36",
            height: "28",
            viewBox: "0 0 36 28",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M1 5.99985H35",
                    stroke: "white",
                    strokeWidth: "2",
                    strokeLinecap: "round"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 264,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M1 13.9998H35",
                    stroke: "white",
                    strokeWidth: "2",
                    strokeLinecap: "round"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 270,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M1 21.9998H35",
                    stroke: "white",
                    strokeWidth: "2",
                    strokeLinecap: "round"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 276,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Icons.tsx",
            lineNumber: 257,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0)),
    Imports: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "21",
            height: "20",
            viewBox: "0 0 21 20",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M16.925 6.40614L12.1312 1.6123V4.53114C12.1312 5.56239 12.9687 6.40614 14.0062 6.40614H16.925Z",
                    fill: "#FDFCFC"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 292,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M5.58765 1.25C4.5564 1.25 3.71265 2.09375 3.71265 3.125V16.875C3.71265 17.9062 4.5564 18.75 5.58765 18.75H15.4126C16.4439 18.75 17.2876 17.9062 17.2876 16.875V7.65617H14.0065C12.2815 7.65617 10.8815 6.25617 10.8815 4.53117V1.25H5.58765Z",
                    fill: "#FDFCFC"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 296,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Icons.tsx",
            lineNumber: 285,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0)),
    Industrial: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "21",
            height: "20",
            viewBox: "0 0 21 20",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                    clipPath: "url(#clip0_308_909)",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: "M17.7584 7.45992L17.4185 6.63591C18.5845 3.94591 18.5084 3.86591 18.2805 3.63591L16.7905 2.14991L16.6425 2.02191H16.4704C16.3785 2.02191 16.1085 2.02191 13.8424 3.06989L13.0085 2.72588C11.9305 -0.00012207 11.8204 -0.00012207 11.5005 -0.00012207H9.40246C9.08644 -0.00012207 8.96444 -0.00012207 7.96646 2.73588L7.13644 3.07989C5.60643 2.41986 4.70844 2.07989 4.46644 2.07989H4.26644L2.66644 3.67989C2.42041 3.92989 2.33441 4.01186 3.56839 6.65989L3.22843 7.48189C0.500427 8.55788 0.500427 8.66184 0.500427 8.99986V11.0959C0.500427 11.4259 0.500427 11.5419 3.23843 12.5438L3.57839 13.3638C2.41238 16.0538 2.49038 16.1338 2.71641 16.3638L4.20638 17.8518L4.35436 17.9819H4.52838C4.61835 17.9819 4.88638 17.9819 7.15438 16.9319L7.98641 17.2779C9.06441 19.9999 9.17443 19.9999 9.50041 19.9999H11.5944C11.9164 19.9999 12.0304 19.9999 13.0324 17.2659L13.8664 16.9219C15.3964 17.5819 16.2904 17.9219 16.5324 17.9219H16.7324L18.3484 16.3079C18.5784 16.0719 18.6585 15.9899 17.4324 13.3519L17.7704 12.5299C20.5004 11.4419 20.5004 11.3279 20.5004 10.9999V8.90386C20.5004 8.57391 20.5004 8.45789 17.7584 7.45991L17.7584 7.45992ZM10.5004 13.4979C9.80779 13.4995 9.13026 13.2956 8.55361 12.9119C7.97691 12.5281 7.52711 11.982 7.26103 11.3425C6.99494 10.7029 6.92456 9.99884 7.05888 9.31929C7.19319 8.63979 7.52613 8.01546 8.01546 7.52529C8.50484 7.03506 9.12868 6.70114 9.80796 6.56566C10.4872 6.43017 11.1914 6.49931 11.8315 6.76429C12.4714 7.02926 13.0184 7.47816 13.4031 8.05414C13.7878 8.63017 13.9929 9.30739 13.9925 9.99997C13.991 10.9261 13.6227 11.8141 12.9684 12.4696C12.314 13.1251 11.4267 13.4949 10.5005 13.498L10.5004 13.4979Z",
                        fill: "#FDFCFC"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Icons.tsx",
                        lineNumber: 311,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 310,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("clipPath", {
                        id: "clip0_308_909",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                            width: "20",
                            height: "20",
                            fill: "white",
                            transform: "translate(0.5)"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Icons.tsx",
                            lineNumber: 318,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/Icons.tsx",
                        lineNumber: 317,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 316,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Icons.tsx",
            lineNumber: 303,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0)),
    Delivery: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "21",
            height: "20",
            viewBox: "0 0 21 20",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M10.5001 5.69836L1.71105 10.5202C1.02198 10.8983 0.792299 11.7764 1.20715 12.4437L5.44782 19.2594H15.5525L19.7931 12.4437C20.208 11.7765 19.9783 10.8984 19.2893 10.5202L10.5001 5.69836Z",
                    fill: "#FDFCFC"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 336,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M17.2033 1.62028V7.29995L10.5002 3.62412L3.797 7.29995V1.62028C3.797 1.13592 4.18996 0.740601 4.67668 0.740601H16.3227C16.8102 0.740601 17.2031 1.13592 17.2031 1.62028H17.2033Z",
                    fill: "#FDFCFC"
                }, void 0, false, {
                    fileName: "[project]/src/components/Icons.tsx",
                    lineNumber: 340,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/Icons.tsx",
            lineNumber: 329,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/common/Header.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/dropdown-menu.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Icons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Icons.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
const NAV_ITEMS = [
    {
        label: "About Us",
        href: "/about-us"
    },
    {
        label: "Our Products",
        href: "/our-products"
    },
    {
        label: "News",
        href: "#"
    },
    {
        label: "Art",
        href: "#"
    },
    {
        label: "Career",
        href: "#"
    },
    {
        label: "Contact Us",
        href: "/contact"
    }
];
const LANGUAGES = [
    {
        code: "EN",
        name: "English"
    },
    {
        code: "PL",
        name: "Polish"
    },
    {
        code: "DE",
        name: "German"
    },
    {
        code: "FR",
        name: "French"
    }
];
const BREAKPOINTS = {
    MOBILE_LOGO: 786,
    MOBILE_MENU: 1025,
    DESKTOP_LARGE: 1275
};
const IMAGES = {
    DESKTOP_LOGO: "/assets/logos/light-logo.svg",
    MOBILE_LOGO: "/assets/logos/mobile-light-logo.svg"
};
const Navbar = (param)=>{
    let { className = "", activeNavItem = "" } = param;
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [isMenuOpen, setIsMenuOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isMenuOpen2, setIsMenuOpen2] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isLanguageDropdownOpen, setIsLanguageDropdownOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [selectedLanguage, setSelectedLanguage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("EN");
    const [windowWidth, setWindowWidth] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1200);
    const languageDropdownRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [showFixedNav, setShowFixedNav] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const topNavRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Navbar.useEffect": ()=>{
            const observer = new IntersectionObserver({
                "Navbar.useEffect": (param)=>{
                    let [entry] = param;
                    setShowFixedNav(!entry.isIntersecting);
                }
            }["Navbar.useEffect"], {
                threshold: 0
            } // trigger as soon as it leaves screen
            );
            if (topNavRef.current) {
                observer.observe(topNavRef.current);
            }
            return ({
                "Navbar.useEffect": ()=>{
                    if (topNavRef.current) observer.unobserve(topNavRef.current);
                }
            })["Navbar.useEffect"];
        }
    }["Navbar.useEffect"], []);
    // Responsive Logic
    const isMobileMenu = windowWidth <= BREAKPOINTS.MOBILE_MENU;
    const isMobileMenu2 = windowWidth <= BREAKPOINTS.MOBILE_MENU;
    const isMobileLogo = windowWidth <= BREAKPOINTS.MOBILE_LOGO;
    const navItemsWithActive = NAV_ITEMS.map((item)=>({
            ...item,
            isActive: item.label === activeNavItem
        }));
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Navbar.useEffect": ()=>{
            const handleClickOutside = {
                "Navbar.useEffect.handleClickOutside": (event)=>{
                    if (languageDropdownRef.current && !languageDropdownRef.current.contains(event.target)) {
                        setIsLanguageDropdownOpen(false);
                    }
                }
            }["Navbar.useEffect.handleClickOutside"];
            document.addEventListener("mousedown", handleClickOutside);
            return ({
                "Navbar.useEffect": ()=>document.removeEventListener("mousedown", handleClickOutside)
            })["Navbar.useEffect"];
        }
    }["Navbar.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Navbar.useEffect": ()=>{
            const handleResize = {
                "Navbar.useEffect.handleResize": ()=>setWindowWidth(window.innerWidth)
            }["Navbar.useEffect.handleResize"];
            if ("TURBOPACK compile-time truthy", 1) {
                setWindowWidth(window.innerWidth);
                window.addEventListener("resize", handleResize);
            }
            return ({
                "Navbar.useEffect": ()=>{
                    if ("TURBOPACK compile-time truthy", 1) {
                        window.removeEventListener("resize", handleResize);
                    }
                }
            })["Navbar.useEffect"];
        }
    }["Navbar.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Navbar.useEffect": ()=>{
            if (!isMobileMenu) {
                setIsMenuOpen(false);
            }
        }
    }["Navbar.useEffect"], [
        isMobileMenu
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Navbar.useEffect": ()=>{
            if (!isMobileMenu2) {
                setIsMenuOpen2(false);
            }
        }
    }["Navbar.useEffect"], [
        isMobileMenu2
    ]);
    const toggleMenu = ()=>{
        setIsMenuOpen(!isMenuOpen);
    };
    const toggleMenu2 = ()=>{
        setIsMenuOpen2(!isMenuOpen2);
    };
    const closeMenu = ()=>{
        setIsMenuOpen(false);
    };
    const closeMenu2 = ()=>{
        setIsMenuOpen2(false);
    };
    const toggleLanguageDropdown = ()=>{
        setIsLanguageDropdownOpen(!isLanguageDropdownOpen);
    };
    const selectLanguage = (langCode)=>{
        setSelectedLanguage(langCode);
        setIsLanguageDropdownOpen(false);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                ref: topNavRef,
                initial: {
                    y: -100,
                    opacity: 0
                },
                animate: {
                    y: 0,
                    opacity: 1
                },
                transition: {
                    duration: 0.6,
                    ease: "easeOut"
                },
                className: "absolute top-0 left-0 right-0 w-full z-[999]",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "   pl-4 pr-4 pt-6 pb-0   md:pl-[40px] md:pr-[40px] md:pt-6 md:pb-0   lg:pl-[80px] lg:pr-[80px] lg:pt-[45.48px] lg:pb-[16px]    3xl:pl-0 3xl:pr-0 3xl:pt-[36px] 3xl:pb-[16px]   3xl:max-w-[1306px] w-full mx-auto",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                        className: "flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-shrink-0 cursor-pointer",
                                onClick: ()=>router.push("/"),
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    src: isMobileLogo ? IMAGES.MOBILE_LOGO : IMAGES.DESKTOP_LOGO,
                                    alt: "Danske Gas",
                                    width: isMobileLogo ? 35 : 244,
                                    height: isMobileLogo ? 30 : 40,
                                    priority: true,
                                    className: "transition-all duration-300 only-lg:w-[200px] md:w-[224px] md:h-[44px]"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/common/Header.tsx",
                                    lineNumber: 186,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/common/Header.tsx",
                                lineNumber: 182,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            !isMobileMenu && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-[80px]",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-10",
                                        children: navItemsWithActive.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                href: item.href,
                                                className: "cursor-pointer inline-block font-normal text-[20px] leading-[150%] only-lg:text-[18px] \n                          hover:scale-110\n                          transition-all duration-300 whitespace-nowrap relative group text-white",
                                                children: [
                                                    item.label,
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "absolute left-0 -bottom-0 h-[1px] bg-white transition-all duration-300 ".concat(item.isActive ? "w-full" : "w-0 group-hover:w-full")
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/common/Header.tsx",
                                                        lineNumber: 212,
                                                        columnNumber: 23
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, index, true, {
                                                fileName: "[project]/src/components/common/Header.tsx",
                                                lineNumber: 201,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0)))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/common/Header.tsx",
                                        lineNumber: 199,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex-shrink-0 relative",
                                        ref: languageDropdownRef,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: toggleLanguageDropdown,
                                                className: "flex items-center text-white font-normal text-[18px] transition-opacity duration-300 hover:opacity-80 only-lg:text-[16px]  cursor-pointer",
                                                children: [
                                                    selectedLanguage,
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                                                        className: "ml-1 w-4 h-4 transition-transform duration-300 ".concat(isLanguageDropdownOpen ? "rotate-180" : "")
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/common/Header.tsx",
                                                        lineNumber: 229,
                                                        columnNumber: 21
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/common/Header.tsx",
                                                lineNumber: 224,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            isLanguageDropdownOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "absolute top-full left-1/2 transform -translate-x-[61.4%] mt-2 py-2 min-w-[80px] z-50",
                                                children: LANGUAGES.map((language)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: ()=>selectLanguage(language.code),
                                                        className: "block w-full text-center px-1 py-1 text-white font-normal text-[18px] leading-[150%] uppercase transition-opacity duration-300 hover:opacity-80 cursor-pointer",
                                                        style: {
                                                            fontWeight: 400,
                                                            fontSize: "18px",
                                                            lineHeight: "150%",
                                                            letterSpacing: "0%",
                                                            textTransform: "uppercase"
                                                        },
                                                        children: language.code
                                                    }, language.code, false, {
                                                        fileName: "[project]/src/components/common/Header.tsx",
                                                        lineNumber: 239,
                                                        columnNumber: 25
                                                    }, ("TURBOPACK compile-time value", void 0)))
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/common/Header.tsx",
                                                lineNumber: 237,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/common/Header.tsx",
                                        lineNumber: 220,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/common/Header.tsx",
                                lineNumber: 198,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            isMobileMenu && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenu"], {
                                open: isMenuOpen,
                                onOpenChange: setIsMenuOpen,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuTrigger"], {
                                        asChild: true,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            "aria-label": "Toggle menu",
                                            className: "cursor-pointer z-50",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Icons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Icons"].HamBurger, {}, void 0, false, {
                                                fileName: "[project]/src/components/common/Header.tsx",
                                                lineNumber: 268,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/common/Header.tsx",
                                            lineNumber: 264,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/common/Header.tsx",
                                        lineNumber: 263,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuContent"], {
                                        className: "max-w-[calc(100vw-32px)] w-[calc(100vw-32px)] mx-4    md:max-w-[calc(100vw-80px)] md:w-[calc(100vw-80px)] md:mx-[40px]   mt-4 rounded-b-2xl bg-off-white backdrop-blur-lg shadow-2xl border border-white/30 z-[60]",
                                        align: "end",
                                        sideOffset: 8,
                                        style: {
                                            borderRadius: "0 0 20px 20px"
                                        },
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mt-4 mb-2",
                                            children: [
                                                navItemsWithActive.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                                                        asChild: true,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            href: item.href,
                                                            onClick: closeMenu,
                                                            className: "block px-6 py-2 font-normal text-[20px] transition-all duration-300 relative group cursor-pointer ".concat(item.isActive ? "text-charcoal font-bold" : "text-charcoal"),
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "relative inline-block",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "transition-opacity duration-300 ".concat(item.isActive ? "" : "group-hover:opacity-0"),
                                                                        children: item.label
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/common/Header.tsx",
                                                                        lineNumber: 291,
                                                                        columnNumber: 29
                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                    !item.isActive && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "absolute inset-0 font-bold opacity-0 transition-opacity duration-300 group-hover:opacity-100",
                                                                        children: item.label
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/common/Header.tsx",
                                                                        lineNumber: 299,
                                                                        columnNumber: 31
                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "absolute left-0 -bottom-0 h-[1px] bg-charcoal transition-all duration-300 ".concat(item.isActive ? "w-full" : "w-0 group-hover:w-full")
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/common/Header.tsx",
                                                                        lineNumber: 304,
                                                                        columnNumber: 29
                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/components/common/Header.tsx",
                                                                lineNumber: 290,
                                                                columnNumber: 27
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/common/Header.tsx",
                                                            lineNumber: 282,
                                                            columnNumber: 25
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    }, index, false, {
                                                        fileName: "[project]/src/components/common/Header.tsx",
                                                        lineNumber: 281,
                                                        columnNumber: 23
                                                    }, ("TURBOPACK compile-time value", void 0))),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "relative",
                                                    ref: languageDropdownRef,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: toggleLanguageDropdown,
                                                            className: "flex items-center px-6 py-3 font-normal text-[18px] text-charcoal transition-opacity duration-300 hover:opacity-80 w-full text-left cursor-pointer",
                                                            children: [
                                                                selectedLanguage,
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                                                                    className: "ml-2 w-4 h-4 transition-transform duration-300 ".concat(isLanguageDropdownOpen ? "rotate-180" : "")
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/common/Header.tsx",
                                                                    lineNumber: 321,
                                                                    columnNumber: 25
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/common/Header.tsx",
                                                            lineNumber: 316,
                                                            columnNumber: 23
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        isLanguageDropdownOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "px-6 pb-2",
                                                            children: LANGUAGES.filter((lang)=>lang.code !== selectedLanguage).map((language)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                    onClick: ()=>selectLanguage(language.code),
                                                                    className: "block w-full text-left py-1 text-charcoal font-normal text-[18px] leading-[150%] uppercase transition-opacity duration-300 hover:opacity-80 cursor-pointer",
                                                                    style: {
                                                                        fontWeight: 400,
                                                                        fontSize: "18px",
                                                                        lineHeight: "150%",
                                                                        letterSpacing: "0%",
                                                                        textTransform: "uppercase"
                                                                    },
                                                                    children: language.code
                                                                }, language.code, false, {
                                                                    fileName: "[project]/src/components/common/Header.tsx",
                                                                    lineNumber: 332,
                                                                    columnNumber: 29
                                                                }, ("TURBOPACK compile-time value", void 0)))
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/common/Header.tsx",
                                                            lineNumber: 328,
                                                            columnNumber: 25
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/common/Header.tsx",
                                                    lineNumber: 315,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/common/Header.tsx",
                                            lineNumber: 279,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/common/Header.tsx",
                                        lineNumber: 271,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/common/Header.tsx",
                                lineNumber: 262,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/common/Header.tsx",
                        lineNumber: 181,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/common/Header.tsx",
                    lineNumber: 174,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/common/Header.tsx",
                lineNumber: 167,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                children: showFixedNav && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    initial: {
                        y: -100,
                        opacity: 0
                    },
                    animate: {
                        y: 0,
                        opacity: 1
                    },
                    exit: {
                        y: -100,
                        opacity: 0
                    },
                    transition: {
                        duration: 0.6,
                        ease: "easeOut"
                    },
                    className: "fixed top-0 left-0 right-0 w-full z-[999] \n              bg-gradient-to-r from-[#A01800] via-[#D80A00] to-[#F99639]",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "   pl-4 pr-4 py-[8px]   md:pl-[40px] md:pr-[40px] md:py-[15px]   lg:pl-[80px] lg:pr-[80px] lg:py-[28px]    3xl:pl-0 3xl:pr-0 3xl:py-[28px]   3xl:max-w-[1306px] w-full mx-auto",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                            className: "flex items-center justify-between",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-shrink-0 cursor-pointer",
                                    onClick: ()=>router.push("/"),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        src: isMobileLogo ? IMAGES.MOBILE_LOGO : IMAGES.DESKTOP_LOGO,
                                        alt: "Danske Gas",
                                        width: isMobileLogo ? 35 : 244,
                                        height: isMobileLogo ? 30 : 40,
                                        priority: true,
                                        className: "transition-all duration-300 only-lg:w-[200px] md:w-[224px] md:h-[44px]"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/common/Header.tsx",
                                        lineNumber: 382,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/src/components/common/Header.tsx",
                                    lineNumber: 378,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)),
                                !isMobileMenu2 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-[80px]",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-10",
                                            children: navItemsWithActive.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    href: item.href,
                                                    className: "cursor-pointer inline-block font-normal text-[20px] leading-[150%] only-lg:text-[18px] \n                              hover:scale-110\n                              transition-all duration-300 whitespace-nowrap relative group text-white",
                                                    children: [
                                                        item.label,
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "absolute left-0 -bottom-0 h-[1px] bg-white transition-all duration-300 ".concat(item.isActive ? "w-full" : "w-0 group-hover:w-full")
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/common/Header.tsx",
                                                            lineNumber: 408,
                                                            columnNumber: 27
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, index, true, {
                                                    fileName: "[project]/src/components/common/Header.tsx",
                                                    lineNumber: 397,
                                                    columnNumber: 25
                                                }, ("TURBOPACK compile-time value", void 0)))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/common/Header.tsx",
                                            lineNumber: 395,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex-shrink-0 relative",
                                            ref: languageDropdownRef,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: toggleLanguageDropdown,
                                                    className: "flex items-center text-white font-normal text-[18px] transition-opacity duration-300 hover:opacity-80 only-lg:text-[16px]  cursor-pointer",
                                                    children: [
                                                        selectedLanguage,
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                                                            className: "ml-1 w-4 h-4 transition-transform duration-300 ".concat(isLanguageDropdownOpen ? "rotate-180" : "")
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/common/Header.tsx",
                                                            lineNumber: 425,
                                                            columnNumber: 25
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/common/Header.tsx",
                                                    lineNumber: 420,
                                                    columnNumber: 23
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                isLanguageDropdownOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "absolute top-full left-1/2 transform -translate-x-[61.4%] mt-2 py-2 min-w-[80px] z-50",
                                                    children: LANGUAGES.map((language)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>selectLanguage(language.code),
                                                            className: "block w-full text-center px-1 py-1 text-white font-normal text-[18px] leading-[150%] uppercase transition-opacity duration-300 hover:opacity-80 cursor-pointer",
                                                            style: {
                                                                fontWeight: 400,
                                                                fontSize: "18px",
                                                                lineHeight: "150%",
                                                                letterSpacing: "0%",
                                                                textTransform: "uppercase"
                                                            },
                                                            children: language.code
                                                        }, language.code, false, {
                                                            fileName: "[project]/src/components/common/Header.tsx",
                                                            lineNumber: 435,
                                                            columnNumber: 29
                                                        }, ("TURBOPACK compile-time value", void 0)))
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/common/Header.tsx",
                                                    lineNumber: 433,
                                                    columnNumber: 25
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/common/Header.tsx",
                                            lineNumber: 416,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/common/Header.tsx",
                                    lineNumber: 394,
                                    columnNumber: 19
                                }, ("TURBOPACK compile-time value", void 0)),
                                isMobileMenu2 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenu"], {
                                    open: isMenuOpen2,
                                    onOpenChange: setIsMenuOpen2,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuTrigger"], {
                                            asChild: true,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                "aria-label": "Toggle menu",
                                                className: "cursor-pointer z-50",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Icons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Icons"].HamBurger, {}, void 0, false, {
                                                    fileName: "[project]/src/components/common/Header.tsx",
                                                    lineNumber: 464,
                                                    columnNumber: 25
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/common/Header.tsx",
                                                lineNumber: 460,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/common/Header.tsx",
                                            lineNumber: 459,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuContent"], {
                                            className: "max-w-[calc(100vw-32px)] w-[calc(100vw-32px)] mx-4    md:max-w-[calc(100vw-80px)] md:w-[calc(100vw-80px)] md:mx-[40px]   mt-4 rounded-b-2xl bg-off-white backdrop-blur-lg shadow-2xl border border-white/30 z-[60]",
                                            align: "end",
                                            sideOffset: 8,
                                            style: {
                                                borderRadius: "0 0 20px 20px"
                                            },
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mt-4 mb-2",
                                                children: [
                                                    navItemsWithActive.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                                                            asChild: true,
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                href: item.href,
                                                                onClick: closeMenu,
                                                                className: "block px-6 py-2 font-normal text-[20px] transition-all duration-300 relative group cursor-pointer ".concat(item.isActive ? "text-charcoal font-bold" : "text-charcoal"),
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "relative inline-block",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "transition-opacity duration-300 ".concat(item.isActive ? "" : "group-hover:opacity-0"),
                                                                            children: item.label
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/components/common/Header.tsx",
                                                                            lineNumber: 487,
                                                                            columnNumber: 33
                                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                                        !item.isActive && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "absolute inset-0 font-bold opacity-0 transition-opacity duration-300 group-hover:opacity-100",
                                                                            children: item.label
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/components/common/Header.tsx",
                                                                            lineNumber: 495,
                                                                            columnNumber: 35
                                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "absolute left-0 -bottom-0 h-[1px] bg-charcoal transition-all duration-300 ".concat(item.isActive ? "w-full" : "w-0 group-hover:w-full")
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/components/common/Header.tsx",
                                                                            lineNumber: 500,
                                                                            columnNumber: 33
                                                                        }, ("TURBOPACK compile-time value", void 0))
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/components/common/Header.tsx",
                                                                    lineNumber: 486,
                                                                    columnNumber: 31
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/common/Header.tsx",
                                                                lineNumber: 478,
                                                                columnNumber: 29
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        }, index, false, {
                                                            fileName: "[project]/src/components/common/Header.tsx",
                                                            lineNumber: 477,
                                                            columnNumber: 27
                                                        }, ("TURBOPACK compile-time value", void 0))),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "relative",
                                                        ref: languageDropdownRef,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                onClick: toggleLanguageDropdown,
                                                                className: "flex items-center px-6 py-3 font-normal text-[18px] text-charcoal transition-opacity duration-300 hover:opacity-80 w-full text-left cursor-pointer",
                                                                children: [
                                                                    selectedLanguage,
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                                                                        className: "ml-2 w-4 h-4 transition-transform duration-300 ".concat(isLanguageDropdownOpen ? "rotate-180" : "")
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/common/Header.tsx",
                                                                        lineNumber: 517,
                                                                        columnNumber: 29
                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/components/common/Header.tsx",
                                                                lineNumber: 512,
                                                                columnNumber: 27
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            isLanguageDropdownOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "px-6 pb-2",
                                                                children: LANGUAGES.filter((lang)=>lang.code !== selectedLanguage).map((language)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                        onClick: ()=>selectLanguage(language.code),
                                                                        className: "block w-full text-left py-1 text-charcoal font-normal text-[18px] leading-[150%] uppercase transition-opacity duration-300 hover:opacity-80 cursor-pointer",
                                                                        style: {
                                                                            fontWeight: 400,
                                                                            fontSize: "18px",
                                                                            lineHeight: "150%",
                                                                            letterSpacing: "0%",
                                                                            textTransform: "uppercase"
                                                                        },
                                                                        children: language.code
                                                                    }, language.code, false, {
                                                                        fileName: "[project]/src/components/common/Header.tsx",
                                                                        lineNumber: 528,
                                                                        columnNumber: 33
                                                                    }, ("TURBOPACK compile-time value", void 0)))
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/common/Header.tsx",
                                                                lineNumber: 524,
                                                                columnNumber: 29
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/common/Header.tsx",
                                                        lineNumber: 511,
                                                        columnNumber: 25
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/common/Header.tsx",
                                                lineNumber: 475,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/common/Header.tsx",
                                            lineNumber: 467,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/common/Header.tsx",
                                    lineNumber: 458,
                                    columnNumber: 19
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/common/Header.tsx",
                            lineNumber: 377,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/common/Header.tsx",
                        lineNumber: 370,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                }, "fixed-nav", false, {
                    fileName: "[project]/src/components/common/Header.tsx",
                    lineNumber: 361,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/common/Header.tsx",
                lineNumber: 359,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/common/Header.tsx",
        lineNumber: 166,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(Navbar, "BnExM9QaI0qZMqpCYDIV0OVMfpw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = Navbar;
const __TURBOPACK__default__export__ = Navbar;
var _c;
__turbopack_context__.k.register(_c, "Navbar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/common/Footer.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
;
;
;
// Constants
const LOGO_DIMENSIONS = {
    width: 224,
    height: 44,
    className: "w-[223.9991302490234px] h-[44.000694274902344px]"
};
const COMMON_CLASSES = {
    sectionTitle: "font-medium mb-[16px]",
    linkBase: "text-white hover:text-white transition-colors duration-200",
    linkSpacing: "space-y-[2px]",
    officeSpacing: "leading-[140%] lg:space-y-[8px] md:space-y-[8px] space-y-[12px]",
    legalSpacing: "space-y-[8px]"
};
// Extracted LinkedIn Icon component
const LinkedInIcon = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "32",
        height: "32",
        viewBox: "0 0 32 33",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                clipPath: "url(#clip0_144_1137)",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                    d: "M16 0.578125C7.16344 0.578125 0 7.74156 0 16.5781C0 25.4147 7.16344 32.5781 16 32.5781C24.8366 32.5781 32 25.4147 32 16.5781C32 7.74156 24.8366 0.578125 16 0.578125ZM11.4647 24.4948H7.89881V13.3064H11.4647V24.4948ZM9.68175 11.8411C9.28495 11.8411 8.89706 11.7235 8.56714 11.503C8.23721 11.2826 7.98006 10.9692 7.82822 10.6026C7.67637 10.236 7.63664 9.83265 7.71405 9.44347C7.79146 9.0543 7.98254 8.69682 8.26312 8.41624C8.5437 8.13566 8.90118 7.94459 9.29035 7.86717C9.67952 7.78976 10.0829 7.82949 10.4495 7.98134C10.8161 8.13319 11.1294 8.39034 11.3499 8.72026C11.5703 9.05019 11.688 9.43808 11.688 9.83488C11.688 10.367 11.4766 10.8773 11.1004 11.2535C10.7241 11.6298 10.2138 11.8411 9.68175 11.8411ZM24.325 24.4948H20.825V18.3772C20.825 18.0664 20.8741 16.0054 19.1238 16.0054C18.8128 15.9976 18.5045 16.0651 18.2251 16.2019C17.9456 16.3387 17.7034 16.5409 17.5187 16.7914C17.1973 17.2203 17.0256 17.7429 17.0301 18.2789V24.4946H13.5344V13.3064H16.8604V14.8767C17.6564 13.6554 18.6597 13.2083 19.6465 13.0284C21.3982 12.709 24.3247 13.7754 24.3247 16.9596L24.325 24.4948Z",
                    fill: "#FDFCFC"
                }, void 0, false, {
                    fileName: "[project]/src/components/common/Footer.tsx",
                    lineNumber: 49,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/common/Footer.tsx",
                lineNumber: 48,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("clipPath", {
                    id: "clip0_144_1137",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                        width: "32",
                        height: "32",
                        fill: "white",
                        transform: "translate(0 0.578125)"
                    }, void 0, false, {
                        fileName: "[project]/src/components/common/Footer.tsx",
                        lineNumber: 56,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/common/Footer.tsx",
                    lineNumber: 55,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/common/Footer.tsx",
                lineNumber: 54,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/common/Footer.tsx",
        lineNumber: 41,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c = LinkedInIcon;
// Reusable components
const FooterLogo = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mb-4",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            href: "/",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                src: "/assets/logos/light-logo.svg",
                alt: "Danske Gas Logo",
                ...LOGO_DIMENSIONS
            }, void 0, false, {
                fileName: "[project]/src/components/common/Footer.tsx",
                lineNumber: 71,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/components/common/Footer.tsx",
            lineNumber: 70,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/common/Footer.tsx",
        lineNumber: 69,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c1 = FooterLogo;
const FooterDescription = (param)=>{
    let { className = "text-[16px]" } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "".concat(className, " md:w-[394px] lg:block md:block hidden md:text-[16px] text-white leading-[140%] lg:tracking-[-0.2px]"),
                children: "Danske Gas powers industries, engines, and champions. From high-performance racing fuels to technical gases."
            }, void 0, false, {
                fileName: "[project]/src/components/common/Footer.tsx",
                lineNumber: 84,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            " ",
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "".concat(className, " lg:hidden md:hidden block lg:w-full md:w-full max-w-[354px] w-full text-[16px] text-white leading-[140%] lg:tracking-[-0.2px]"),
                children: "Danske Gas powers industries, engines, and champions. From high-performance racing fuels to technical gases."
            }, void 0, false, {
                fileName: "[project]/src/components/common/Footer.tsx",
                lineNumber: 90,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/common/Footer.tsx",
        lineNumber: 83,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
};
_c2 = FooterDescription;
const LinksSection = (param)=>{
    let { title, links, titleClass = "text-[20px]", linkClass = "text-[16px] font-normal leading-[132%] tracking-tight", containerClass = COMMON_CLASSES.linkSpacing } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: " ".concat(title === "Legal" ? "lg:mt-0 lg:ml-0 md:mt-[22px] md:ml-[-16px]" : ""),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "".concat(COMMON_CLASSES.sectionTitle, " ").concat(titleClass),
                children: title
            }, void 0, false, {
                fileName: "[project]/src/components/common/Footer.tsx",
                lineNumber: 115,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                className: containerClass,
                children: links.map((link, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: link.href,
                            className: "".concat(linkClass, " ").concat(COMMON_CLASSES.linkBase),
                            children: link.name
                        }, void 0, false, {
                            fileName: "[project]/src/components/common/Footer.tsx",
                            lineNumber: 119,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, "".concat(title, "-").concat(index), false, {
                        fileName: "[project]/src/components/common/Footer.tsx",
                        lineNumber: 118,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)))
            }, void 0, false, {
                fileName: "[project]/src/components/common/Footer.tsx",
                lineNumber: 116,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/common/Footer.tsx",
        lineNumber: 114,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
};
_c3 = LinksSection;
const OfficeSection = (param)=>{
    let { office, titleClass = "text-[20px]", textClass = "text-[16px]", containerClass = COMMON_CLASSES.officeSpacing } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "2xl:w-[170px] lg:mt-0 lg:ml-0 md:mt-[6px] md:ml-[10px]",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "".concat(COMMON_CLASSES.sectionTitle, " ").concat(titleClass),
                children: "Office"
            }, void 0, false, {
                fileName: "[project]/src/components/common/Footer.tsx",
                lineNumber: 145,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: containerClass,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: office.address.map((line, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "".concat(textClass, " text-white"),
                                children: line
                            }, "address-".concat(index), false, {
                                fileName: "[project]/src/components/common/Footer.tsx",
                                lineNumber: 149,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)))
                    }, void 0, false, {
                        fileName: "[project]/src/components/common/Footer.tsx",
                        lineNumber: 147,
                        columnNumber: 7
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-[16px] text-white lg:mt-[20px]",
                        children: office.phone
                    }, void 0, false, {
                        fileName: "[project]/src/components/common/Footer.tsx",
                        lineNumber: 154,
                        columnNumber: 7
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "mailto:".concat(office.email),
                        className: "".concat(textClass, " ").concat(COMMON_CLASSES.linkBase),
                        children: office.email
                    }, void 0, false, {
                        fileName: "[project]/src/components/common/Footer.tsx",
                        lineNumber: 155,
                        columnNumber: 7
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/common/Footer.tsx",
                lineNumber: 146,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/common/Footer.tsx",
        lineNumber: 144,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
};
_c4 = OfficeSection;
const Footer = ()=>{
    const footerData = {
        links: [
            {
                name: "Products",
                href: "#"
            },
            {
                name: "News",
                href: "#"
            },
            {
                name: "About Us",
                href: "#"
            },
            {
                name: "Art",
                href: "#"
            },
            {
                name: "Contact Us",
                href: "#"
            }
        ],
        legal: [
            {
                name: "Privacy Policy",
                href: "#"
            },
            {
                name: "Terms and Conditions",
                href: "#"
            },
            {
                name: "Cookies Settings",
                href: "#"
            }
        ],
        office: {
            address: [
                "Wawelska 45/58,",
                "02-034 Warszawa"
            ],
            phone: "+48 780 751 724",
            email: "email@danskegas.com"
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
        className: "bg-brown text-white",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container-custom",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "hidden lg:block pt-[56px] pb-[42px] 3xl:ml-[-9px] 2xl:ml-0",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex  flex-row ",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "2xl:mr-[247px]",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FooterLogo, {}, void 0, false, {
                                            fileName: "[project]/src/components/common/Footer.tsx",
                                            lineNumber: 193,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FooterDescription, {}, void 0, false, {
                                            fileName: "[project]/src/components/common/Footer.tsx",
                                            lineNumber: 194,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/common/Footer.tsx",
                                    lineNumber: 192,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: " flex 2xl:gap-[100px] 3xl:mt-[3px] 2xl:mt-[-1px] gap-[110px]",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "2xl:w-[117px]",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LinksSection, {
                                                title: "Links",
                                                links: footerData.links,
                                                containerClass: COMMON_CLASSES.linkSpacing
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/common/Footer.tsx",
                                                lineNumber: 198,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/common/Footer.tsx",
                                            lineNumber: 197,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OfficeSection, {
                                            office: footerData.office,
                                            containerClass: COMMON_CLASSES.officeSpacing
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/common/Footer.tsx",
                                            lineNumber: 204,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LinksSection, {
                                            title: "Legal",
                                            links: footerData.legal,
                                            containerClass: COMMON_CLASSES.legalSpacing
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/common/Footer.tsx",
                                            lineNumber: 208,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/common/Footer.tsx",
                                    lineNumber: 196,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/common/Footer.tsx",
                            lineNumber: 191,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/common/Footer.tsx",
                        lineNumber: 190,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "hidden sm:block lg:hidden 2xl:pt-[56px] md:pt-10 pb-[42px]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FooterLogo, {}, void 0, false, {
                                        fileName: "[project]/src/components/common/Footer.tsx",
                                        lineNumber: 220,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FooterDescription, {}, void 0, false, {
                                        fileName: "[project]/src/components/common/Footer.tsx",
                                        lineNumber: 221,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/common/Footer.tsx",
                                lineNumber: 219,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex lg:gap-[146px] md:gap-[129px] mt-[40px]",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LinksSection, {
                                        title: "Links",
                                        links: footerData.links,
                                        linkClass: "text-[16px]"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/common/Footer.tsx",
                                        lineNumber: 224,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OfficeSection, {
                                        office: footerData.office,
                                        titleClass: "text-lg",
                                        textClass: "text-[16px]"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/common/Footer.tsx",
                                        lineNumber: 229,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LinksSection, {
                                        title: "Legal",
                                        links: footerData.legal,
                                        titleClass: "text-lg",
                                        linkClass: "text-[16px]"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/common/Footer.tsx",
                                        lineNumber: 234,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/common/Footer.tsx",
                                lineNumber: 223,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/common/Footer.tsx",
                        lineNumber: 218,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "block sm:hidden pt-[56px] pb-[65px] lg:ml-0 xs:ml-[9px]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-[60px]",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FooterLogo, {}, void 0, false, {
                                        fileName: "[project]/src/components/common/Footer.tsx",
                                        lineNumber: 246,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FooterDescription, {
                                        className: "text-sm"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/common/Footer.tsx",
                                        lineNumber: 247,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/common/Footer.tsx",
                                lineNumber: 245,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex ",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex-1",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LinksSection, {
                                                    title: "Links",
                                                    links: footerData.links,
                                                    titleClass: "text-lg"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/common/Footer.tsx",
                                                    lineNumber: 252,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/common/Footer.tsx",
                                                lineNumber: 251,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex-1",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(OfficeSection, {
                                                    office: footerData.office,
                                                    titleClass: "text-lg"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/common/Footer.tsx",
                                                    lineNumber: 259,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/common/Footer.tsx",
                                                lineNumber: 258,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/common/Footer.tsx",
                                        lineNumber: 250,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-[60px]",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LinksSection, {
                                            title: "Legal",
                                            links: footerData.legal,
                                            titleClass: "text-lg"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/common/Footer.tsx",
                                            lineNumber: 266,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/common/Footer.tsx",
                                        lineNumber: 265,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/common/Footer.tsx",
                                lineNumber: 249,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/common/Footer.tsx",
                        lineNumber: 244,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/common/Footer.tsx",
                lineNumber: 188,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "hidden lg:block md:block",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container-custom 2xl:w-[1280px] lg:mt-0 md:mt-[-3px]",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "border-t border-dark-gray pt-[14px] lg:pb-[56px] pb-[40px] 3xl:ml-[-22px] 2xl:ml-[-79px] 2xl:mt-[-5px] 2xl:w-[1280px]",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-row justify-between items-center gap-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[16px] text-white",
                                    children: "© 2025. All rights reserved."
                                }, void 0, false, {
                                    fileName: "[project]/src/components/common/Footer.tsx",
                                    lineNumber: 281,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    href: "#",
                                    className: "text-gray-400 hover:text-white transition-colors duration-200 ",
                                    "aria-label": "LinkedIn",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LinkedInIcon, {}, void 0, false, {
                                        fileName: "[project]/src/components/common/Footer.tsx",
                                        lineNumber: 289,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/src/components/common/Footer.tsx",
                                    lineNumber: 284,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/common/Footer.tsx",
                            lineNumber: 280,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/common/Footer.tsx",
                        lineNumber: 279,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/common/Footer.tsx",
                    lineNumber: 278,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/common/Footer.tsx",
                lineNumber: 277,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "block lg:hidden md:hidden",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "border-t border-dark-gray lg:pt-[14px] xs:pt-[22px] lg:pb-[40px] xs:pb-[64px] mt-2 ml-2",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "container-custom",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-row justify-between items-center gap-4 -mt-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[16px] text-white",
                                    children: "© 2025. All rights reserved."
                                }, void 0, false, {
                                    fileName: "[project]/src/components/common/Footer.tsx",
                                    lineNumber: 301,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    href: "#",
                                    className: "text-gray-400 hover:text-white transition-colors duration-200 mr-2",
                                    "aria-label": "LinkedIn",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LinkedInIcon, {}, void 0, false, {
                                        fileName: "[project]/src/components/common/Footer.tsx",
                                        lineNumber: 309,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/src/components/common/Footer.tsx",
                                    lineNumber: 304,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/common/Footer.tsx",
                            lineNumber: 300,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/common/Footer.tsx",
                        lineNumber: 299,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/common/Footer.tsx",
                    lineNumber: 298,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/common/Footer.tsx",
                lineNumber: 297,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/common/Footer.tsx",
        lineNumber: 187,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c5 = Footer;
const __TURBOPACK__default__export__ = Footer;
var _c, _c1, _c2, _c3, _c4, _c5;
__turbopack_context__.k.register(_c, "LinkedInIcon");
__turbopack_context__.k.register(_c1, "FooterLogo");
__turbopack_context__.k.register(_c2, "FooterDescription");
__turbopack_context__.k.register(_c3, "LinksSection");
__turbopack_context__.k.register(_c4, "OfficeSection");
__turbopack_context__.k.register(_c5, "Footer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/common/FooterWrapper.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>FooterWrapper
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$Footer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/common/Footer.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function FooterWrapper() {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    // ✅ Add all paths where footer should be hidden
    const noFooterPaths = [
        "/our-products"
    ];
    if (noFooterPaths.includes(pathname)) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$common$2f$Footer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
        fileName: "[project]/src/components/common/FooterWrapper.tsx",
        lineNumber: 14,
        columnNumber: 12
    }, this);
}
_s(FooterWrapper, "xbyQPtUVMO7MNj7WjJlpdWqRcTo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = FooterWrapper;
var _c;
__turbopack_context__.k.register(_c, "FooterWrapper");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_d9a8db5b._.js.map