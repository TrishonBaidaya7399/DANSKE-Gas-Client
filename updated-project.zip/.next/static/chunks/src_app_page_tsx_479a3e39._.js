(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_components_ea710eb8._.js",
  "static/chunks/node_modules_zod_v4_05d335f2._.js",
  "static/chunks/node_modules_gsap_8ed0561d._.js",
  "static/chunks/node_modules_2c96721c._.js"
],
    source: "dynamic"
});
