(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__8ebb6d4b._.css",
  "static/chunks/src_d9a8db5b._.js",
  "static/chunks/node_modules_next_3f48ce4d._.js",
  "static/chunks/node_modules_framer-motion_dist_es_4aade3dc._.js",
  "static/chunks/node_modules_motion-dom_dist_es_b028b575._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854acb4._.js",
  "static/chunks/node_modules_484c3bd9._.js"
],
    source: "dynamic"
});
