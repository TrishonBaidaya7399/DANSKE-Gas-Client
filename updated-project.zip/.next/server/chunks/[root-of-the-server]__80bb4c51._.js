module.exports = {

"[project]/.next-internal/server/app/favicon.ico/route/actions.js [app-rsc] (server actions loader, ecmascript)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/src/app/favicon--route-entry.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "GET": ()=>GET,
    "dynamic": ()=>dynamic
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-rsc] (ecmascript)");
;
const contentType = "image/x-icon";
const cacheControl = "public, max-age=0, must-revalidate";
const buffer = Buffer.from("AAABAAEAICAAAAEAIACoEAAAFgAAACgAAAAgAAAAQAAAAAEAIAAAAAAAABAAABMLAAATCwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKiblACkn5QwrJeR+KyPjgygg3w8uJugAGxPKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACwk4wAsJOYALCTkQSwk5OYrI+TyKiLjfigg4A0tJekAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALSTkAC4k5AktJOSJLCTk/ywk5P8sJOTyKyPjgCkg3w0oH94AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/f39AP39/QP9/f0A/f39AAAAAAAsJOQALCTkFCwk5MUsJOT/LCTk/ywk5P8sJOTwKyTkdiIh4AckIuEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPn5/QD5+f0I/f39aPv7/DL4+PoBAAAAAC0l5QAtJeUXLSXl2Cwk5P8sJOT/LCTk/ywk5P8sJOTsKyTkaDcq6gEtJeUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+/v9APv7/Vf8/P3m/f3+wP39/i79/f4ALCTkACwk5BMsJOS/LCTk/ywk5P8sJOT/LCTk/ywk5P8sJOTcLSXlUC0i4gMtJOQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPr6+gD29vUD/Pz9oPz8/f/8/P3+/f3+t/z8/ibd3PoALibkCC0l5H4sJOT5LCTk/ywk5P8sJOT/LCTk/ywk5P8sJOTTLCTlRywk5gIsJOUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+/v7APv7+x78/P29/Pz9//z8/f/8/P36/Pz9o/7+/Ru/u/UALybmHi0k5KcsJOT+LCTk/ywk5P8sJOT/LCTk/ywk5P8sJOTOLCTlRiwk5QEsJOUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD8/PwA/Pz8Jvz8/cX8/P3//Pz9//z8/f/8/P34/f39oP7+/RdybuwALiPjLSwk5MEsJOT/LCTk/ywk5P8sJOT/LCTk/ywk5P8sJOTPLCTlRSwk5QEsJOUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPz8/AD8/Pwc/Pz9u/z8/f/8/P3//Pz9//z8/f/8/P35/f39j////RQ9Tf4AKyPjOSwk5MosJOT/LCTk/ywk5P8sJOT/LCTk/ywk5P8sJOTPLCTlQywp7wEsJecAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA////AP///wX8/P2U/Pz9/vz8/f/8/P3//Pz9//z8/f/8/P32/Pz9jv39/Rf///8AKyTkQiwk5NEsJOT/LCTk/ywk5P8sJOT/LCTk/ywk5P8sJOTFKyPkLDAo6wAnH90AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKyPkAisj5CUoIN8M9vb8AP39/Tr8/P3e/Pz9//z8/f/8/P3//Pz9//z8/f/8/P30/Pz9jv39/RYAAAAALCTjSSwk5NEsJOT/LCTk/ywk5P8sJOT/LCTk/ywk5P0rI+RvKCDiBCoi4wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAsJOUELCTlbysj5IAnH98O////BPv7/Yf8/P33/Pz9//z8/f/8/P3//Pz9//z8/f/8/P30/Pz9j////RQAAMsBLCTjSCwk5NEsJOT/LCTk/ywk5P8sJOT/LCTk/ysj5KUrI+QPKyPkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACwk5QQsJOV/LCTk7ysj5IMoIeAN////Evv7/ZD8/P32/Pz9//z8/f/8/P3//Pz9//z8/f/8/P30/Pz8fv///AwQB+ACLCTjSSwk5NYsJOT/LCTk/ywk5P8sJOT/KyPksCsj5BIrI+QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALCTlBCwk5X0sJOT8LCTk7yok5HQVD+AI///+E/z8/Y/8/P30/Pz9//z8/f/8/P3//Pz9//z8/f/8/P3z/Pz9b///+gcHANwBLSXkWCwk5N0sJOT/LCTk/ywk5P8sJeWMLCXlCiwl5QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAsJOUELCTlfSwk5PosJOT/KyTk7Sok43QAANgF/v79Ffz8/Y/8/P30/Pz9//z8/f/8/P3//Pz9//z8/f/8/P3l/Pz8WO3t7QIDAOEBLSXkWiwk5OYsJOT/LCTk8ywk5FcsJN4BLCTjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACwk5QQsJOV9LCTk+iwk5P8sJOT/LCTk6y0l5Vr///8A+/v9F/z8/Zv8/P35/Pz9//z8/f/8/P3//Pz9//z8/f/8/P3a+/v7Uv//8AIaEeEFLCTjbywk5PEsJOSxLCTkGiwk5AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALCTkAiwk5FcsJOT3LCTk/ywk5P8sJOT/LCTk3S0l5VcAAM8B/v79HPz8/aL8/P37/Pz9//z8/f/8/P3//Pz9//z8/f/8/P3c+/v8Tf///QEnHOILLCTkXisk5EYlJOoALCTjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAtJeYALSXlHy0l5dssJOT/LCTk/ywk5P8sJOT/LCTk2S0k5E4AAOEB///+Hv39/r78/P39/Pz9//z8/f/8/P3//Pz9//z8/f/8/P2+/Pz9G+Df+gArJOQEKyTkBSsk5AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC0l5QAtJeUNLSXlmCwk5P8sJOT/LCTk/ywk5P8sJOT/LCTk0Swk5UgAAN8C////LPz8/b/8/P3//Pz9//z8/f/8/P3//Pz9//z8/fr9/f5G5OTtAP///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMCjnACcf4AAtJeQ/LCTk4ywk5P8sJOT/LCTk/ywk5P8sJOT/LCTk0Cwk5Un///8A/f3+Nfz8/cj8/P3//Pz9//z8/f/8/P3//Pz9/P39/nT///8E/v7+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALSLiAC0g4AotJOSELCTk+ywk5P8sJOT/LCTk/ywk5P8sJOT/LCTk0isj5UkAANQB/v7+Ov39/sn8/P3//Pz9//z8/f/8/P39/f39f/7+/Qb9/f0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALiXlAC4l5RwsJOSzLCTk/ywk5P8sJOT/LCTk/ywk5P8sJOT/LCTk0isj5Uf///8A///+N/39/sz8/P3//Pz9//z8/fz8/Pxw/Pz7BPz8/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA3JeIAJiHiACoi4jUsJOTHLCTk/ywk5P8sJOT/LCTk/ywk5P8sJOT/LCTkzSsk5D3//9kA////N/39/s38/P3//Pz97/z8/Tf6+vwA/v7+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKiTkACsk5D8sJOTOLCTk/ywk5P8sJOT/LCTk/ywk5P8sJOT/KyTktych4x0AAL8A+/v8Rvz8/dP8/P2e+/v8Efv7/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAsJOMALCTiAiwk40YsJOTOLCTk/ywk5P8sJOT/LCTk/ywk5P8sJOT5LCTkYQIA4AL///YC/Pz8Ofv7/Cr///8A9fX1AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAsJOMALCTjAiwk40UsJOTPLCTk/ywk5P8sJOT/LCTk/ywk5P8tJOSdLSTkDC0k5AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAsJOMALCTjASwk40YsJOTRLCTk/ywk5P8sJOT/LCTk/ywk5L8sJOQTLCTkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAsJOMALCfjASwj400sJOTZLCTk/ywk5P8sJOT/LCTltSwk5REsJOUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALibkAi0l5FUsJOTbLCTk/ywk5P8tJOSKLSTkCS0k5AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAtJeQALibkAywk5FwsJOTsLCTk5iwk5EEsJOYALCTjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAtI+MALiLiCSwk5HksJOSFKyTkDysk5AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//w////8H///+A///3gH//4YA//+GAH//AgA//wEAH/8AgA//AEAH/wAgB/iAEAP4AAAD+AAAA/gAAAP4AAAD+AgAB/gAAA/8AABP/AAAf/4AgD/+AAA//wAgP/+AEH//wAh//8AA///gB///8Af///gH///8B////g////8P/8=", 'base64');
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
function GET() {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["NextResponse"](buffer, {
        headers: {
            'Content-Type': contentType,
            'Cache-Control': cacheControl
        }
    });
}
const dynamic = 'force-static';
}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__80bb4c51._.js.map